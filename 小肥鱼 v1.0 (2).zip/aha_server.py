# -*- coding: utf-8 -*-
"""
Project Aha — Web 天文台后端 (aha_server.py)
=============================================

职责: 把 aha_brain 的小鱼接到浏览器上，让人能以"上帝视角"看它的记忆星云生长。

对外接口:
  GET  /                -> index.html（天文台前端）
  WS   /ws              -> 10Hz 推送大脑状态（首帧全量，之后增量）
  POST /teach           -> {text}  教小鱼一句话：先"听见"这句话，再问 DeepSeek，
                           把答案作为"百科全书的安全感反馈"注入，返回答案与想法
  POST /api/feed        -> 手动投喂一次（不经过 DeepSeek）
  GET  /api/state       -> 一次性 REST 快照（调试用）
  GET  /api/status      -> 健康检查：存活、节点数、有没有配 DeepSeek key
  POST /api/save        -> 立即把记忆落盘
  POST /api/think       -> 让小鱼凭空做一次清醒联想（不接输入）

设计约束（来自架构师）:
  - 每 100ms 必须能读到最新的 nodes / connections，前端才画得动。
  - 内稳态崩溃、外部 API 超时、单个节点数值爆炸，都**绝不能**让后端死锁。
    所以：主循环有独立的 try/except + 退避；WebSocket 单客户端异常只断它自己；
    DeepSeek 调用有硬超时，失败就降级成本地回答。
"""

import argparse
import asyncio
import collections
import contextlib
import json
import logging
import os
import random
import re
import threading
import time
import traceback
import urllib.error
import urllib.request
from pathlib import Path

import uvicorn
from fastapi import FastAPI, Request, Response, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse

from aha_brain import AhaEngine
from aha_input import (AhaInput, extract_text_feature, extract_char_feature,
                       read_text_file)

# ---------------------------------------------------------------------------
# 配置
# ---------------------------------------------------------------------------

HERE = Path(__file__).resolve().parent
MEMORY_DIR = HERE / "Memory_Core"
MEMORY_DIR.mkdir(parents=True, exist_ok=True)
CONFIG_FILE = MEMORY_DIR / "config.json"

# 端点由 config.json 的 deepseek_base 决定（见 _DEEPSEEK_BASE），这里只留官方默认值备查
DEFAULT_DEEPSEEK_BASE = "https://api.deepseek.com"
DEEPSEEK_TIMEOUT = 25.0

TICK_HZ = 10.0                 # 心跳频率
TICK_DT = 1.0 / TICK_HZ
FEED_INTERVAL = 0.6            # 保留给 /api/feed 手动投喂的参考节奏
SAVE_INTERVAL = 30.0           # 每 30 秒落一次盘

# --- 中文文本模式（m01200）---
# 小鱼不再看"边缘 + 颜色"的合成噪声，改成一本一本地读 .txt，一个字一个字地学。
CHAR_INTERVAL = 0.8            # 接上百科全书时，两个字之间歇多久（省额度也给大脑消化时间）
CHAR_INTERVAL_OFFLINE = 0.12   # 没接上网关就不用等网络，学得快一点
CHAR_ROUND_PAUSE = 3.0         # 一本书读完，歇多久再从头看
CHAR_CACHE_MAX = 4000          # 一个字只问一次，问过的存着


# 造物主控制台的存档槽（用户指定的名字，放在项目根目录方便直接拖走）
SAVE_SLOT = HERE / "Aha_Save_01.json"

# 大脑是单实例，却被两条线程同时碰：life_loop 会改结构（新增节点/连线），
# asyncio 线程要读结构（frame / snapshot）。不加锁就会撞出
# "dictionary changed size during iteration"，直接把前端连接打断。
_ENGINE_LOCK = threading.RLock()

# ---------------------------------------------------------------------------
# 观测层旁路：每个节点「顿悟过什么」
#
# 小鱼的 NeuronNode 里**没有** meta / memory 字段（模型刻意保持极简，不存语义），
# 而观测台要回答"这颗星星顿悟了什么"。所以这里在**不改大脑模型**的前提下，
# 旁路监听 engine.last_thought 的变化，把含节点 id 的想法归档到对应节点名下。
# 纯观测，不参与任何认知计算。
# ---------------------------------------------------------------------------

_CONN_RE = re.compile(r"顿悟：连接了\s*(\d+)\s*与\s*(\d+)")
_ANCHOR_RE = re.compile(r"锚点\s*(\d+)\s*被点亮")
_NEWNODE_RE = re.compile(r"建立新记忆节点\s*(\d+)")

_node_memories = {}          # node_id -> deque[{t, text, kind}]
_memory_lock = threading.Lock()
# 百科全书的三本账：真·DeepSeek 答的 / 本地降级 / 命中教学缓存（没花新钱）。
# 计数点在 ask_deepseek 内部 —— 早期只有 /api/teach 会记账，逐字教学
# 走的是同一个函数却从不计数，于是面板上 "DeepSeek 解答" 永远是 0。
_source_stats = {"deepseek": 0, "local": 0, "cached": 0}
_MEM_KEEP = 8                # 每个节点最多留 8 条，够看懂它的"履历"
_last_seen_thought = ""


# ===========================================================================
# 输入口分离与注意力抢占（Interrupt Priority）
#
# 三条输入通道抢同一个大脑。过去的做法是谁先到谁喂 —— 你正在聊天框里教她，
# 后台读书线程还在一个字一个字往里塞，两股特征流撞在一起，她谁也记不清。
#
# 规则只有一条：同一时刻只有一条通道能推进。优先级从高到低：
#   chat   (1) 外部对话 —— 聊天框里你敲的字。一来就掀桌子。
#   oracle (2) 百科解答 —— 某个字/某句话正等着 DeepSeek 回话。
#   learn  (3) 学习输入 —— Input_Files 的自动/手动投喂。
#
# 抢占不是杀线程，是挂起：char_loop 每轮开头问一句 learn_ready()，不 ready
# 就 sleep(0.15) 让路，绝不 spin。对话结束后不是立刻恢复，而是 resume_at
# 再等 2~3 秒 —— 让她把最后一句呓语说完，这就是「等 G 模块输出完毕再恢复」
# 的落地方式。恢复后还有一段 ramp，前几个字的间隔加倍，避免一开闸就洪水。
# ===========================================================================
LANE_CHAT = "chat"
LANE_ORACLE = "oracle"
LANE_LEARN = "learn"
LANE_PRIO = {LANE_CHAT: 1, LANE_ORACLE: 2, LANE_LEARN: 3}
LANE_ORDER = (LANE_CHAT, LANE_ORACLE, LANE_LEARN)
LANE_TITLE = {LANE_CHAT: u"外部对话", LANE_ORACLE: u"百科解答", LANE_LEARN: u"学习输入"}
LANE_DESC = {
    LANE_CHAT: u"聊天框里你敲的字。一来就抢走全部注意力。",
    LANE_ORACLE: u"等 DeepSeek 回话的那一次求知。学习通道必须让路。",
    LANE_LEARN: u"Input_Files 的自动/手动投喂。前两个都闲着才轮得到它。",
}

RESUME_DELAY_CHAT = 2.6      # 对话结束后隔多久才允许学习恢复（用户要 2~3 秒）
RESUME_DELAY_ORACLE = 0.3    # 一次求知只让半个呼吸 —— 每个字都等 2.6 秒会把她饿死
LEARN_RAMP = 3.0             # 恢复后的起步缓坡时长
LEARN_RAMP_MUL = 1.8         # 缓坡期间的间隔倍数

_ARB_LOCK = threading.RLock()
_arb = {
    "busy": {LANE_CHAT: 0, LANE_ORACLE: 0, LANE_LEARN: 0},
    "since": {LANE_CHAT: 0.0, LANE_ORACLE: 0.0, LANE_LEARN: 0.0},
    "last": {LANE_CHAT: 0.0, LANE_ORACLE: 0.0, LANE_LEARN: 0.0},
    "count": {LANE_CHAT: 0, LANE_ORACLE: 0, LANE_LEARN: 0},
    "preempted": "",          # 最近一次被谁抢走
    "resume_at": 0.0,         # 学习通道最早恢复时刻
    "ramp_until": 0.0,        # 缓坡截止
    "event": {"t": 0.0, "kind": "", "lane": "", "text": ""},
    "focus_id": None,         # 星云里正在被对话点亮的节点
    "focus_at": 0.0,
    "focus_ttl": 0.0,
    "focus_note": "",
}


def _arb_event(kind, lane="", text=""):
    _arb["event"] = {"t": round(time.time(), 3), "kind": kind,
                     "lane": lane, "text": str(text)[:80]}


def _arb_enter(name, resume_delay=None):
    """占住一条通道。返回实际使用的延迟，供 _arb_exit 对齐。"""
    delay = RESUME_DELAY_CHAT if resume_delay is None else float(resume_delay)
    now = time.time()
    with _ARB_LOCK:
        busy = _arb["busy"]
        others = [l for l in LANE_ORDER if busy[l] > 0 and l != name]
        busy[name] += 1
        _arb["count"][name] += 1
        _arb["since"][name] = now
        if others and min(LANE_PRIO[l] for l in others) > LANE_PRIO[name]:
            low = sorted(others, key=lambda x: LANE_PRIO[x])
            _arb["preempted"] = u"、".join(LANE_TITLE[l] for l in low)
            _arb_event("preempt", name,
                       u"%s 抢占，%s 挂起" % (LANE_TITLE[name], _arb["preempted"]))
    return delay


def _arb_exit(name, resume_delay=None):
    delay = RESUME_DELAY_CHAT if resume_delay is None else float(resume_delay)
    now = time.time()
    with _ARB_LOCK:
        busy = _arb["busy"]
        busy[name] = max(0, busy[name] - 1)
        _arb["last"][name] = now
        if busy[name] == 0 and name in (LANE_CHAT, LANE_ORACLE) and delay > 0.0:
            _arb["resume_at"] = max(_arb["resume_at"], now + delay)
            if name == LANE_CHAT:
                # 只有对话结束才给缓坡。oracle 每学一个字都要进出一次，
                # 若也触发缓坡，学习间隔会被永久乘 1.8，等于把她饿成半速。
                _arb["ramp_until"] = max(_arb["ramp_until"], now + delay + LEARN_RAMP)
                _arb_event("release", name,
                           u"对话结束，%.1f 秒后平滑恢复学习" % delay)
            else:
                _arb_event("release", name, u"百科答完了，学习通道放行")


@contextlib.contextmanager
def lane(name, resume_delay=None):
    d = _arb_enter(name, resume_delay)
    try:
        yield d
    finally:
        _arb_exit(name, d)


def holder_lane():
    with _ARB_LOCK:
        for l in LANE_ORDER:
            if _arb["busy"][l] > 0:
                return l
    return ""


def learn_ready(now=None):
    """学习通道此刻能不能往前走。返回 (bool, 原因)。

    用户 m02583 第四条："优化学习速度，在提问的同时依然可以走学习通道"。
    所以外部对话 / 百科解答占线时**不再冻结学习** —— 只是它们优先占用
    注意力与焦点，学习照常往前爬。只有三条还挡：
      1) 学习通道自己正在忙（避免并发抢同一份输入缓冲）；
      2) 全局都空闲时，才让"刚让出注意力"的恢复倒计时生效。
    """
    now = time.time() if now is None else float(now)
    with _ARB_LOCK:
        busy = _arb["busy"]
        if busy[LANE_LEARN] > 0:
            return False, u"学习通道自己在忙"
        if busy[LANE_CHAT] > 0 or busy[LANE_ORACLE] > 0:
            return True, u""
        left = _arb["resume_at"] - now
        if left > 0.0:
            return False, u"刚让出注意力，%.1f 秒后恢复" % left
    return True, ""


def learn_ramp(now=None):
    """恢复后的缓坡系数：1.8 = 慢一倍起步，1.0 = 正常。"""
    now = time.time() if now is None else float(now)
    with _ARB_LOCK:
        return LEARN_RAMP_MUL if now < _arb["ramp_until"] else 1.0


def arb_hold(seconds=2.0):
    """临时压一下学习通道（抢注意力但不占通道的动作）。"""
    now = time.time()
    with _ARB_LOCK:
        _arb["resume_at"] = max(_arb["resume_at"], now + float(seconds))


def arb_focus(node_id, note="", ttl=6.0):
    """把某个节点顶到星云最亮处 —— 正在被对话/解答指着的那个。"""
    try:
        nid = int(node_id) if node_id is not None else None
    except (TypeError, ValueError):
        nid = None
    if nid is None:
        return
    now = time.time()
    with _ARB_LOCK:
        _arb["focus_id"] = nid
        _arb["focus_at"] = now
        _arb["focus_ttl"] = float(ttl)
        _arb["focus_note"] = str(note or "")[:40]


def arb_snapshot():
    """给前端的三通道面板：谁在占线、谁被挂起、还剩几秒恢复、谁在发光。"""
    now = time.time()
    with _ARB_LOCK:
        busy = dict(_arb["busy"])
        holder = ""
        for l in LANE_ORDER:
            if busy[l] > 0:
                holder = l
                break
        left = max(0.0, _arb["resume_at"] - now)
        ftl = max(0.0, (_arb["focus_at"] + _arb["focus_ttl"]) - now)
        # 单一真源：闸门只由 learn_ready() 判定。
        # 这里以前自己重算一份，改 learn_ready 时会被它覆盖回旧口径。
        ready, why = learn_ready(now)
        hp = LANE_PRIO.get(holder, 9)
        lanes = []
        for l in LANE_ORDER:
            lanes.append({
                "id": l,
                "title": LANE_TITLE[l],
                "prio": LANE_PRIO[l],
                "desc": LANE_DESC[l],
                "busy": busy[l] > 0,
                "count": int(_arb["count"][l]),
                "since": round(_arb["since"][l], 3),
                "last": round(_arb["last"][l], 3),
                "blocked_by": (why if LANE_PRIO[l] > hp else ""),
            })
        return {
            "ok": True,
            "holder": holder,
            "holder_title": LANE_TITLE.get(holder, u"空闲"),
            "preempted": _arb["preempted"],
            "learn_ready": ready,
            "learn_reason": why,
            "resume_in": round(left, 2),
            "ramp": now < _arb["ramp_until"],
            "lanes": lanes,
            "focus": {
                "id": _arb["focus_id"] if ftl > 0 else None,
                "note": _arb["focus_note"],
                "left": round(ftl, 2),
            },
            "event": dict(_arb["event"]),
            "t": round(now, 3),
        }


def _record_thought(text):
    """把一条想法按涉及的节点归档。解析不出节点就丢弃。"""
    if not text:
        return
    ids, kind = [], ""
    m = _CONN_RE.search(text)
    if m:
        ids, kind = [int(m.group(1)), int(m.group(2))], "link"
    else:
        m = _ANCHOR_RE.search(text)
        if m:
            ids, kind = [int(m.group(1))], "anchor"
        else:
            m = _NEWNODE_RE.search(text)
            if m:
                ids, kind = [int(m.group(1))], "birth"
    if not ids:
        return
    now = time.time()
    with _memory_lock:
        for nid in ids:
            dq = _node_memories.get(nid)
            if dq is None:
                dq = collections.deque(maxlen=_MEM_KEEP)
                _node_memories[nid] = dq
            if dq and dq[-1]["text"] == text:
                continue          # 同一条想法只记一次
            dq.append({"t": round(now, 1), "text": text, "kind": kind})


def obs_stats():
    """观测层统计：大脑自己的计数 + 观测台额外关心的分项（不改大脑）。"""
    d = dict(engine.stats)
    d["teach_deepseek"] = _source_stats["deepseek"]
    d["teach_local"] = _source_stats["local"]
    d["teach_cached"] = _source_stats["cached"]
    return d


def node_memories(nid):
    with _memory_lock:
        dq = _node_memories.get(nid)
        return list(dq) if dq else []


# 观测档案落盘：让"这颗星顿悟过什么"能跨重启保留（仍属观测层，不进大脑）
def _obs_path():
    d = getattr(engine, "memory_dir", None)
    return (Path(d) / "observations.json") if d else None


def load_observations():
    p = _obs_path()
    if not p or not p.is_file():
        return
    try:
        doc = json.loads(p.read_text(encoding="utf-8")) or {}
        raw = doc.get("nodes") or {}
        with _memory_lock:
            for k, items in raw.items():
                if isinstance(items, list) and items:
                    _node_memories[int(k)] = collections.deque(
                        items[-_MEM_KEEP:], maxlen=_MEM_KEEP)
        saved = doc.get("source_stats")
        if isinstance(saved, dict):
            _source_stats["deepseek"] = max(0, int(saved.get("deepseek", 0) or 0))
            _source_stats["local"] = max(0, int(saved.get("local", 0) or 0))
            _source_stats["cached"] = max(0, int(saved.get("cached", 0) or 0))
        else:
            # 旧档案还没记分项：没配密钥时，历史上的讲授必然全是本地降级，据实补账。
            _source_stats["local"] = 0 if API_KEY else int(
                getattr(engine, "stats", {}).get("teach", 0))
        log.info(
            "观测档案载入：%d 个节点的顿悟履历；百科全书 %d 次（DeepSeek %d / 本地 %d）",
            len(_node_memories),
            _source_stats["deepseek"] + _source_stats["local"],
            _source_stats["deepseek"], _source_stats["local"])
    except Exception as exc:
        log.warning("观测档案载入失败（忽略）：%s", exc)


def save_observations():
    p = _obs_path()
    if not p:
        return
    try:
        with _memory_lock:
            data = {
                "nodes": {str(k): list(v) for k, v in _node_memories.items()},
                "source_stats": dict(_source_stats),
            }
        tmp = p.with_name(p.name + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp.replace(p)
    except Exception as exc:
        log.warning("观测档案写入失败：%s", exc)


log = logging.getLogger("aha")

# ---------------------------------------------------------------------------
# 真理标定器（System Prompt）
#
# 这段是整个 H 模块的外部锚点：小鱼没有语义，她只能靠"外面有个人说这是苹果"
# 来给一团特征向量打标签。必须硬约束输出格式，否则大模型会回一段话，
# 那段话再被 aha_input 降维成特征向量灌进记忆池 —— 聚类立刻被客套话污染。
# ---------------------------------------------------------------------------
_BRAIN_SYSTEM_PROMPT = (
    "你现在是‘Project Aha（小鱼）’的客观世界百科全书与真理标定器。\n"
    "你的任务是接收小鱼在认知过程中产生的‘特征向量’或‘节点连接’，并给出极简、客观、准确的现实标签。\n"
    "\n"
    "严格遵守以下输出规则：\n"
    "1. 【拒绝废话】：绝对不要使用‘你好’、‘根据你的描述’、‘希望这对你有帮助’等对话客套话。\n"
    "2. 【极简标签】：最多输出 15 个字。直接给出该特征/连接对应的现实物理概念或分类名称。\n"
    "3. 【真值判定】：如果输入的特征明显是某种已知物体（如：红色、圆形、边缘），直接返回最贴近的词语（如：‘苹果’或‘球体’）。如果特征极其混沌、无法分类，返回：‘未知特征’。\n"
    "4. 【错误纠正】：如果小鱼把两个完全不可能产生物理关联的节点连在了一起（比如‘金属’和‘水’连在一起并认为会燃烧），你需要用最严厉的词汇纠正她，返回：‘错误关联’。\n"
    "5. 【安全感反馈】：如果是正确答案，在标签后加上‘[+安全]’；如果是未知或错误，加上‘[-危机]’。\n"
    "\n"
    "示例 1：输入 '红，圆，高亮' -> 输出 '苹果 [+安全]'\n"
    "示例 2：输入 '尖锐，刺耳，黑色' -> 输出 '噪音 [-危机]'\n"
    "示例 3：输入 '木头的质感 + 水的流动性' -> 输出 '物理不相容 [-危机]'\n"
    "\n"
    "只输出那一行结果本身，不要解释、不要换行、不要加任何前后缀。"
)

_TRUTH_SAFE = "[+安全]"
_TRUTH_CRISIS = "[-危机]"


def parse_truth_label(answer):
    """把真理标定器的回答拆成 (极简标签, verdict)。

    verdict ∈ {"safe", "crisis", "unknown"}
      [+安全] → safe      现实对得上，H 模块进账（安全感 +）
      [-危机] → crisis    未知或错得离谱，H 模块支出（危机感 +）
      都没有   → unknown   模型没守格式，按"未标定"处理：给一点点安慰，不奖不罚
    """
    if not answer:
        return "", "unknown"
    text = str(answer).strip()
    verdict = "unknown"
    # 模型偶尔会换全角括号/中文括号，三种都认
    for tok in (_TRUTH_SAFE, "【+安全】", "（+安全）"):
        if tok in text:
            verdict = "safe"
            text = text.replace(tok, "")
            break
    if verdict == "unknown":
        for tok in (_TRUTH_CRISIS, "【-危机】", "（-危机）"):
            if tok in text:
                verdict = "crisis"
                text = text.replace(tok, "")
                break
    # 兜底：没带标签但语义就是"判不了/判错了"
    for ch in ("「", "」", "『", "』", "“", "”", "‘", "’", "\"", "'"):
        text = text.replace(ch, "")
    text = " ".join(text.split())
    if verdict == "unknown" and text in ("未知特征", "错误关联", "物理不相容", "未知", "无法分类"):
        verdict = "crisis"
    if not text:
        text = "未知特征"
    if len(text) > 15:
        text = text[:15]
    return text, verdict


def load_config():
    """读 Memory_Core/config.json（可放 deepseek_api_key / model / host / port）。"""
    if CONFIG_FILE.is_file():
        try:
            return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        except Exception as exc:
            log.warning("config.json 解析失败，用默认值: %r", exc)
    return {}


def resolve_api_key(cfg):
    """优先环境变量，其次配置文件。都没有就返回 None（进入本地降级模式）。"""
    import os
    key = (os.environ.get("DEEPSEEK_API_KEY") or cfg.get("deepseek_api_key") or "").strip()
    return key or None


# ---------------------------------------------------------------------------
# 全局单例
# ---------------------------------------------------------------------------

engine = AhaEngine(persist=True)
eye = AhaInput(text_mode=True)
eye.round_cooldown = CHAR_ROUND_PAUSE

CFG = load_config()
API_KEY = resolve_api_key(CFG)
MODEL_NAME = CFG.get("deepseek_model", "deepseek-chat")
# 允许换端点：官方留空即可；第三方 OpenAI 兼容中转站填 https://xxx/v1
_DEEPSEEK_BASE = (CFG.get("deepseek_base") or DEFAULT_DEEPSEEK_BASE).rstrip("/")

_stop_event = threading.Event()
_last_feed = 0.0
_last_save = time.time()
_last_cpu = 0.0
_last_error = {"at": 0.0, "where": "", "detail": ""}
# 最近一次 DeepSeek 的 HTTP 失败（401 之类是配置问题，不该混进 last_error，又必须让人看得见）
_last_http = {"at": 0.0, "code": 0, "detail": ""}

# --- 逐字教学的状态（只给观测用，不参与认知）---
_char_cache = {}          # 汉字 -> (label, verdict)。同一个字只问一次。
_char_stats = {"fed": 0, "asked": 0, "cached": 0, "offline": 0, "errors": 0}
_last_char = {"glyph": "", "label": "", "verdict": "", "at": 0.0, "source": ""}

# --- 投喂控制台的状态（只管节奏，不碰认知）---
# paused: 人工暂停投喂，char_loop 让路（大脑照常心跳）
# burst : "一键全部投喂"——跳过轮间冷却，把这一轮剩下的文件读完就自动收工
_feed = {
    "paused": False,
    "burst": False,
    "burst_base": 0,       # 按下按钮时的 eye.rounds_done，用来判断"这一轮真的读完了"
    "burst_at": 0.0,
}
_feed_cache = {"at": 0.0, "data": {}}


def feed_snapshot():
    """投喂控制台要的全部数字。1 秒缓存 —— WS 是 10Hz，不能每帧去列目录。"""
    now = time.time()
    if now - _feed_cache["at"] < 1.0 and _feed_cache["data"]:
        try:
            prog = dict(eye.round_progress())
        except Exception:
            prog = {}
        snap = dict(_feed_cache["data"])
        snap["current"] = prog.get("current", snap.get("current", ""))
        snap["rounds_done"] = prog.get("rounds_done", snap.get("rounds_done", 0))
        snap["chars_fed"] = prog.get("chars_fed", snap.get("chars_fed", 0))
        snap["text_files_read"] = prog.get("text_files_read", snap.get("text_files_read", 0))
        return snap
    try:
        prog = eye.round_progress()
    except Exception:
        prog = {}
    with _ENGINE_LOCK:
        sleeping = bool(getattr(engine, "sleeping", False))
        paused = bool(getattr(engine, "paused", False))
    data = {
        "ok": True,
        "total": int(prog.get("total", 0)),
        "read": int(prog.get("read", 0)),
        "left": int(prog.get("left", 0)),
        "rounds_done": int(prog.get("rounds_done", 0)),
        "current": prog.get("current", ""),
        "chars_fed": int(prog.get("chars_fed", 0)),
        "text_files_read": int(prog.get("text_files_read", 0)),
        "paused": bool(_feed["paused"]),
        "burst": bool(_feed["burst"]),
        "sleeping": sleeping,
        "engine_paused": paused,
        "chars": dict(_char_stats),
        "dir": str(getattr(eye, "root", "")),
        "hold": bool(prog.get("hold", False)),
        "hold_reason": str(prog.get("hold_reason", "") or ""),
        "hold_file": str(prog.get("hold_file", "") or ""),
        "forced": str(prog.get("forced", "") or ""),
        "t": now,
    }
    _feed_cache["at"] = now
    _feed_cache["data"] = data
    return dict(data)


def _stop_burst(reason=""):
    if _feed["burst"]:
        _feed["burst"] = False
        _feed_cache["at"] = 0.0
        if reason:
            log.info("一键投喂收工：%s", reason)
            try:
                engine.speak(text="呓语：这叠纸读完了。" + reason)
            except Exception:
                pass


def record_error(where, exc):
    """把异常钉在墙上，而不是让线程静默死掉。"""
    global _last_error
    _last_error = {
        "at": time.time(),
        "where": where,
        "detail": "".join(traceback.format_exception_only(type(exc), exc)).strip(),
    }
    log.error("[%s] %s", where, _last_error["detail"])
    log.debug("%s", traceback.format_exc())


# ---------------------------------------------------------------------------
# DeepSeek 调用（标准库实现，不引入 httpx/requests）
# ---------------------------------------------------------------------------


def ask_deepseek(question, count=True, system=None):
    """返回 (answer_text, source)。source ∈ {"deepseek", "local"}。

    绝不抛异常：网络/密钥/解析任何一环出问题，都降级成本地回声。

    count=True 时把这次调用记进 _source_stats（面板上那三本账）。
    体检接口 /api/test_deepseek 传 False —— 探路不该算进"她学了多少"。

    system 默认是真理标定器（查字典/盖章）；外部真理场裁决黑箱关联时
    换成 SUP_SYSTEM（只判两个概念有没有关系）。
    """
    if not API_KEY:
        if count:
            _source_stats["local"] += 1
        return (
            "（百科全书还没接上：在 Memory_Core/config.json 里填 deepseek_api_key，"
            "或设置环境变量 DEEPSEEK_API_KEY，小鱼就能听懂更多了。）",
            "local",
        )

    body = {
        "model": MODEL_NAME,
        "messages": [
            {"role": "system", "content": system or _BRAIN_SYSTEM_PROMPT},
            {"role": "user", "content": question},
        ],
        # 真理标定器要的是确定性，不是文采：温度压低、长度卡死。
        # max_tokens 64 足够 15 个汉字 + 6 字符标签，超了说明模型在跑题。
        "temperature": 0.1,
        "max_tokens": 64,
        "stream": False,
    }
    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        _DEEPSEEK_BASE + "/chat/completions",
        data=data,
        headers={
            "Content-Type": "application/json",
            "Authorization": "Bearer " + API_KEY,
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=DEEPSEEK_TIMEOUT) as resp:
            payload = json.loads(resp.read().decode("utf-8", errors="replace"))
        answer = payload["choices"][0]["message"]["content"]
        if not answer or not answer.strip():
            raise ValueError("empty answer")
        if count:
            _source_stats["deepseek"] += 1
        return answer.strip(), "deepseek"
    except urllib.error.HTTPError as exc:
        detail = ""
        try:
            detail = exc.read().decode("utf-8", errors="replace")[:300]
        except Exception:
            pass
        log.warning("DeepSeek HTTP %s: %s", exc.code, detail)
        global _last_http
        _last_http = {"at": time.time(), "code": int(exc.code), "detail": detail[:300]}
        if count:
            _source_stats["local"] += 1
        return "（百科全书今天有点吵，小鱼只听见了杂音。）", "local"
    except Exception as exc:
        record_error("deepseek", exc)
        if count:
            _source_stats["local"] += 1
        return "（信号没传出去，小鱼自己安静地想了想。）", "local"


# ---------------------------------------------------------------------------
# 生命主循环（独立线程，绝不阻塞事件循环）
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 系统硬件监控（不依赖 psutil，直接打 Win32 API）
# ---------------------------------------------------------------------------


def _process_mem_mb():
    """当前进程的工作集（WorkingSetSize），MB。

    必须显式声明 argtypes/restype：ctypes.windll 默认把返回值当 32 位 int，
    GetCurrentProcess() 返回的伪句柄会被截断，GetProcessMemoryInfo 直接失败。
    （踩过一次：面板常驻 0.0 MB。）

    用 psapi.GetProcessMemoryInfo；拿不到时退回 /proc/self/statm。
    监控面板宁可显示 0，也不能因为缺库把 /api/system 打成 500。
    """
    try:
        import ctypes
        from ctypes import wintypes

        class PMC(ctypes.Structure):
            _fields_ = [
                ("cb", wintypes.DWORD),
                ("PageFaultCount", wintypes.DWORD),
                ("PeakWorkingSetSize", ctypes.c_size_t),
                ("WorkingSetSize", ctypes.c_size_t),
                ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                ("PagefileUsage", ctypes.c_size_t),
                ("PeakPagefileUsage", ctypes.c_size_t),
            ]

        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.GetCurrentProcess.restype = ctypes.c_void_p
        handle = k32.GetCurrentProcess()

        fn = getattr(k32, "GetProcessMemoryInfo", None)
        if fn is None:
            fn = ctypes.WinDLL("psapi", use_last_error=True).GetProcessMemoryInfo
        fn.argtypes = [ctypes.c_void_p, ctypes.POINTER(PMC), wintypes.DWORD]
        fn.restype = wintypes.BOOL

        info = PMC()
        info.cb = ctypes.sizeof(info)
        if fn(handle, ctypes.byref(info), info.cb):
            return info.WorkingSetSize / (1024.0 * 1024.0)
    except Exception:
        pass
    try:
        pages = int(Path("/proc/self/statm").read_text().split()[1])
        return pages * 4096.0 / (1024.0 * 1024.0)
    except Exception:
        return 0.0


_CPU_SAMPLE = {"prev": None, "value": 0.0}


def _system_cpu_pct():
    """整机 CPU 占用率。GetSystemTimes 做两次差分。

    由 life_loop 每秒刷一次缓存，/api/system 只读缓存 —— 端点不能被
    系统调用阻塞，也不能每次都因为没有上一次采样而返回 0。
    """
    try:
        import ctypes

        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        fn = k32.GetSystemTimes
        fn.argtypes = [
            ctypes.POINTER(ctypes.c_ulonglong),
            ctypes.POINTER(ctypes.c_ulonglong),
            ctypes.POINTER(ctypes.c_ulonglong),
        ]
        fn.restype = ctypes.c_int

        idle = ctypes.c_ulonglong()
        kernel = ctypes.c_ulonglong()
        user = ctypes.c_ulonglong()
        if not fn(ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user)):
            return _CPU_SAMPLE["value"]
        cur = (idle.value, kernel.value, user.value)
    except Exception:
        return _CPU_SAMPLE["value"]

    prev = _CPU_SAMPLE["prev"]
    _CPU_SAMPLE["prev"] = cur
    if prev is None:
        return _CPU_SAMPLE["value"]
    idle_d = cur[0] - prev[0]
    total_d = (cur[1] - prev[1]) + (cur[2] - prev[2])   # kernel 已含 idle
    if total_d <= 0:
        return _CPU_SAMPLE["value"]
    pct = max(0.0, min(100.0, (total_d - idle_d) / total_d * 100.0))
    _CPU_SAMPLE["value"] = pct
    return pct


def _dir_size_mb(path):
    total = 0
    try:
        for p in Path(path).rglob("*"):
            try:
                if p.is_file():
                    total += p.stat().st_size
            except OSError:
                continue
    except Exception:
        pass
    return total / (1024.0 * 1024.0)


def life_loop():
    """小鱼的呼吸：滴答 → 偶尔喂一口 → 定期存档。

    注意这里的 try/except 不是可选的。任何一次 tick 抛出未捕获异常，
    这个线程就死了，前端会永久定格在同一帧 —— 那就是"后端死锁"。
    """
    global _last_feed, _last_save, _last_seen_thought, _last_cpu
    log.info("生命主循环启动 (%.0fHz)", TICK_HZ)
    backoff = 0.0

    while not _stop_event.is_set():
        loop_start = time.time()
        try:
            now = loop_start
            with _ENGINE_LOCK:
                engine.tick(TICK_DT, now=now)

            # 喂食已经搬到 char_loop（逐字读文本 + 问百科全书）。
            # 这条线程只管心跳：tick / 存档 / 呓语出闸。网络 IO 一律不许进来，
            # 否则一次二十几秒的请求超时就会把整个天文台冻住。

            # CPU 采样在后台线程里持续刷新，端点只读缓存
            if now - _last_cpu >= 1.0:
                _last_cpu = now
                try:
                    _system_cpu_pct()
                except Exception:
                    pass

            if now - _last_save >= SAVE_INTERVAL:
                _last_save = now
                try:
                    engine.save_state()
                    save_observations()
                except Exception as exc:
                    record_error("save_state", exc)

            # 观测层旁路：想法一变就按节点归档（不影响大脑，纯记账）
            thought = getattr(engine, "last_thought", "") or ""
            if thought != _last_seen_thought:
                _last_seen_thought = thought
                _record_thought(thought)

            # G 模块：呓语出闸。drain_speech 只在引擎锁内做一次 list 拷贝，
            # print 在锁外执行 —— 缓慢的 stdout（管道写满 / 控制台卡住）
            # 绝不能占着引擎锁，否则 10Hz 心跳和 WebSocket 会被终端一起拖死。
            for line in engine.drain_speech():
                try:
                    print(line, flush=True)
                except Exception:
                    pass

            backoff = 0.0

        except Exception as exc:
            # 退避重试：连爆也不要空转把 CPU 烧穿
            record_error("life_loop", exc)
            backoff = min(2.0, (backoff or 0.05) * 2)
            log.warning("主循环异常，%.2fs 后重试", backoff)
            time.sleep(backoff)
            continue

        # 对齐到 10Hz，避免 sleep 漂移累积
        elapsed = time.time() - loop_start
        time.sleep(max(0.0, TICK_DT - elapsed))

    log.info("生命主循环停止")


def start_life_loop():
    t = threading.Thread(target=life_loop, name="aha-life", daemon=True)
    t.start()
    return t


# ---------------------------------------------------------------------------
# 外部真理场：黑箱关联的异步裁决（用户 m04766）
#
# 「严禁控制性代码」的落法：这一层只往引擎里灌势能（apply_supervise），
# 从不下指令。关掉（场强 0）时引擎自己就把队列清空、物理量自然归零，
# 这里也只是不再发请求 —— 没有任何一条行为是被 if 出来的。
# ---------------------------------------------------------------------------

SUP_SYSTEM = (
    "你是小鱼的外部真理场。她刚从潜意识里把两个概念撞在了一起，"
    "你只做一件事：判断这两个概念在常识里是不是真有关系。\n"
    "有真实关系 -> 输出一行：有关系 [+安全]\n"
    "没关系、或者只是牵强附会 -> 输出一行：没关系 [-危机]\n"
    "只输出那一行本身，不要解释、不要换行、不要加任何前后缀。"
)
SUP_QUESTION = u"「%s」和「%s」有关系吗？"
SUP_INTERVAL = 1.2        # 两次裁决之间的最短间隔（省额度，也给她时间消化）
SUP_BATCH = 2             # 一轮最多取几条候选
SUP_ANSWER_MAX = 48

_sup_stats = {
    "asked": 0, "safe": 0, "crisis": 0, "skip": 0, "errors": 0,
    "last": {"at": 0.0, "a": "", "b": "", "verdict": "", "answer": ""},
}


def parse_supervise(answer):
    """把裁决回话压成 safe / crisis / ""（说不清就不裁决）。

    刻意比 parse_truth_label 保守：模糊回答不去削弱她的联想 ——
    「没听懂」不等于「判错了」，把两者混为一谈会让她越学越孤僻。
    """
    t = str(answer or "").strip()
    if not t:
        return ""
    flat = t.replace(" ", "").replace(u"\u3000", "")
    if (u"+安全" in flat) or (u"＋安全" in flat):
        return "safe"
    for bad in (u"-危机", u"－危机", u"没关系", u"无关", u"不成立", u"错误关联"):
        if bad in flat:
            return "crisis"
    return ""


def supervise_loop():
    """后台线程：把黑箱候选交出去裁决，回来的结论只调质权重。"""
    time.sleep(3.0)
    while not _stop_event.is_set():
        try:
            with _ENGINE_LOCK:
                enabled = float(getattr(engine, "llm_supervise", 1.0)) > 0.0
                paused = bool(getattr(engine, "paused", False))
            if not enabled or paused:
                time.sleep(0.6)
                continue
            # 用户对话 / 百科解答占线时让路 —— 不跟最高优先级抢带宽。
            if holder_lane():
                time.sleep(0.3)
                continue
            batch = engine.drain_supervise(SUP_BATCH)
            if not batch:
                time.sleep(0.4)
                continue
            for a_id, b_id, _t in batch:
                with _ENGINE_LOCK:
                    na = engine.nodes.get(a_id)
                    nb = engine.nodes.get(b_id)
                if na is None or nb is None:
                    continue
                la, lb = engine._plain(na), engine._plain(nb)
                try:
                    with lane(LANE_ORACLE, RESUME_DELAY_ORACLE):
                        answer, source = ask_deepseek(
                            SUP_QUESTION % (la, lb), count=True, system=SUP_SYSTEM)
                except Exception as exc:
                    record_error("supervise", exc)
                    _sup_stats["errors"] += 1
                    time.sleep(SUP_INTERVAL)
                    continue
                if source != "deepseek":
                    _sup_stats["errors"] += 1
                    time.sleep(SUP_INTERVAL * 2.0)
                    continue
                verdict = parse_supervise(answer)
                _sup_stats["asked"] += 1
                _sup_stats["last"] = {
                    "at": round(time.time(), 2), "a": la, "b": lb,
                    "verdict": verdict, "answer": str(answer)[:SUP_ANSWER_MAX],
                }
                if verdict == "safe":
                    _sup_stats["safe"] += 1
                elif verdict == "crisis":
                    _sup_stats["crisis"] += 1
                else:
                    _sup_stats["skip"] += 1
                if verdict:
                    res = engine.apply_supervise(a_id, b_id, verdict)
                    if res:
                        log.info("  监督: %s <-> %s -> %s (w=%.2f)",
                                 la, lb, verdict, res.get("w") or 0.0)
                time.sleep(SUP_INTERVAL)
        except Exception as exc:
            record_error("supervise_loop", exc)
            time.sleep(1.0)


def start_supervise_loop():
    t = threading.Thread(target=supervise_loop, name="aha-supervise", daemon=True)
    t.start()
    return t


# ---------------------------------------------------------------------------
# 中文文本模式：一个字一个字地教
# ---------------------------------------------------------------------------


def teach_char(glyph):
    """把一个汉字交给百科全书，换一个极简标签回来。

    返回 (label, verdict, online)；没接上就 (None, "offline", False)。

    同一个字只问一次 —— _char_cache 命中就直接复用。一本书从头读第二遍时
    所有字都已经认识，这是"记忆"，不是重复计费。
    """
    hit = _char_cache.get(glyph)
    if hit is not None:
        _char_stats["cached"] += 1
        _source_stats["cached"] += 1
        return hit[0], hit[1], True

    # 外部真理场强度为零时不再查字典：字照样建节点，只是没有标签。
    # 这是「要不要发起网络请求」的成本门 —— 学习本身从来没有被拦住。
    if float(getattr(engine, "llm_supervise", 1.0)) <= 0.0:
        _char_stats["offline"] += 1
        return None, "offline", False

    try:
        # 百科解答是次高优先级：这一问没回来之前，学习通道必须等着（见 lane()）
        with lane(LANE_ORACLE, RESUME_DELAY_ORACLE):
            answer, source = ask_deepseek("这个汉字：%s" % glyph)
    except Exception as exc:
        record_error("teach_char", exc)
        _char_stats["errors"] += 1
        return None, "offline", False

    if source != "deepseek":
        _char_stats["offline"] += 1
        return None, "offline", False

    _char_stats["asked"] += 1
    try:
        label, verdict = parse_truth_label(answer)
    except Exception as exc:
        record_error("parse_truth_label", exc)
        _char_stats["errors"] += 1
        return None, "offline", False
    label = (label or "").strip() or None
    if label is not None:
        if len(_char_cache) >= CHAR_CACHE_MAX:
            # 缓存不是记忆，满了就整体丢掉重学。真正的记忆在节点上。
            _char_cache.clear()
        _char_cache[glyph] = (label, verdict)
    return label, verdict, True


def warm_char_cache():
    """把大脑里已经认过的字回填进教学缓存。

    重启后 _char_cache 是空的。若不回填，char_loop 会把每个字重新问一遍
    DeepSeek —— 同样的答案，花同样的钱。记忆已经写在节点上了，读回来就是。
    """
    n = 0
    try:
        with _ENGINE_LOCK:
            for node in engine.nodes.values():
                g = getattr(node, "glyph", None)
                m = getattr(node, "meaning", None)
                if g and m and g not in _char_cache:
                    _char_cache[g] = (m, node.verdict or "safe")
                    n += 1
    except Exception as exc:
        record_error("warm_char_cache", exc)
    if n:
        log.info("  认过的字: %d 个（教学缓存已回填，不再重复提问）", n)
    return n


def _unit_for_glyph(glyph):
    """给聊天里碰到的生字临时扎一个输入单元（和 eye.next_char() 返回同构）。"""
    return {
        "kind": "char",
        "glyph": glyph,
        "feature": extract_char_feature(glyph),
        "path": "",
        "name": "<chat>",
        "index": 0,
    }


def _learn_unknown_in_text(text, limit=6):
    """对话里碰到的生字：**先教、后答**（用户 m02583 第二条）。

    以前只挑一个生字丢到后台线程，等下次聊天它才可能变成节点 ——
    用户实测「你好」「自己」说完一遍，星云里还是空的，因为那一轮
    compose_reply 跑在她还不认识这些字的时候。

    现在改成同步：把她不认识的实词字逐个 teach_char（查字典盖章）
    -> feed_char（变成节点），全部落进星云之后再拼话。
    上限 limit 个字，防止一句长文瞬间烧掉一串 API 额度。
    """
    learned = []
    text = str(text or "")
    if not text:
        return learned
    try:
        with _ENGINE_LOCK:
            idx = engine._glyph_index()
            weak = engine._WEAK_CHARS
        known = set(g for g in idx.keys() if g)
    except Exception as exc:
        record_error("chat_learn_scan", exc)
        return learned

    cand = []
    for ch in text:
        if not (u"\u4e00" <= ch <= u"\u9fff"):
            continue
        if ch in weak or ch in known or ch in cand:
            continue
        cand.append(ch)
        if len(cand) >= max(1, int(limit)):
            break

    for glyph in cand:
        try:
            label, verdict, online = teach_char(glyph)
            if not online or not label:
                continue
            unit = _unit_for_glyph(glyph)
            with _ENGINE_LOCK:
                res = eye.feed_char(engine, unit, meaning=label, verdict=verdict)
                node_id = (res or {}).get("node_id")
                try:
                    if verdict == "safe":
                        engine.receive_reassurance(0.6)
                    elif verdict == "crisis":
                        engine.receive_threat(0.6)
                except Exception:
                    pass
                try:
                    engine.stats["teach"] += 1
                except Exception:
                    pass
                try:
                    engine.speak(
                        text=u"呓语：我去字典里查了「%s」，它原来是「%s」。" % (glyph, label),
                        kind="learn", ids=[node_id] if node_id else [])
                except Exception:
                    pass
                _last_char.update({
                    "glyph": glyph, "pinyin": "", "label": label, "verdict": verdict,
                    "at": time.time(), "source": "deepseek",
                })
                _char_stats["fed"] += 1
            # 只有真的进了图才算「学会了」。脱敏 / 没建出节点 / 异常都不算 ——
            # 以前这里无条件 append，于是 learned 声称学会了、_glyph_index 里却没有它，
            # 同一句的 compose_reply 只能退回度数最高的虚词（实测答成「你 → 低、风、写」）。
            _ev = (res or {}).get("event") or ""
            if node_id and _ev in ("new_node", "recall"):
                learned.append(glyph)
                log.info("  对话里认得新字: %s -> %s (%s)", glyph, label, verdict)
            else:
                log.warning("  对话里没能认下新字: %s -> %s (event=%s)", glyph, label, _ev or "?")
        except Exception as exc:
            record_error("chat_learn", exc)
    return learned


def _lookup_in_background(glyph):
    """大模型的**唯一**职责：查字典、盖个标签。

    用户 m02206 明确：绝不调用大模型生成对话文本，她的每一句话都必须
    来自内部图网络的节点拼接。所以这里只做 teach_char -> feed_char 的
    "盖章"动作 —— 查完她多一个带 meaning 的节点，下次就能自己把话说出来。

    现在它只是**兜底**：_learn_unknown_in_text 已经在对话里同步学了一轮，
    只有超出上限或当时 API 失败的漏网之字，才走这条后台补刀。
    """
    if not glyph or not API_KEY:
        return
    try:
        # Chat 是最高优先级，字典查询只能在它后面排队
        t0 = time.time()
        while time.time() - t0 < 5.0:
            if holder_lane() is None:
                break
            time.sleep(0.1)
        label, verdict, online = teach_char(glyph)
        if not online or not label:
            return
        unit = _unit_for_glyph(glyph)
        with _ENGINE_LOCK:
            res = eye.feed_char(engine, unit, meaning=label, verdict=verdict)
            node_id = (res or {}).get("node_id")
            try:
                if verdict == "safe":
                    engine.receive_reassurance(0.6)
                elif verdict == "crisis":
                    engine.receive_threat(0.6)
            except Exception:
                pass
            try:
                engine.stats["teach"] += 1
            except Exception:
                pass
            try:
                engine.speak(
                    text=u"呓语：我去字典里查了「%s」，它原来是「%s」。" % (glyph, label),
                    kind="learn", ids=[node_id] if node_id else [])
            except Exception:
                pass
            _last_char.update({
                "glyph": glyph, "pinyin": "", "label": label, "verdict": verdict,
                "at": time.time(), "source": "deepseek",
            })
            _char_stats["fed"] += 1
        log.info("  查字典: %s -> %s (%s)", glyph, label, verdict)
    except Exception as exc:
        record_error("chat_lookup", exc)


def char_loop():
    """文本学习循环：逐字读 → 问百科全书 → 喂进大脑。

    为什么单独开一条线程，而不是塞进 life_loop：
    ask_deepseek 是网络 IO，最坏要等二十几秒。放进 10Hz 心跳线程里，
    一次超时就会把整个天文台冻住。心跳归心跳，读书归读书。

    暂停时整个循环让路（和 life_loop 的语义一致）。
    任何异常都不许逃出 while —— 这条线程死掉 = 小鱼不再学习。
    """
    log.info("文本学习循环启动（逐字模式）")
    backoff = 0.0
    prev_glyph = ""        # V4.0：上一个字，用来抽二元组（「江」+「水」-> 江水）
    while not _stop_event.is_set():
        try:
            with _ENGINE_LOCK:
                paused = bool(getattr(engine, "paused", False))
                sleeping = bool(getattr(engine, "sleeping", False))
            if paused:
                time.sleep(0.2)
                continue

            # 生物钟：睡眠态切断所有外部输入。A2 随机游走那边由
            # awake_think 自己挡着，喂字这条线由这里挡 —— 两条都得断，
            # 否则睡着了还在学新字，睡眠只是装样子。
            if sleeping:
                time.sleep(0.25)
                continue

            # 人工暂停投喂：大脑继续心跳，只是不再读新字
            if _feed["paused"]:
                time.sleep(0.25)
                continue

            # 一课上完就停：老师在课程选择器里点了哪一课，读完就收住，
            # 不再自己往后翻 —— 否则 12 课会在没人看着的时候被一口吃光。
            if getattr(eye, "hold", False):
                time.sleep(0.4)
                continue

            # "一键全部投喂"：一轮读完（eye.rounds_done 增加）就自动收工，
            # 不无限循环。不能用 _read_set 判 —— 读完那一刻它就被清空了。
            if _feed["burst"] and eye.rounds_done > _feed["burst_base"]:
                _stop_burst("")

            # 注意力抢占：更高优先级的通道在忙，学习必须挂起。
            # 不是死等 —— 每 150ms 探一次，对话一结束立刻就能接上（还有缓坡）。
            ready, why = learn_ready()
            if not ready:
                time.sleep(0.15)
                continue

            unit = eye.next_char()      # 内部自带锁与异常兜底，绝不抛
            if not unit:
                prev_glyph = ""     # 换课了，上一课最后一个字不参与本课的词
                # 用户 m03927：这一课读完了，把还挂着的句子和段落收掉。
                # 不收的话最后一句话会一直停在 _cur_sent 里，天文台上永远缺最后一段。
                try:
                    with _ENGINE_LOCK:
                        engine.flush_structure()
                except Exception as exc:
                    record_error("flush_structure", exc)
                if _feed["burst"]:
                    # burst 模式不等轮间冷却，把这一轮剩下的读完
                    eye.resume_round()
                    time.sleep(0.05)
                else:
                    time.sleep(1.0)     # Input_Files 空 / 一轮读完在冷却
                continue

            glyph = unit["glyph"]
            label, verdict, online = teach_char(glyph)

            with _ENGINE_LOCK:
                eye.feed_char(engine, unit, meaning=label, verdict=verdict)
                # V4.0 Phase 1-B：课文里相邻的两个字就是词候选。
                # 两个字都得认识、都得是实词、在空间里还得挨得够近，
                # grow_concept 自己会把这些条件全判掉，这里只管递候选。
                if prev_glyph and prev_glyph != glyph and online:
                    try:
                        engine.grow_concept(prev_glyph + glyph)
                    except Exception:
                        pass
                prev_glyph = glyph
                if verdict == "safe":
                    engine.receive_reassurance(0.5)
                    engine.stats["teach_safe"] = engine.stats.get("teach_safe", 0) + 1
                elif verdict == "crisis":
                    engine.receive_threat(0.5)
                    engine.stats["teach_crisis"] = engine.stats.get("teach_crisis", 0) + 1
                if online:
                    engine.stats["teach"] = engine.stats.get("teach", 0) + 1

            _char_stats["fed"] += 1
            _last_char.update({
                "glyph": glyph,
                # 课程里标的读音，跟着这一次投喂一起上屏
                "pinyin": (unit.get("pinyin") or "") if unit else "",
                "label": label or "",
                "verdict": verdict or "",
                "source": "deepseek" if online else "offline",
                "at": round(time.time(), 3),
            })
            backoff = 0.0
            time.sleep((CHAR_INTERVAL if online else CHAR_INTERVAL_OFFLINE)
                       * learn_ramp())

        except Exception as exc:
            record_error("char_loop", exc)
            _char_stats["errors"] += 1
            backoff = min(5.0, (backoff or 0.2) * 2)
            log.warning("文本学习循环异常，%.2fs 后重试", backoff)
            time.sleep(backoff)


def start_char_loop():
    t = threading.Thread(target=char_loop, name="aha-char", daemon=True)
    t.start()
    return t


# ---------------------------------------------------------------------------
# FastAPI
# ---------------------------------------------------------------------------


app = FastAPI(title="Project Aha 天文台", version="1.0.0")


@app.exception_handler(Exception)
async def _global_exc(request: Request, exc: Exception):
    """兜底：任何没被捕获的异常都返回 JSON，而不是把连接挂死。"""
    record_error("http:" + request.url.path, exc)
    return JSONResponse(
        status_code=500,
        content={"ok": False, "error": _last_error.get("detail", "unknown")},
    )


@app.on_event("startup")
def _on_startup():
    load_observations()
    warm_char_cache()      # 认过的字别再花钱问一遍
    start_life_loop()
    start_char_loop()
    start_supervise_loop()  # 外部真理场：只在她撞出关联时才开口


@app.on_event("shutdown")
def _on_shutdown():
    _stop_event.set()
    try:
        engine.save_state()
        save_observations()
        log.info("记忆已落盘")
    except Exception as exc:
        record_error("shutdown_save", exc)


# --- 前端 -----------------------------------------------------------------


@app.get("/")
def index():
    page = HERE / "index.html"
    if not page.is_file():
        return JSONResponse(status_code=404, content={"error": "index.html 不存在"})
    return FileResponse(str(page), media_type="text/html; charset=utf-8")


@app.get("/favicon.ico")
def favicon():
    # 204 不能带 body：JSONResponse 会塞一个 "{}"，uvicorn 立刻报
    # "Response content longer than Content-Length"，并把它记进 last_error。
    return Response(status_code=204, media_type="image/x-icon")


# --- WebSocket: 10Hz 状态流 -------------------------------------------------


@app.websocket("/ws")
async def ws_stream(websocket: WebSocket):
    await websocket.accept()
    since_node = 0
    since_conn = 0
    since_speech = 0
    try:
        # 首帧给全量（含所有坐标 + 最近 60 条呓语），之后只发增量
        with _ENGINE_LOCK:
            snap = engine.snapshot_full()
            snap["stats"] = obs_stats()           # 观测层附加，不改大脑
            snap["speech"] = engine.recent_speech(0, 60)
            snap["last_char"] = dict(_last_char)  # 正在学哪个字
        snap["feed"] = feed_snapshot()            # 投喂控制台：文件数/已读/剩余
        snap["arb"] = arb_snapshot()              # 三通道仲裁 + 焦点节点
        await websocket.send_text(json.dumps(snap, ensure_ascii=False))
        since_node = max([n[0] for n in snap["nodes"]] or [0])
        since_conn = len(snap["connections"])
        since_speech = snap["speech"][-1]["seq"] if snap["speech"] else 0

        while True:
            frame_start = time.time()
            with _ENGINE_LOCK:
                fr = engine.frame(since_node, since_conn)
                fr["stats"] = obs_stats()             # 观测层附加，不改大脑
            fr["last_char"] = dict(_last_char)        # 观测层：当前在学哪个字
            fr["feed"] = feed_snapshot()              # 投喂控制台（内部 1s 缓存）
            fr["arb"] = arb_snapshot()                # 三通道仲裁（焦点高亮也走这里）
            since_node = fr["max_node_id"]
            since_conn = fr["conn_count"]

            # G 模块增量：只在有新呓语时附带这个字段，安静时不占带宽
            new_sp = engine.recent_speech(since_speech, 40)
            if new_sp:
                fr["speech"] = new_sp
                since_speech = new_sp[-1]["seq"]
            await websocket.send_text(json.dumps(fr, ensure_ascii=False))

            elapsed = time.time() - frame_start
            await asyncio.sleep(max(0.0, TICK_DT - elapsed))

    except WebSocketDisconnect:
        pass
    except Exception as exc:
        # 浏览器正常关页面时底层 websockets 抛的是 ConnectionClosedOK，而非
        # WebSocketDisconnect —— 那是收摊，不是故障，别污染 last_error。
        name = type(exc).__name__
        if "ConnectionClosed" not in name and "Disconnect" not in name:
            record_error("ws", exc)   # 单个客户端出问题只影响它自己
    finally:
        try:
            await websocket.close()
        except Exception:
            pass


# --- 教导 -----------------------------------------------------------------


@app.post("/teach")
def teach(payload: dict):
    """教小鱼一句话。

    三步：
      1. 小鱼"听见"这句话的形状（文本特征 -> learn）
      2. 问 DeepSeek，把小鱼的困惑交给百科全书
      3. 把答案的文本特征也喂进去，并给一次安全感反馈（H 模块）
    """
    text = str((payload or {}).get("text", "")).strip()
    if not text:
        return {"ok": False, "error": "text 不能为空"}
    text = text[:2000]

    # 抢占（最高优先级）：一进来就按住学习通道，松手时再延后 2.6 秒恢复。
    # 用 enter/exit 而不是 with，是为了不打乱下面那一长段 try 的缩进。
    _arb_enter(LANE_CHAT, RESUME_DELAY_CHAT)
    try:
        # 1. 先听见
        with _ENGINE_LOCK:
            heard = eye.feed_text(engine, text)
        # 星云里点亮"她正在听的那颗" —— 这就是「高亮正在对话的节点」
        arb_focus(heard.get("node_id"), u"听到：" + text[:14], ttl=12.0)

        # 2. 问百科全书（网络 IO 必须在锁外，否则一旦超时会冻结整个大脑心跳）
        answer, source = ask_deepseek(text)

        # 3. 真理标定器的裁决：安全 → 安全感进账；危机 → 危机感落账
        #    source=local 说明百科全书没接上，answer 只是一句降级文案 ——
        #    那不是知识，绝不能喂进记忆（否则会固化成一个小鱼"学过的错概念"）。
        online = source == "deepseek"
        label, verdict = parse_truth_label(answer) if online else ("", "offline")

        with _ENGINE_LOCK:
            if online:
                learned = eye.feed_text(engine, answer)
                if verdict == "safe":
                    engine.receive_reassurance(1.0)
                    engine.stats["teach_safe"] += 1
                elif verdict == "crisis":
                    engine.receive_threat(1.0)
                    engine.stats["teach_crisis"] += 1
                else:
                    # 没守格式：她至少听懂了几个字，给一点点安慰，不奖不罚
                    engine.receive_reassurance(0.4)
                engine.stats["teach"] += 1
                # G 模块：外部反馈也要出声。这是她第一次"被人指认"。
                try:
                    if verdict == "safe":
                        engine.speak(kind="reassure", label=label, ids=None)
                    elif verdict == "crisis":
                        engine.speak(kind="threat", label=label, ids=None)
                    else:
                        engine.speak(text="呓语：她说了「%s」，我还不太懂。" % label)
                except Exception:
                    pass
            else:
                learned = {}
        if online and learned.get("node_id"):
            arb_focus(learned["node_id"], u"明白：" + (label or text[:10]), ttl=12.0)

        return {
            "ok": True,
            "source": source,
            "question": text,
            "answer": answer,
            "label": label,
            "verdict": verdict,
            "heard": heard.get("thought", ""),
            "learned": learned.get("thought", ""),
            "thought": engine.last_thought,
            "physio": engine.physiology(),
            "hint": "" if online else (
                "百科全书没接上：这句话她只记住了形状，答案没进记忆。"
                "填好 " + str(CONFIG_FILE) + " 的 deepseek_api_key，再调 POST /api/reload_config。"
            ),
        }
    except Exception as exc:
        record_error("teach", exc)
        return {"ok": False, "error": _last_error["detail"]}
    finally:
        # 松手 -> resume_at = now + 2.6s，等她把这句呓语说完再让学习通道复工
        _arb_exit(LANE_CHAT, RESUME_DELAY_CHAT)


# --- 其他 API --------------------------------------------------------------


@app.post("/api/feed")
def api_feed():
    """手动喂一个字（调试用）。文本模式下不再使用合成噪声。"""
    try:
        with _ENGINE_LOCK:
            sleeping = bool(getattr(engine, "sleeping", False))
        if sleeping:
            return {"ok": True, "input": None,
                    "thought": "她正在深度睡眠，突触在修剪。醒了再喂。",
                    "feed": feed_snapshot(),
                    "physio": engine.physiology()}
        _feed["paused"] = False       # 手动喂一口 = 顺便解除投喂暂停
        # 上课时的「这一课读完了」闸门（hold）会挡住手动投喂。老师单独点一口
        # 不该被「等老师点下一课」拦住 —— 先放开，再取字。
        if getattr(eye, "hold", False):
            try:
                eye.release_hold()
            except Exception as exc:
                record_error("release_hold", exc)
        unit = eye.next_char()
        if not unit:
            try:
                with _ENGINE_LOCK:
                    engine.flush_structure()
            except Exception as exc:
                record_error("flush_structure", exc)
            return {
                "ok": True, "input": None,
                "thought": "Input_Files 里没有可读的 .txt，或者一轮刚读完、正在冷却",
                "feed": feed_snapshot(),
                "physio": engine.physiology(),
            }
        label, verdict, online = teach_char(unit["glyph"])
        with _ENGINE_LOCK:
            res = eye.feed_char(engine, unit, meaning=label, verdict=verdict)
        arb_focus(res.get("node_id"), u"手动投喂：" + unit["glyph"], ttl=6.0)
        return {
            "ok": True,
            "input": {"kind": unit["kind"], "glyph": unit["glyph"],
                      "label": label or "", "verdict": verdict,
                      "source": "deepseek" if online else "offline"},
            "thought": res.get("thought", ""),
            "feed": feed_snapshot(),
            "chars": dict(_char_stats),
            "physio": engine.physiology(),
        }
    except Exception as exc:
        record_error("api_feed", exc)
        return {"ok": False, "error": _last_error["detail"]}


_file_chars = {}


def _file_char_count(path):
    """一个课程 txt 里有多少个汉字（前端显示「这一课几个字」用）。

    按 (size, mtime) 缓存 —— 每次刷新下拉框不该把十几个文件重读一遍。
    """
    key = str(path)
    try:
        st = path.stat()
        sig = (int(st.st_size), int(st.st_mtime))
    except Exception:
        return 0
    hit = _file_chars.get(key)
    if hit and hit[0] == sig:
        return hit[1]
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        text = ""
    lo, hi = chr(0x4E00), chr(0x9FFF)
    n = 0
    for ch in (text or ""):
        if lo <= ch <= hi:
            n += 1
    _file_chars[key] = (sig, n)
    return n


@app.get("/api/files")
def api_files():
    """Input_Files 里的课程清单（给前端课程选择器用）。"""
    try:
        paths = eye.list_text_files()
    except Exception as exc:
        record_error("api_files", exc)
        paths = []
    try:
        read_set = set(getattr(eye, "_read_set", set()))
    except Exception:
        read_set = set()
    cur = str(getattr(eye, "_cur_name", "") or "")
    rows = []
    total_chars = 0
    for p in paths:
        try:
            size = int(p.stat().st_size)
        except Exception:
            size = 0
        n = _file_char_count(p)
        total_chars += n
        rows.append({
            "name": p.name,
            "size": size,
            "chars": n,
            "read": p in read_set,
            "current": p.name == cur,
        })
    return {
        "ok": True,
        "dir": str(getattr(eye, "root", "")),
        "total": len(rows),
        "read": sum(1 for r in rows if r["read"]),
        "chars": total_chars,
        "hold": bool(getattr(eye, "hold", False)),
        "hold_reason": str(getattr(eye, "hold_reason", "") or ""),
        "hold_file": str(getattr(eye, "hold_file", "") or ""),
        "files": rows,
        "feed": feed_snapshot(),
    }


@app.post("/api/feed_file")
async def api_feed_file(request: Request):
    """老师点课：只读这一课，读完自己停住等下一课。"""
    try:
        payload = await request.json()
    except Exception:
        payload = {}
    if not isinstance(payload, dict):
        payload = {}
    name = str(payload.get("name") or "").strip()
    try:
        with _ENGINE_LOCK:
            sleeping = bool(getattr(engine, "sleeping", False))
        if sleeping:
            return {"ok": False, "error": u"她正在深度睡眠，等醒了再上课。",
                    "feed": feed_snapshot()}
        ready, why = learn_ready()
        if not ready:
            return {"ok": False,
                    "error": u"现在轮到更高优先级的通道：%s。等她说完了我再读。" % why,
                    "feed": feed_snapshot(), "arb": arb_snapshot()}
        path, err = eye.select_text_file(name)
        if path is None:
            return {"ok": False, "error": err or u"挑不到这一课",
                    "feed": feed_snapshot()}
        _feed["paused"] = False
        _feed["burst"] = False
        _feed_cache["at"] = 0.0
        log.info("老师点了课：%s", path.name)
        try:
            engine.speak(text=u"呓语：翻开《%s》。" % path.stem)
        except Exception:
            pass
        return {"ok": True, "name": path.name,
                "chars": _file_char_count(path),
                "feed": feed_snapshot(), "arb": arb_snapshot()}
    except Exception as exc:
        record_error("api_feed_file", exc)
        return {"ok": False, "error": _last_error["detail"]}


@app.post("/api/feed_release")
async def api_feed_release():
    """解除「一课一停」的停泊，恢复按文件名顺序轮转。"""
    try:
        eye.release_hold()
    except Exception as exc:
        record_error("api_feed_release", exc)
    _feed_cache["at"] = 0.0
    return {"ok": True, "feed": feed_snapshot()}


@app.get("/api/feed_stats")
def api_feed_stats():
    """投喂控制台：一共多少文件 / 已读多少 / 还剩多少。"""
    try:
        return feed_snapshot()
    except Exception as exc:
        record_error("api_feed_stats", exc)
        return {"ok": False, "error": _last_error["detail"]}


@app.get("/api/arbiter")
def api_arbiter():
    """三通道仲裁的实时快照：谁在占线、谁被挂起、还剩几秒恢复、谁在发光。"""
    try:
        return arb_snapshot()
    except Exception as exc:
        record_error("api_arbiter", exc)
        return {"ok": False, "error": _last_error["detail"]}


@app.post("/api/feed_all")
def api_feed_all():
    """一键全部投喂：跳过轮间冷却，把这一轮剩下的文件读完就自动收工。"""
    try:
        with _ENGINE_LOCK:
            sleeping = bool(getattr(engine, "sleeping", False))
        if sleeping:
            return {"ok": False, "error": "她正在深度睡眠，等醒了再喂。",
                    "feed": feed_snapshot()}
        ready, why = learn_ready()
        if not ready:
            return {"ok": False,
                    "error": u"现在轮到更高优先级的通道：%s。等她说完了我再读。" % why,
                    "feed": feed_snapshot(),
                    "arb": arb_snapshot()}
        _feed["paused"] = False
        _feed["burst"] = True
        try:
            eye.release_hold()      # 一键全投 = 放弃「一课一停」，整轮滚一遍
        except Exception:
            pass
        _feed["burst_base"] = int(getattr(eye, "rounds_done", 0))
        _feed["burst_at"] = time.time()
        eye.resume_round()          # 若正在轮间冷却，立刻开读
        _feed_cache["at"] = 0.0
        try:
            engine.speak(text="呓语：纸都拿来吧，我一张一张看。")
        except Exception:
            pass
        log.info("一键投喂开始（本轮基线 rounds_done=%d）", _feed["burst_base"])
        return {"ok": True, "feed": feed_snapshot(), "arb": arb_snapshot()}
    except Exception as exc:
        record_error("api_feed_all", exc)
        return {"ok": False, "error": _last_error["detail"]}


@app.post("/api/feed_pause")
async def api_feed_pause(request: Request):
    """暂停 / 继续投喂。不影响大脑心跳，只是不再读新字。"""
    try:
        body = {}
        try:
            body = await request.json()
        except Exception:
            body = {}
        want = body.get("paused", None)
        if want is None:
            want = not _feed["paused"]
        _feed["paused"] = bool(want)
        if _feed["paused"]:
            _stop_burst("")
        _feed_cache["at"] = 0.0
        return {"ok": True, "paused": _feed["paused"], "feed": feed_snapshot()}
    except Exception as exc:
        record_error("api_feed_pause", exc)
        return {"ok": False, "error": _last_error["detail"]}


@app.post("/api/chat")
def api_chat(payload: dict):
    """【与小鱼对话】她用自己的图网络拼话回答，大模型只在后台查字典。"""
    text = (payload.get("text") or "").strip()[:500]
    if not text:
        return {"ok": False, "error": u"说点什么吧。"}

    delay = _arb_enter(LANE_CHAT, RESUME_DELAY_CHAT)
    physio = {}
    report = {}
    learned = []
    try:
        # 用户 m02583 第二条：**先学，再答**。
        # 她必须在对话里学会新词，而不是"闪一下就没了"。
        learned = _learn_unknown_in_text(text, limit=6)
        with _ENGINE_LOCK:
            res = engine.compose_reply(text)
            node_id = res.get("topic_id")
            if node_id:
                arb_focus(node_id, u"回答：" + (res.get("reply") or "")[:16], ttl=10.0)
            try:
                engine.stats["chat"] = engine.stats.get("chat", 0) + 1
            except Exception:
                pass
            physio = engine.physiology()
            report = engine.cognitive_report()
    except Exception as exc:
        record_error("chat", exc)
        return {"ok": False, "error": u"她走神了：%s" % exc}
    finally:
        _arb_exit(LANE_CHAT, RESUME_DELAY_CHAT)

    # 还没认出来的那个字：丢给后台补一刀（同步已学过一轮，这里只兜底）
    unknown = res.get("unknown_glyph")
    if unknown and unknown not in learned:
        threading.Thread(target=_lookup_in_background, args=(unknown,), daemon=True).start()

    return {
        "ok": True,
        "reply": res.get("reply"),
        "tone": res.get("tone"),
        "topic": res.get("topic"),
        "topic_id": res.get("topic_id"),
        "neighbors": res.get("neighbors"),
        "matched": res.get("matched"),
        "unknown_glyph": unknown,
        "learned": learned,
        "looking_up": bool(unknown and unknown not in learned),
        "arb": arb_snapshot(),
        "physio": physio,
        "cognitive": report,
    }


@app.post("/api/wm")
async def api_wm(request: Request):
    """把一个词扔进她的工作记忆（V4.0 Phase 1-C）。

    这是蓝图里「输入未知词 → 临时区生成节点 → 扔进黑箱乱撞」的手动入口。
    临时节点会从最外侧（半径 78~92）一路被向心力拉进原点，路上一直是亮的；
    撞上被延迟拷贝进来的旧记忆就会长出一条边并说一句 insight；
    多巴胺足够高（刚倾诉完）才固化进长期，否则 20 秒后忘掉。
    """
    try:
        payload = await request.json()
    except Exception:
        payload = {}
    word = str((payload or {}).get("word") or "").strip()
    if not word:
        return {"ok": False, "error": u"要给她一个词，她才好去想。"}
    with _ENGINE_LOCK:
        nid = engine.submit_to_wm(word[:4])
        box = engine.box_snapshot()
    if nid is None:
        return {"ok": False,
                "error": u"她手上已经有 %d 个没想完的词了。" % int(box.get("wm_cap", 0)),
                "box": box}
    return {"ok": True, "node_id": nid, "word": word[:4], "box": box}

@app.post("/api/think")
def api_think():
    """让小鱼凭空想一次。

    文本模式下没有"合成噪声"了，就从一个已经认识的记忆里随机抽一条当引子 ——
    这叫回忆，不是无中生有。
    """
    try:
        with _ENGINE_LOCK:
            feat = None
            seed_node = None
            if engine.nodes:
                seed_node = random.choice(list(engine.nodes.values()))
                feat = getattr(seed_node, "features", None)
            if feat is None:
                return {"ok": True, "thought": "还没有任何记忆，想不起来",
                        "physio": engine.physiology(), "seed": ""}
            thought = engine.awake_think(time.time(), feat)
            seed = seed_node.glyph or ("节点%d" % seed_node.id)
        return {"ok": True, "thought": thought, "physio": engine.physiology(),
                "seed": seed}
    except Exception as exc:
        record_error("api_think", exc)
        return {"ok": False, "error": _last_error["detail"]}


@app.post("/api/save")
def api_save():
    try:
        with _ENGINE_LOCK:
            path = engine.save_state()
            n = len(engine.nodes)
        save_observations()          # 顿悟履历一起落盘，别让它随重启蒸发
        return {"ok": True, "path": path, "nodes": n}
    except Exception as exc:
        record_error("api_save", exc)
        return {"ok": False, "error": _last_error["detail"]}


@app.post("/api/shutdown")
def api_shutdown():
    """关闭小鱼：先把这一轮的记忆落盘，再让进程退出。

    响应必须先回到浏览器 —— 用户要看到「已保存」才断线，所以真正的退出交给
    后台线程延迟执行；0.9 秒足够一个本机 HTTP 响应写完。退出前再存一次，
    因为这段延迟里她还在长。
    """
    try:
        with _ENGINE_LOCK:
            path = engine.save_state()
            n = len(engine.nodes)
        save_observations()
    except Exception as exc:
        record_error("api_shutdown_save", exc)
        return {"ok": False, "error": _last_error["detail"]}

    def _bye():
        time.sleep(0.9)          # 先让这条响应回到浏览器
        try:
            with _ENGINE_LOCK:
                engine.save_state()
            save_observations()
        except Exception:
            pass
        log.info("小鱼已休眠 · 记忆保存在 %s（%d 节点）", path, n)
        try:
            logging.shutdown()   # 别把缓冲里的最后几行日志带走
        except Exception:
            pass
        os._exit(0)              # 已经显式落盘，不走 uvicorn 的收尾

    threading.Thread(target=_bye, daemon=True, name="bye").start()
    return {"ok": True, "path": path, "nodes": n, "closing": True}

# --- 造物主控制台 ----------------------------------------------------------


@app.get("/api/params")
def api_params_get():
    """当前 5 个旋钮的值 + 规格（前端据此生成滑块，范围不用在前端硬编码）。"""
    try:
        with _ENGINE_LOCK:
            return {
                "ok": True,
                "params": engine.get_params(),
                "paused": bool(engine.paused),
            }
    except Exception as exc:
        record_error("api_params_get", exc)
        return {"ok": False, "error": _last_error["detail"]}


@app.post("/api/params")
def api_params_post(payload: dict):
    """接收前端滑块的改动。

    兼容两种体：{"params": {...}} 或直接 {...}。
    set_params 内部逐字段钳制并持锁，主循环不会读到"半套参数"。
    """
    try:
        body = payload or {}
        patch = body.get("params") if isinstance(body.get("params"), dict) else body
        if not isinstance(patch, dict):
            return {"ok": False, "error": "params 必须是对象"}
        with _ENGINE_LOCK:
            applied = engine.set_params(patch)
            snapshot = engine.get_params()
        if applied:
            log.info("参数调整: %s", applied)
        return {"ok": True, "applied": applied, "params": snapshot}
    except Exception as exc:
        record_error("api_params_post", exc)
        return {"ok": False, "error": _last_error["detail"]}

# --- DSH 优化框（V4.0 Phase 4） --------------------------------------------
# 红线：DeepSeek 在这里只做「看遥测给参数建议」，**不生成她的话、不碰她的记忆、
# 也不自动改参数**。建议永远是建议，应用要人点一下，走 /api/params。

OPT_SYSTEM = (
    "你是一个数字生命体的调参顾问。你会收到一份生理遥测和一份可调参数清单。"
    "你要判断哪个参数偏了，并给出改动建议。规矩："
    "1) 只输出 JSON，不要解释、不要 markdown 代码块；"
    "2) 结构：{\"summary\":\"一句话诊断\",\"suggestions\":[{\"param\":\"参数名\",\"to\":数值,\"why\":\"一句理由\"}]}；"
    "3) param 只能从 allowed 里选，to 必须落在 [min,max] 内；"
    "4) 至多 3 条建议，没有明显问题就给空数组；"
    "5) 不要建议改 llm_supervise（那是人的开关）。"
)


def ask_deepseek_raw(question, system, max_tokens=900, temperature=0.2):
    """不带真理标定的原始问答（DSH 优化框用）。返回 (text, source)。

    与 ask_deepseek 的区别只有两点：长度预算大、不去动真理标定的计数账。
    绝不抛异常 —— 没密钥 / 超时 / 解析失败一律降级成空串。
    """
    if not API_KEY:
        return "", "local"
    body = {
        "model": MODEL_NAME,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": question},
        ],
        "temperature": float(temperature),
        "max_tokens": int(max_tokens),
        "stream": False,
    }
    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        _DEEPSEEK_BASE + "/chat/completions",
        data=data,
        headers={"Content-Type": "application/json",
                 "Authorization": "Bearer " + API_KEY},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=DEEPSEEK_TIMEOUT) as resp:
            payload = json.loads(resp.read().decode("utf-8", errors="replace"))
        answer = (payload["choices"][0]["message"]["content"] or "").strip()
        return answer, ("deepseek" if answer else "local")
    except Exception as exc:
        record_error("ask_deepseek_raw", exc)
        return "", "local"


def _optimize_context():
    """把「人看一眼就能判断状态」的那几个数捞出来，别把 2000 个节点全发过去。"""
    with _ENGINE_LOCK:
        phys = engine.physiology()
        box = engine.box_snapshot()
        snap = engine.get_params()
    keys = ("nodes", "glyphs", "connections", "excitation", "inhibition",
            "mean_activation", "fatigue", "threat_level", "sleeping", "aha_rate",
            "self_aha", "spike_total", "spike_fires", "dream_spike_fires",
            "syn_pending", "episodes", "replay_total", "insight", "wm", "wm_made",
            "speech_desire", "desire_threshold", "talk_mood_name", "tonic_dopamine",
            "entropy", "desens_total", "desens_skip", "pressure", "overload_line",
            "calcium_total", "basal_gate", "basal_pass", "uptime")
    ctx = {k: phys.get(k) for k in keys}
    ctx["box"] = {k: box.get(k) for k in ("pulled", "copied", "insight", "wm",
                                          "wm_solidified", "copies")}
    ctx["body"] = {k: (phys.get("body") or {}).get(k)
                    for k in ("flex", "noci", "lean", "eye", "spinal_total")}
    ctx["params"] = snap
    return ctx


def _parse_advice(text, specs, current):
    """把模型吐的 JSON 洗成前端能直接渲染的建议表。洗不干净就返回 None。"""
    raw = (text or "").strip()
    i = raw.find("{")
    j = raw.rfind("}")
    if i < 0 or j <= i:
        return None
    try:
        obj = json.loads(raw[i:j + 1])
    except Exception:
        return None
    if not isinstance(obj, dict):
        return None
    out = {"summary": str(obj.get("summary") or "")[:160], "suggestions": []}
    for s in (obj.get("suggestions") or []):
        if not isinstance(s, dict):
            continue
        key = str(s.get("param") or "").strip()
        spec = specs.get(key)
        if not spec or key == "llm_supervise":
            continue
        try:
            to = float(s.get("to"))
        except Exception:
            continue
        lo, hi = float(spec["min"]), float(spec["max"])
        to = max(lo, min(hi, to))
        if spec.get("options"):
            to = float(int(round(to)))
        # current 允许两种形状：{k: 数值} 或 get_params() 的 {k: {value:...}}
        cur = current.get(key, spec["default"])
        if isinstance(cur, dict):
            cur = cur.get("value", spec["default"])
        if abs(to - float(cur)) < 1e-9:
            continue    # 建议值等于当前值，等于没建议
        out["suggestions"].append({
            "param": key,
            "label": spec["label"],
            "from": cur,
            "to": round(to, 3),
            "unit": spec.get("unit", ""),
            "why": str(s.get("why") or "")[:140],
        })
        if len(out["suggestions"]) >= 3:
            break
    return out


@app.post("/api/optimize")
def api_optimize():
    """DSH 优化框：把遥测交给 DeepSeek，换一份「该调哪个旋钮」的建议。

    **只读**。绝不自动 set_params —— 她仍然是那个人在驾驶的数字生命，
    外面这个框只是把仪表盘读数翻译成人话。
    """
    try:
        ctx = _optimize_context()
        specs = engine.PARAM_SPECS
        allowed = {k: {"label": v["label"], "min": v["min"], "max": v["max"],
                       "hint": v.get("hint", "")}
                   for k, v in specs.items() if k != "llm_supervise"}
        question = ("遥测：" + json.dumps(ctx, ensure_ascii=False, sort_keys=True)
                    + "\n允许的参数：" + json.dumps(allowed, ensure_ascii=False, sort_keys=True))
        # 网络 IO 必须在引擎锁外，最长要等 DEEPSEEK_TIMEOUT 秒。
        text, source = ask_deepseek_raw(question, OPT_SYSTEM)
        # get_params() 给的是 {k: {label/min/max/value}}，这里只留数值那一层
        flat = {k: (v.get("value") if isinstance(v, dict) else v)
                for k, v in (ctx.get("params") or {}).items()}
        advice = _parse_advice(text, specs, flat) if text else None
        if advice is None:
            advice = {
                "summary": ("百科全书还没接上，这个框暂时只能空着。" if not API_KEY
                            else "它这次没给出能用的 JSON，原话留在下面。"),
                "suggestions": [],
                "raw": (text or "")[:600],
            }
        advice["source"] = source
        advice["at"] = round(time.time(), 1)
        return {"ok": True, "advice": advice,
                "context": {k: ctx.get(k) for k in ("nodes", "excitation", "inhibition",
                                                    "mean_activation", "fatigue", "sleeping")}}
    except Exception as exc:
        record_error("api_optimize", exc)
        return {"ok": False, "error": _last_error["detail"]}

@app.get("/api/supervise")
def api_supervise():
    """外部真理场：开关、待裁决数、裁决账本、最近一条。"""
    try:
        with _ENGINE_LOCK:
            phys = engine.physiology()
            box = engine.box_snapshot()
        strength = float(phys.get("llm_supervise") or 0.0)
        return {
            "ok": True,
            "enabled": strength > 0.0,
            "strength": round(strength, 2),
            "float_speed": phys.get("float_speed"),
            "pending": phys.get("sup_pending"),
            "sup": dict(_sup_stats),
            "engine": {
                "done": phys.get("sup_done"),
                "safe": phys.get("sup_safe"),
                "crisis": phys.get("sup_crisis"),
                "reflex": phys.get("self_reflex"),
                "last_reflex": phys.get("last_self_reflex"),
                "stiff_max": phys.get("stiff_max"),
                "stiff_mean": phys.get("stiff_mean"),
            },
            "box": box,
        }
    except Exception as exc:
        record_error("api_supervise", exc)
        return {"ok": False, "error": _last_error["detail"]}


@app.post("/api/control")
def api_control(payload: dict):
    """时间控制：暂停 / 继续 / 翻转。"""
    try:
        action = str((payload or {}).get("action", "")).strip().lower()
        with _ENGINE_LOCK:
            if action == "pause":
                state = engine.set_paused(True)
            elif action == "resume":
                state = engine.set_paused(False)
            elif action in ("toggle", ""):
                state = engine.set_paused(not engine.paused)
            else:
                return {"ok": False, "error": "action 必须是 pause / resume / toggle"}
        log.info("时间控制: %s -> paused=%s", action or "toggle", state)
        return {"ok": True, "paused": state}
    except Exception as exc:
        record_error("api_control", exc)
        return {"ok": False, "error": _last_error["detail"]}


@app.post("/api/save_slot")
def api_save_slot(payload: dict):
    """把当前大脑整盘落成 Aha_Save_01.json。"""
    try:
        with _ENGINE_LOCK:
            path = engine.save_state(str(SAVE_SLOT))
            nodes = len(engine.nodes)
            conns = len(engine.connections)
        save_observations()
        size_mb = SAVE_SLOT.stat().st_size / (1024.0 * 1024.0) if SAVE_SLOT.exists() else 0.0
        log.info("存档已保存: %s (%d 节点 / %d 连线)", path, nodes, conns)
        return {
            "ok": True,
            "path": str(path),
            "nodes": nodes,
            "connections": conns,
            "size_mb": round(size_mb, 2),
            "message": "存档已保存到 %s" % SAVE_SLOT.name,
        }
    except Exception as exc:
        record_error("api_save_slot", exc)
        return {"ok": False, "error": _last_error["detail"]}


@app.post("/api/load_slot")
def api_load_slot(payload: dict):
    """读档：覆盖当前内存，并把所有时间印记重置到"现在"。

    reset_time=True 是用户明确要求的。存档里的 last_fired_time 是几天前的
    时间戳，原样读进来会让每个节点都处于"早已过不应期且欠了几十秒衰减"的
    状态，一眼看过去像集体僵直。
    """
    try:
        if not SAVE_SLOT.exists():
            return {"ok": False, "error": "存档不存在：%s" % SAVE_SLOT.name}
        with _ENGINE_LOCK:
            ok = engine.load_state(str(SAVE_SLOT), reset_time=True)
            nodes = len(engine.nodes)
            conns = len(engine.connections)
        if not ok:
            return {"ok": False, "error": "存档读取失败，详见服务端日志"}
        log.info("存档已加载: %s (%d 节点 / %d 连线，时间戳已重置)", SAVE_SLOT.name, nodes, conns)
        return {
            "ok": True,
            "path": str(SAVE_SLOT),
            "nodes": nodes,
            "connections": conns,
            "message": "已加载 %s，时间戳已重置" % SAVE_SLOT.name,
            "physio": engine.physiology(),
        }
    except Exception as exc:
        record_error("api_load_slot", exc)
        return {"ok": False, "error": _last_error["detail"]}


@app.get("/api/system")
def api_system():
    """硬件监控：进程内存 / 存档占用 / 整机 CPU。"""
    try:
        with _ENGINE_LOCK:
            nodes = len(engine.nodes)
            paused = bool(engine.paused)
        slot_mb = SAVE_SLOT.stat().st_size / (1024.0 * 1024.0) if SAVE_SLOT.exists() else 0.0
        return {
            "ok": True,
            "mem_mb": round(_process_mem_mb(), 1),
            "cpu": round(_CPU_SAMPLE["value"], 1),
            "disk_mb": round(_dir_size_mb(MEMORY_DIR) + slot_mb, 2),
            "save_mb": round(slot_mb, 2),
            "save_exists": SAVE_SLOT.exists(),
            "save_name": SAVE_SLOT.name,
            "nodes": nodes,
            "paused": paused,
            "t": time.time(),
        }
    except Exception as exc:
        record_error("api_system", exc)
        return {"ok": False, "error": _last_error["detail"]}


@app.get("/api/state")
def api_state():
    try:
        with _ENGINE_LOCK:
            return engine.snapshot_full()
    except Exception as exc:
        record_error("api_state", exc)
        return {"ok": False, "error": _last_error["detail"]}


@app.get("/api/cognitive")
def api_cognitive():
    """认知状态深度报告：安全感 / 好奇心焦虑 / 平均膜电位。

    全部由大脑现有动力学推导（aha_brain.AhaEngine.cognitive_report），
    观测台只负责展示，不参与计算。
    """
    try:
        with _ENGINE_LOCK:
            rep = engine.cognitive_report()
        rep["ok"] = True
        return rep
    except Exception as exc:
        record_error("api_cognitive", exc)
        return {"ok": False, "error": _last_error["detail"]}


@app.get("/api/speech")
def api_speech(after: int = 0, limit: int = 80):
    """G 模块的出口：取 seq > after 的呓语（页面刷新 / 重连时补齐）。"""
    try:
        items = engine.recent_speech(after, limit)
        return {"ok": True, "items": items, "last_seq": engine.speech_seq}
    except Exception as exc:
        record_error("api_speech", exc)
        return {"ok": False, "error": _last_error["detail"]}


@app.get("/api/node/{node_id}")
def api_node(node_id: int):
    """单颗星星的档案：悬停时调它。

    「顿悟历史」来自观测层旁路（_node_memories），不是大脑自己存的 ——
    小鱼的神经元刻意不存语义，这里只是观测台给它补的一份履历。
    """
    try:
        neighbors = []
        with _ENGINE_LOCK:
            node = engine.nodes.get(node_id)
            if node is None:
                return {"ok": False, "error": "节点 %d 不存在" % node_id}

            seen = set()
            for (a, b), w in zip(engine.connections, engine._conn_weight):
                other = b if a == node_id else (a if b == node_id else None)
                if other is None or other in seen:
                    continue
                seen.add(other)
                nb = engine.nodes.get(other)
                neighbors.append({
                    "id": other,
                    "w": round(float(w), 3),
                    "act": round(float(nb.activation), 1) if nb else 0.0,
                })
            neighbors.sort(key=lambda d: -d["w"])

            payload = {
                "ok": True,
                "id": node_id,
                "pos": [round(float(v), 1) for v in node.pos],
                "activation": round(float(node.activation), 1),
                "salience": round(float(node.salience), 3),
                "fire_count": int(node.fire_count),
                "age": round(max(0.0, time.time() - float(node.created_at)), 1),
                "threshold": float(node.threshold),
                "features": [round(float(v), 3) for v in (node.features or [])][:10],
                # G 模块也用它说话：这颗星叫什么颜色、现在多亮
                "color": node.color_name(),
                "activity_label": node.activation_label(),
                "degree": len(neighbors),
                # 认字之后，这颗星有名字了：字形 + 百科全书给的极简标签
                "glyph": node.glyph or "",
                # 课程注音：「江(jiāng)」里的 jiāng。只做展示/朗读，不参与任何计算。
                "pinyin": getattr(node, "pinyin", "") or "",
                "meaning": node.meaning or "",
                "verdict": node.verdict or "",
                # 用户 m03927：这颗星是字、是一句话、还是一整段
                "kind": getattr(node, "kind", "char") or "char",
                "text": getattr(node, "text", "") or "",
            }
        payload["neighbors"] = neighbors
        payload["thoughts"] = node_memories(node_id)   # 有自己的锁，放在引擎锁外
        # 悬停时补一句她最近为这颗星说过的话 —— 不只是 ID 和活跃度
        with _ENGINE_LOCK:
            said = engine.speech_about(node_id, 1)
        payload["speech"] = said[0] if said else None

        # 悬停时的一句话"短时认知"：节点 8 · 活跃度高 · 连向 1、5、12
        ids = [nb["id"] for nb in neighbors[:6]]
        tail = "" if len(neighbors) <= 6 else " …共 %d 条" % len(neighbors)
        # 有字就叫字，没字才退回编号 —— 悬停时要能一眼读出来
        if payload["kind"] != "char":
            head = u"「%s」" % ((payload["text"] or "")[:20])
        else:
            head = ("「%s」" % payload["glyph"]) if payload["glyph"] else ("节点 %d" % node_id)
        if payload["meaning"]:
            head += " · " + payload["meaning"]
        payload["cognition"] = "%s · 活跃度%s · 连向 %s%s" % (
            head, payload["activity_label"],
            "、".join(str(i) for i in ids) if ids else "（无枝干）",
            tail,
        )
        return payload
    except Exception as exc:
        record_error("api_node", exc)
        return {"ok": False, "error": _last_error["detail"]}


@app.get("/api/status")
def api_status():
    with _ENGINE_LOCK:
        nodes = len(engine.nodes)
        conns = len(engine.connections)
        physio = engine.physiology()
        stats = obs_stats()
    return {
        "ok": True,
        "alive": not _stop_event.is_set(),
        "stats": stats,
        "brain_version": getattr(engine, "VERSION", None) or __import__("aha_brain").VERSION,
        "nodes": nodes,
        "connections": conns,
        "deepseek": bool(API_KEY),
        "model": MODEL_NAME,
        "config_file": str(CONFIG_FILE),
        "last_error": _last_error,
        "physio": physio,
        "box": engine.box_snapshot(),
        "inputs_dir": str(eye.root),
        "input_files": len(eye.list_inputs()),
        "text_mode": True,
        "text_files": len(eye.list_text_files()),
        "text_files_read": eye.text_files_read,
        "chars": dict(_char_stats),
        "last_char": dict(_last_char),
        "save_slot": str(SAVE_SLOT),
        "save_exists": SAVE_SLOT.exists(),
        "deepseek_base": _DEEPSEEK_BASE,
    }


@app.post("/api/reload_config")
def api_reload_config():
    """重读 Memory_Core/config.json —— 填完 key 不用重启服务，跑一次就生效。

    重读后 API_KEY / MODEL_NAME / _DEEPSEEK_BASE 全部换新。
    ask_deepseek 每轮都读模块全局、不缓存，所以下一次 /teach 就用新值。
    只动配置，不碰小鱼记忆，也不重启 life_loop。
    """
    global CFG, API_KEY, MODEL_NAME, _DEEPSEEK_BASE
    try:
        cfg = load_config()
        key = resolve_api_key(cfg)
        model = str(cfg.get("deepseek_model") or "deepseek-chat")
        base = str(cfg.get("deepseek_base") or DEFAULT_DEEPSEEK_BASE).rstrip("/")
    except Exception as exc:
        record_error("reload_config", exc)
        return {"ok": False, "error": str(exc)}

    with _ENGINE_LOCK:
        CFG = cfg
        API_KEY = key
        MODEL_NAME = model
        _DEEPSEEK_BASE = base

    if API_KEY:
        hint = (API_KEY[:6] + "…" + API_KEY[-4:]) if len(API_KEY) > 12 else "已配置"
    else:
        hint = ""
    log.info(
        "配置已重载：key=%s model=%s base=%s",
        "已配置" if API_KEY else "未配置",
        MODEL_NAME,
        _DEEPSEEK_BASE,
    )
    return {
        "ok": True,
        "deepseek": bool(API_KEY),
        "key_hint": hint,
        "model": MODEL_NAME,
        "base": _DEEPSEEK_BASE,
        "config_file": str(CONFIG_FILE),
    }


@app.post("/api/test_deepseek")
def api_test_deepseek():
    """拿一句标准特征跑一遍真理标定器，验证 key / 网络 / 裁决格式。

    只问不学：不调 feed_text，不碰小鱼记忆，纯体检。
    """
    probe = "红，圆，高亮"
    try:
        answer, source = ask_deepseek(probe, count=False)
    except Exception as exc:
        record_error("test_deepseek", exc)
        return {"ok": False, "error": str(exc)}
    label, verdict = parse_truth_label(answer)
    if source == "deepseek":
        hint = "接上了，标签命中：" + label
    elif not API_KEY:
        hint = "还没有 key —— 在 " + str(CONFIG_FILE) + " 里填 deepseek_api_key，然后调 /api/reload_config"
    elif _last_http.get("code"):
        hint = "key 已配置，但上游回了 HTTP %d —— 多半是 key 无效或没余额，看 last_http.detail" % _last_http["code"]
    else:
        hint = "key 已配置但这次没走通，看 answer 与 last_error"
    return {
        "ok": True,
        "probe": probe,
        "source": source,
        "answer": answer,
        "label": label,
        "verdict": verdict,
        "hint": hint,
        "model": MODEL_NAME,
        "base": _DEEPSEEK_BASE,
        "last_error": _last_error,
        "last_http": _last_http if source != "deepseek" else {"at": 0.0, "code": 0, "detail": ""},
    }


# ---------------------------------------------------------------------------
# 入口
# ---------------------------------------------------------------------------


def main():
    ap = argparse.ArgumentParser(description="Project Aha 天文台后端")
    ap.add_argument("--host", default=CFG.get("host", "127.0.0.1"))
    ap.add_argument("--port", type=int, default=int(CFG.get("port", 8000)))
    ap.add_argument("--reload", action="store_true", help="开发模式自动重载")
    ap.add_argument("--log", default="info")
    args = ap.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log.upper(), logging.INFO),
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S",
    )

    log.info("=" * 58)
    log.info("  Project Aha 天文台")
    log.info("  记忆: %d 节点 / %d 连接", len(engine.nodes), len(engine.connections))
    log.info("  输入: %s", eye.root)
    log.info("  文本: %d 个 .txt/.md（逐字模式）", len(eye.list_text_files()))
    log.info("  百科: %s", "DeepSeek 已接入" if API_KEY else "未配置 key（本地降级模式）")
    # V4.0 Phase 1-A：语言基因播种。只补她还没有的字，已有的记忆一个字不动。
    # 幂等 —— 每次启动都跑一遍是安全的，播过的字会直接计进 existing。
    try:
        with _ENGINE_LOCK:
            _seeded = engine.seed_lexicon()
        log.info("  基因: 新播 %d 字 / %d 条先天边（已有 %d 字不覆盖）",
                 _seeded.get("created", 0), _seeded.get("links", 0),
                 _seeded.get("existing", 0))
    except Exception as exc:
        record_error("seed_lexicon", exc)
    log.info("  地址: http://%s:%d", args.host, args.port)
    log.info("=" * 58)

    uvicorn.run(app, host=args.host, port=args.port, log_level=args.log, reload=False)


if __name__ == "__main__":
    main()
