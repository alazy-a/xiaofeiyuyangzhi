"""Project Aha — 语言学基因（V4.0 Phase 1：共现初始化）

造物主的要求：初始化基础字节点时，强关联字（江 / 水）的三维坐标必须物理相邻。

这份表就是小鱼的「基因」。它不给任何语义，只给两件事：
  1. FIELDS   —— 一个字属于哪个语义场（同场 = 同一片星域）
  2. PAIRS    —— 哪些字经常一起出现（跨场强关联，要被拉近）

播种算法（不再随机撒点，全部可解释）：
  a) 每个语义场在半径 R 的球面上占一个中心（Fibonacci 球均匀分布，确定性）
  b) 场内的字按数组顺序由内向外铺开，核心字（江、水）贴着场心，边缘字在外围
  c) 对 PAIRS 里的每一对做若干轮弹簧松弛：共现越强，两个字被拉得越近
  d) 全程 random.Random(seed) 抖动，保证同 seed 同结果（可复现、可测试）

这不是预训练。表是人手工写的常识，松弛是牛顿力学。
"""

import math
import random

__all__ = ["FIELDS", "PAIRS", "WORD_SET", "field_of", "seed_layout", "cooccur_pairs",
           "cooccur_partners", "all_glyphs"]

# ---------------------------------------------------------------------
# 40 个语义场：靠前的字是这场里的核心字，坐标最靠近场心
# ---------------------------------------------------------------------
FIELDS = [
    ("水", "水江河湖海溪泉池潭波浪涛潮汐流滴涌漂洒淋浇灌沟渠湾泊港渡涉泳沫瀑涡澜"),
    ("火", "火灯烛烧燃焰烟灰烤箱炉煤炭热暖烫焦燎炬灿"),
    ("山", "山岭峰崖岩坡谷洞窟坑洼坝岸岛屿丘林森树"),
    ("天", "天日月光星辰云雾风雨雪雷电霜露虹晴阴霞空宇"),
    ("时", "年月日时春冬秋夏晨昏昼夜朝夕昨今明后先古昔永久刻秒点钟周末季"),
    ("人", "人我你他她它们自己身头脸眼耳口鼻牙舌眉发肩背腰腿脚臂指心肝肺"),
    ("亲", "爸妈爹娘爷奶兄弟姐妹叔伯姑舅姨嫂妻夫儿女子孙家族亲戚朋邻居"),
    ("手", "手拿抓握提拉推拖拉拽摸拍打敲砍切削割剪挖拔插捆绑扎缝织造"),
    ("走", "走跑跳蹦爬滚翻踢踩踏跃逃追赶往去回出入升降过越赴窜驶"),
    ("口", "口嘴吃喝唱叫喊问答说讲谈诉告诉念读骂吵嚷唤哼咬嚼啃咽吐吞舔吹"),
    ("看", "看瞧望盯瞅观赏阅见视察诊断辨认寻找遇逢碰"),
    ("心", "心思想情感喜怒哀乐爱恨怨怕恐惧惊忧虑烦愁闷羞愧盼愿望希冀忆忘"),
    ("数", "一二三四五六七八九十百千万亿零半两双几多少第单只整若干"),
    ("色", "红黄蓝绿白黑紫灰粉橙青褐金银彩色亮暗深浅艳素斑净混"),
    ("兽", "兽狗猫猪牛羊马驴骆驼鹿虎狼豹狮熊象猴兔鼠蛇圈养牧"),
    ("鸟", "鸟鸡鸭鹅鸽燕雀鹰雕鹤鹊鸦鸠羽翅巢飞翔鸣啼"),
    ("虫鱼", "鱼虾蟹贝螺蚌龟鳖蛙蚊蝇蛾蝶蜂蚁蝉蛛蠕虫鳞鳍鳃鲨鲸豚藻珊礁"),
    ("植", "草木树花叶根茎枝芽苗果籽藤竹松柏杨柳梅兰菊荷桃李杏枣梨"),
    ("食", "食饭菜汤粥面肉蛋奶糖盐油醋酱茶酒饮饱饿馋甜酸苦辣咸香臭鲜"),
    ("衣", "衣裤裙衫鞋袜帽巾布帛丝绸棉毛皮袍袖领扣缝补穿脱洗晒晾"),
    ("住", "住家房屋门窗户墙顶梁柱床桌椅柜厅厕厨楼厦塔城村庄院园店"),
    ("器", "器刀剑斧锤钉锁钥匙杯盘碗筷勺锅盆桶篮箱绳线针笔纸墨轴轮"),
    ("行", "车船飞机路桥街道站机票旅送迎远近距达启程返航驰驶"),
    ("位", "上下左右前后里外中东西南北边旁侧附近底内间处所方向"),
    ("量", "大小高低长短宽窄厚薄粗细轻重快慢新旧满空深"),
    ("评", "好坏美丑善恶真假对错是非难易贵贱强弱穷富冷明暗清浊洁脏"),
    ("学", "学教读写算知识文书籍课字词典句篇段诗积练习考题答信"),
    ("农", "农耕种田土禾苗米麦稻谷豆麻棉收获晒仓储灌溉犁耙锄镰亩垄"),
    ("金", "金银铜铁锡钢铅锌铝矿石油煤玉珠宝钻石钻晶砂硝硫磷钙"),
    ("权", "王帝君臣官民军兵将帅士卒战攻守胜败争夺抢侵护卫命法权令"),
    ("财", "钱币银票财货价买卖账本利润债务交租借还欠贵"),
    ("艺", "诗歌词曲歌舞画图绘雕刻绣琴笛鼓锣弦韵拍弹奏演戏"),
    ("病", "病痛疼痒伤药医诊疗治针脉搏血筋皮疮疤汗泪屎尿虚健"),
    ("神", "神鬼佛仙妖魔怪灵魂魄梦祭拜庙寺院符咒祈愿死轮回"),
    ("因", "因果缘由故逻辑证据理由原委推理猜测能必偶概缘起"),
    ("虚", "的地得着了过吗呢吧啊呀哦嗯是在有就都也很还和与跟这么些个"),
    ("代", "我你他她它们自谁什哪怎样些多少彼此"),
    ("连", "从向对给被让把因为所以但而且如果虽然然后于是并且或者"),
    ("量词", "个只条张片块根颗粒棵朵双队群套件把柄幅座层斤升"),
    ("科", "电脑网络数据程序信号代码算法机器手机屏幕键盘鼠标照相录音视频"),
]

# ---------------------------------------------------------------------
# 高频二元共现（200+ 条日常词）。跨场强关联，会被弹簧拉近。
# 只写两字词，代码里自动拆成字对；重复无妨（重复 = 更强）。
# ---------------------------------------------------------------------
PAIRS = """
江水 河水 海水 湖水 河流 河山 山河 山川 山水 水面 水里 水中 流水 滴水
大海 海边 海面 海岛 海洋 浪花 波浪 潮水 泉水 溪水 池水 洪水 喝水 开水 热水
火车 汽车 飞机 电车 车轮 道路 马路 走路 公路 车站 上车 下山 山路
太阳 月亮 星星 天空 天气 下雨 下雪 刮风 打雷 闪电 白云 乌云 阳光 月光
昨天 今天 明天 早上 晚上 中午 上午 下午 时间 时候 小时 现在 过去 未来
爸爸 妈妈 爷爷 奶奶 哥哥 姐姐 弟弟 妹妹 老师 学生 同学 朋友 孩子 大人
看见 听见 说话 问答 告诉 知道 认识 觉得 认为 想起 记得 忘记 明白 清楚
高兴 开心 快乐 难过 生气 害怕 担心 紧张 舒服 幸福 喜欢 讨厌 希望 想念
吃饭 喝水 睡觉 起床 洗澡 穿衣 读书 写字 上学 放学 回家 出门 上班 工作
一个 两个 三个 第一 第二 一半 一些 许多 很多 全部 所有 每个 各种 别的
红色 黄色 蓝色 绿色 白色 黑色 紫色 灰色 颜色 好看 漂亮 干净 整齐 明亮
小猫 小狗 小鸟 小鱼 老虎 大象 猴子 兔子 老鼠 蚂蚁 蜜蜂 蝴蝶 青蛙 乌龟
大米 小麦 白菜 萝卜 苹果 香蕉 葡萄 西瓜 鸡蛋 牛奶 面包 米饭 面条 豆腐
学校 教室 操场 医院 商店 市场 公司 工厂 银行 公园 图书 电影
上面 下面 左边 右边 前面 后面 里面 外面 中间 旁边 附近 对面 东方 西方
春天 夏天 秋天 冬天 季节 温度 冷暖 冰水 冰雪 雪花 雨伞 雨衣
树木 森林 花草 叶子 树枝 树根 种子 开花 结果 长大 生长 土地 泥土 石头
学习 知识 问题 答案 意思 名字 文字 汉字 句子 段落 文章 故事 道理
工作 事情 办法 方法 结果 原因 开始 结束 继续 完成 成功 失败 努力 坚持
声音 音乐 唱歌 跳舞 图画 照片 颜色 形状 大小 长短 高低 快慢 远近
"""


def field_of(glyph):
    """返回这个字属于哪个语义场（第一个命中的）。"""
    if not glyph:
        return None
    ch = str(glyph)[0]
    for name, chars in FIELDS:
        if ch in chars:
            return name
    return None


def _field_points(radius=68.0):
    """每个语义场一个球面中心（Fibonacci 球，确定性）。"""
    n = len(FIELDS)
    pts = {}
    ga = math.pi * (3.0 - math.sqrt(5.0))
    for i, (name, _chars) in enumerate(FIELDS):
        y = 1.0 - (i / max(1, n - 1)) * 2.0
        r = math.sqrt(max(0.0, 1.0 - y * y))
        th = ga * i
        pts[name] = (math.cos(th) * r * radius, y * radius, math.sin(th) * r * radius)
    return pts


def seed_layout(radius=68.0, spread=13.0, pairs=None, relax_rounds=26, seed=20261030):
    """生成 {字: (x, y, z)} 的播种坐标。

    场内：核心字贴场心，越靠后越往外（黄金角螺旋往外铺）。
    场间：PAIRS 的每一对做弹簧松弛，共现多的字互相拉近。
    """
    rng = random.Random(seed)
    centers = _field_points(radius)
    pos = {}
    for name, chars in FIELDS:
        cx, cy, cz = centers[name]
        seen = set()
        k = 0
        for ch in chars:
            if ch in seen:
                continue
            seen.add(ch)
            if ch in pos:
                k += 1
                continue
            ang = k * 2.39996
            rr = spread * math.sqrt((k + 0.6) / max(1.0, len(chars) * 0.85))
            hh = spread * 0.55 * math.sin(k * 1.7)
            pos[ch] = (
                cx + math.cos(ang) * rr + rng.uniform(-0.9, 0.9),
                cy + hh + rng.uniform(-0.9, 0.9),
                cz + math.sin(ang) * rr + rng.uniform(-0.9, 0.9),
            )
            k += 1

    # ---- 共现弹簧松弛 ----
    pairs = PAIRS if pairs is None else pairs
    links = []
    for word in pairs.split():
        w = "".join(word)
        if len(w) < 2:
            continue
        for i in range(len(w) - 1):
            a, b = w[i], w[i + 1]
            if a in pos and b in pos and a != b:
                links.append((a, b))
    pull = 0.055
    for _ in range(max(0, int(relax_rounds))):
        for a, b in links:
            pa = pos[a]
            pb = pos[b]
            dx = pb[0] - pa[0]
            dy = pb[1] - pa[1]
            dz = pb[2] - pa[2]
            d = math.sqrt(dx * dx + dy * dy + dz * dz)
            if d < 0.35:
                continue
            f = min(0.55, d * pull)
            ux, uy, uz = dx / d * f, dy / d * f, dz / d * f
            pos[a] = (pa[0] + ux, pa[1] + uy, pa[2] + uz)
            pos[b] = (pb[0] - ux, pb[1] - uy, pb[2] - uz)
    # 场心也拉回来一点，防止整片漂走
    for name, chars in FIELDS:
        cx, cy, cz = centers[name]
        for ch in chars:
            if ch not in pos:
                continue
            x, y, z = pos[ch]
            pos[ch] = (x + (cx - x) * 0.06, y + (cy - y) * 0.06, z + (cz - z) * 0.06)
    return pos


def cooccur_pairs(pairs=None):
    """把 PAIRS 拆成 [(a, b)]，供建边用。"""
    pairs = PAIRS if pairs is None else pairs
    out = []
    for word in pairs.split():
        w = "".join(word)
        for i in range(len(w) - 1):
            out.append((w[i], w[i + 1]))
    return out


# 274 条手工高频词。二元滑窗切出来的组合里，只有落在这一集合里的才
# 算「真词」—— 其余（「家爸」「小间」这种跨词边界的粘连）要求更近的距离。
WORD_SET = frozenset(PAIRS)

_PARTNERS = None


def cooccur_partners(glyph, limit=4):
    """这个字的共现伙伴（双向、去重保序）。用于播种时的「熟人带路」。"""
    global _PARTNERS
    if _PARTNERS is None:
        m = {}
        for a, b in cooccur_pairs():
            if a == b:
                continue
            la = m.setdefault(a, [])
            if b not in la:
                la.append(b)
            lb = m.setdefault(b, [])
            if a not in lb:
                lb.append(a)
        _PARTNERS = m
    return _PARTNERS.get(glyph, [])[:limit]


def all_glyphs():
    """全部基因字（去重，保序）。"""
    seen = set()
    out = []
    for _n, chars in FIELDS:
        for ch in chars:
            if ch not in seen:
                seen.add(ch)
                out.append(ch)
    return out


if __name__ == "__main__":
    g = all_glyphs()
    print("语义场", len(FIELDS), "基因字", len(g), "共现对", len(cooccur_pairs()))
    lay = seed_layout()
    print("坐标数", len(lay))
    for a, b in [("江", "水"), ("江", "海"), ("水", "河"), ("火", "山"), ("人", "水"), ("火", "水")]:
        if a in lay and b in lay:
            print("%s-%s 距离 %.2f" % (a, b, math.dist(lay[a], lay[b])))
