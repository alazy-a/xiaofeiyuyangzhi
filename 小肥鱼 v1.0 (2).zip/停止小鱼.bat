@echo off
chcp 65001 >nul
title 停止小肥鱼
set FOUND=
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":8000" ^| findstr "LISTENING"') do (
  set FOUND=1
  taskkill /f /pid %%a >nul 2>nul
)
if defined FOUND (echo   小肥鱼已停止。) else (echo   8000 端口上没有在跑的小肥鱼。)
pause
