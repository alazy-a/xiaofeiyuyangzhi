"""Project Aha — 三维 KD-Tree（V4.0 Phase 1）

为什么需要它
------------
引擎里几乎所有"看谁离得近"的地方原来都是 O(n) 全量遍历：
    _get_spatial_neighbors / consolidate / _prune
节点数到 3000 时，每帧十几次全量扫描就是几十万次距离计算，
主循环会被几何拖死。KD-Tree 把这个降到 O(log n + k)。

设计取舍
--------
1. 只做三维空间检索。50 维特征向量的余弦检索**不用** KD-Tree：
   高维下剪枝率趋近于零，退化成全量遍历还多一层递归开销。
2. 节点会移动（黑箱向心力的要求），所以支持 move()：
   旧点标记 dead、新点插入，累计位移数超过阈值再整体 rebuild。
3. 惰性删除：remove 只打标记，rebuild 时才真正丢弃。
4. 叶子是"桶"（axis == -1），桶内线性扫。桶溢出时累计一次位移计数，
   由 _maybe_rebuild 统一重建 —— 不做动态平衡，rebuild 承担全部平衡职责。
"""

import bisect
import math

__all__ = ["KDTree3"]

LEAF_AXIS = -1


class _Node(object):
    __slots__ = ("axis", "pid", "point", "left", "right", "bucket")

    def __init__(self, axis, pid=None, point=None, bucket=None):
        self.axis = axis
        self.pid = pid
        self.point = point
        self.left = None
        self.right = None
        self.bucket = bucket


class KDTree3(object):
    """纯 Python 三维 KD-Tree，主打"够快 + 好读"。"""

    def __init__(self, leaf_size=8, rebuild_slack=0.05, rebuild_min=48):
        self.leaf_size = int(leaf_size)
        self.rebuild_slack = float(rebuild_slack)
        self.rebuild_min = int(rebuild_min)
        self._root = None
        self._pts = {}            # pid -> (x, y, z)  只存当前有效位置
        self._dead = set()        # 墓碑 {(pid,(x,y,z))}：旧位置，查询时跳过
        self._moved = 0           # 自上次 rebuild 以来的位移/删除/桶溢出次数
        self._builds = 0
        self._queries = 0

    # -- 基础 ---------------------------------------------------------
    def __len__(self):
        return len(self._pts)

    def __contains__(self, pid):
        return pid in self._pts

    @property
    def stats(self):
        return {
            "size": len(self),
            "alive": len(self._pts),
            "dead": len(self._dead),
            "moved": self._moved,
            "builds": self._builds,
            "queries": self._queries,
        }

    def clear(self):
        self._root = None
        self._pts = {}
        self._dead = set()
        self._moved = 0

    def positions(self):
        return dict(self._pts)

    # -- 构建 ---------------------------------------------------------
    def _make(self, items, depth):
        if not items:
            return None
        n = len(items)
        if n <= self.leaf_size:
            return _Node(LEAF_AXIS, bucket=list(items))
        axis = depth % 3
        items.sort(key=lambda it: it[1][axis])
        mid = n // 2
        pid, p = items[mid]
        nd = _Node(axis, pid, p)
        nd.left = self._make(items[:mid], depth + 1)
        nd.right = self._make(items[mid + 1:], depth + 1)
        return nd

    def rebuild(self, points=None):
        """全量重建。points 为空时用内部索引重建（清掉 dead）。"""
        if points is not None:
            self._pts = {}
            for pid, p in points:
                self._pts[pid] = (float(p[0]), float(p[1]), float(p[2]))
            self._dead = set()
        else:
            self._dead = set()
        items = [(pid, p) for pid, p in self._pts.items()]
        self._root = self._make(items, 0)
        self._moved = 0
        self._builds += 1
        return len(self)

    def _cap(self):
        return max(self.rebuild_min, int(len(self._pts) * self.rebuild_slack))

    def _maybe_rebuild(self):
        if self._moved >= self._cap() or len(self._dead) >= self._cap():
            self.rebuild()

    # -- 写入 ---------------------------------------------------------
    def insert(self, pid, point):
        p = (float(point[0]), float(point[1]), float(point[2]))
        if pid in self._pts:
            self.move(pid, p)
            return
        self._pts[pid] = p
        if self._root is None:
            self.rebuild()
            return
        self._insert_one(pid, p)

    def _detach_and_reinsert(self, pid, p, old=None):
        """旧位置留墓碑，新位置插进树。"""
        if old is not None:
            self._dead.add((pid, old))
        self._moved += 1
        if self._moved >= self._cap():
            self.rebuild()
        else:
            self._insert_one(pid, p)

    def _insert_one(self, pid, p):
        nd = self._root
        if nd is None:
            self.rebuild()
            return
        depth = 0
        while True:
            if nd.axis == LEAF_AXIS:
                nd.bucket.append((pid, p))
                if len(nd.bucket) > self.leaf_size * 2:
                    self._moved += 1
                    if self._moved >= self._cap():
                        self.rebuild()
                return
            axis = nd.axis
            depth += 1
            if p[axis] < nd.point[axis]:
                if nd.left is None:
                    nd.left = _Node(LEAF_AXIS, bucket=[(pid, p)])
                    return
                nd = nd.left
            else:
                if nd.right is None:
                    nd.right = _Node(LEAF_AXIS, bucket=[(pid, p)])
                    return
                nd = nd.right

    def remove(self, pid):
        old = self._pts.pop(pid, None)
        if old is not None:
            self._dead.add((pid, old))
            self._moved += 1
            self._maybe_rebuild()

    def move(self, pid, point):
        """节点在空间里动了（黑箱向心力）。"""
        if pid not in self._pts:
            self.insert(pid, point)
            return
        p = (float(point[0]), float(point[1]), float(point[2]))
        old = self._pts[pid]
        self._pts[pid] = p
        self._detach_and_reinsert(pid, p, old)

    # -- 查询 ---------------------------------------------------------
    @staticmethod
    def _dist2(p, q):
        dx = p[0] - q[0]
        dy = p[1] - q[1]
        dz = p[2] - q[2]
        return dx * dx + dy * dy + dz * dz

    def knn(self, point, k=8, exclude=None, max_dist=None):
        """返回 [(dist, pid, (x,y,z))]，按距离升序。"""
        if self._root is None or k <= 0:
            return []
        self._queries += 1
        q = (float(point[0]), float(point[1]), float(point[2]))
        lim = None if max_dist is None else float(max_dist) ** 2
        ex = exclude or ()
        best = []
        self._knn(self._root, q, k, lim, ex, best)
        best.sort(key=lambda t: t[0])
        return [(math.sqrt(d2), pid, self._pts[pid]) for d2, pid in best[:k]]

    def _knn(self, nd, q, k, lim, ex, best):
        # 热循环：把方法查找、重复排序、空集判定都提到循环外。
        # 原来每命中一个点就 best.sort() 一次，k=8 时白烧掉一半时间。
        dead = self._dead
        dist2 = self._dist2
        insort = bisect.insort
        stack = [nd]
        while stack:
            cur = stack.pop()
            if cur is None:
                continue
            if cur.axis == LEAF_AXIS:
                for pid, p in cur.bucket:
                    if dead and (pid, p) in dead:
                        continue
                    if pid in ex:
                        continue
                    d2 = dist2(q, p)
                    if lim is not None and d2 > lim:
                        continue
                    if len(best) < k:
                        insort(best, (d2, pid))
                    elif d2 < best[-1][0]:
                        best.pop()
                        insort(best, (d2, pid))
                continue
            pid = cur.pid
            if pid is not None and not (dead and (pid, cur.point) in dead) and pid not in ex:
                d2 = dist2(q, cur.point)
                if lim is None or d2 <= lim:
                    if len(best) < k:
                        insort(best, (d2, pid))
                    elif d2 < best[-1][0]:
                        best.pop()
                        insort(best, (d2, pid))
            axis = cur.axis
            d = q[axis] - cur.point[axis]
            near, far = (cur.left, cur.right) if d <= 0 else (cur.right, cur.left)
            # 远侧子树只有在"球面还没被最近邻挡住"时才需要走
            bound = best[-1][0] if len(best) >= k else (lim if lim is not None else float("inf"))
            if d * d <= bound:
                stack.append(far)
            stack.append(near)

    def radius(self, point, r, exclude=None, cap=4096):
        """半径内的所有节点，按距离升序。"""
        if self._root is None:
            return []
        self._queries += 1
        q = (float(point[0]), float(point[1]), float(point[2]))
        r2 = float(r) ** 2
        ex = exclude or ()
        dead = self._dead
        dist2 = self._dist2
        out = []
        stack = [self._root]
        while stack:
            cur = stack.pop()
            if cur is None:
                continue
            if cur.axis == LEAF_AXIS:
                for pid, p in cur.bucket:
                    if dead and (pid, p) in dead:
                        continue
                    if pid in ex:
                        continue
                    d2 = dist2(q, p)
                    if d2 <= r2:
                        out.append((d2, pid))
                continue
            pid = cur.pid
            if pid is not None and not (dead and (pid, cur.point) in dead) and pid not in ex:
                d2 = dist2(q, cur.point)
                if d2 <= r2:
                    out.append((d2, cur.pid))
            axis = cur.axis
            d = q[axis] - cur.point[axis]
            if d * d <= r2:
                stack.append(cur.left)
                stack.append(cur.right)
            else:
                stack.append(cur.left if d <= 0 else cur.right)
            if len(out) >= cap:
                break
        out.sort(key=lambda t: t[0])
        return [(math.sqrt(d2), pid, self._pts[pid]) for d2, pid in out[:cap]]
