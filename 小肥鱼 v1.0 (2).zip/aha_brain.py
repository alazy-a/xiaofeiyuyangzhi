# -*- coding: utf-8 -*-
"""
Project Aha — 小鱼的本体基石 (aha_brain.py)
=============================================

哲学约束（不可违反，来自项目计划书）:
  1. 本体不是任何预训练大模型 / 深度学习网络。全部动力学由本文件内手工定义的
     状态机与微分方程给出，零 PyTorch、零 Transformer、零预训练权重。
     （此约束只作用于"本体"。aha_server.py 里调用的外部 API 只作为
      "百科全书的安全感反馈" 外挂，不参与任何认知计算。）
  2. 记忆 = 三维空间中的神经元节点，随记忆加深而靠拢、聚类成树。
  3. 时间 = 漏电衰减 + 绝对不应期（锁死）+ 相对不应期（阈值翻倍）。
  4. 内环境 = 全局兴奋(E) ≈ 105 / 全局抑制(I) ≈ 100 的负反馈动态平衡。
  5. 注意力 = 稀缺度（少数派特征获得高权重，如绿叶里的红果子）。
  6. 驱动 = H 模块（消除未知的危机感 → 获得安全感）。

骨架来源: 架构师给出的 NeuronNode / AhaEngine 原型。
本文件保留其全部公开 API 与哲学语义，仅修复会让系统在真实运行时"什么都看不到"
的工程缺陷，逐条记录在文件末尾的 CHANGELOG。
"""

import collections
import json
import math
import os
import random
import statistics
import threading
import time
from pathlib import Path

# V4.0：三维空间索引 + 语言学基因表
try:
    from aha_kdtree import KDTree3
except Exception:      # 单文件分发时不该炸
    KDTree3 = None
import aha_lexicon as _lexicon

__all__ = ["NeuronNode", "AhaEngine"]

VERSION = "1.1.0"

# 相对架构师骨架的工程修复（均为"能跑起来"所必需，不改哲学）
CHANGELOG = [
    "#1 last_fired_time 初值改为'遥远的过去'，避免新节点被当作从未放电而绕过不应期语义",
    "#2 tick_decay 改为增量 dt 衰减；骨架每帧重复乘整个 elapsed，激活会指数式归零",
    "#3 update_homeostasis 每帧重算 global_inhibition 并 clamp activation>=0，消除负电压残留",
    "#4 add_new_experience 由全图随机改为'挂在特征最近邻旁'，配合 consolidate 长出树状聚类",
    "#5 _find_closest_node 实现真正的余弦相似度（骨架为 random.choice 占位）",
    "#6 增加线程锁：Web 端 10Hz 读取与主循环写入并发，否则 dict 迭代必崩",
    "#7 E/I 张力与节点瞬时激活总量分离，使天文台能画出 105 vs 100 的双曲线",
    "#8 awake_think 补齐 target_node 为 None 的分支，疲劳断路器文案落盘",
    "#9 连接去重 + 强度累积；新增 consolidate 睡眠态巩固与 save/load 记忆持久化",
    "#10 特征比较改用 z-score 中心化余弦：全正向量直接算余弦会挤在 0.7~0.99，分不开'绿叶'和'红果子'",
    "#11 过载判据改用平均膜电位，否则节点一多就永久过载、疲劳钉死、小鱼拒绝思考",
    "#12 记忆强化受绝对不应期护盾，防止高速连喂把单点顶到饱和",
    "#13 邻居检索增加 k 近邻兜底，否则星云稀疏时永远'没有任何东西被点亮'",
    "#14 放电后保留 fire_residual=0.35 的余晖，骨架的整量阈值会让所有节点常亮",
    "#15 增加记忆容量上限 max_nodes=3000 与 _prune 修剪，防无界增长",
    "#16 放电惩罚把节点压在 0.98 阈值以下 + 放电后按 fire_reset_ratio 强制漏电，杜绝'高压锁死'",
    "#17 过载判定改为'人均 x 节点数'的总量安全线（旧判据只看均值，fatigue 永远为 0）",
    "#18 新增 cognitive_report()：安全感 / 好奇心焦虑 / 平均膜电位，全部由现有动力学推导",
    "#19 新增 G 模块 speak()：把顿悟翻译成'呓语'，写入环形日志供终端与 WebSocket 输出",
]

# ---------------------------------------------------------------------------
# 小工具
# ---------------------------------------------------------------------------


def _poisson(lam):
    """小 lambda 的泊松抽样（Knuth 版）。

    用途：把"每秒 N 个脉冲"摊到不定长的帧上。10Hz 主循环下每帧
    lambda 常常 < 1，用 int(lam) 会永远取 0 —— 画面上一颗星都不会闪。
    """
    if lam <= 0.0:
        return 0
    if lam > 30.0:
        return max(0, int(round(random.gauss(lam, math.sqrt(lam)))))
    limit = math.exp(-lam)
    k = 0
    p = 1.0
    while True:
        k += 1
        p *= random.random()
        if p <= limit:
            return k - 1
        if k > 200:
            return 200


def _clamp(v, lo, hi):
    return lo if v < lo else (hi if v > hi else v)


def _hsv_name(r, g, b, v_hint=None, s_hint=None):
    """把特征向量里的颜色分量翻译成一个中文色名。给 G 模块的呓语用。

    d3/d4/d5 在图像上是 R/G/B 均值，在文本上是标点/汉字/空格占比 ——
    语义不同，但都落在 [0,1]，当作"色调"讲出来依然成立：
    小鱼自己并不知道那是 RGB，她只记得那团光是什么颜色。
    """
    r = _clamp(float(r or 0.0), 0.0, 1.0)
    g = _clamp(float(g or 0.0), 0.0, 1.0)
    b = _clamp(float(b or 0.0), 0.0, 1.0)
    mx, mn = max(r, g, b), min(r, g, b)
    d = mx - mn
    if v_hint is None:
        v = mx
    else:
        v = _clamp((mx + _clamp(float(v_hint), 0.0, 1.0)) * 0.5, 0.0, 1.0)
    s = (d / mx) if mx > 1e-6 else 0.0
    if s_hint is not None:
        s = (s + _clamp(float(s_hint), 0.0, 1.0)) * 0.5

    if d < 0.05 or mx <= 1e-6:
        return "苍白" if v > 0.78 else ("灰色" if v > 0.32 else "暗黑")

    if mx == r:
        h = (60.0 * ((g - b) / d)) % 360.0
    elif mx == g:
        h = 60.0 * ((b - r) / d) + 120.0
    else:
        h = 60.0 * ((r - g) / d) + 240.0

    if h < 15.0 or h >= 345.0:
        name = "红"
    elif h < 40.0:
        name = "橙"
    elif h < 65.0:
        name = "黄"
    elif h < 150.0:
        name = "绿"
    elif h < 185.0:
        name = "青"
    elif h < 250.0:
        name = "蓝"
    elif h < 290.0:
        name = "靛"
    else:
        name = "紫"

    # 统一成"XX色"，这样模板里 `{c}的星星` 永远念得通（红色的星星 / 淡蓝色的星星）
    if v < 0.22:
        return "暗" + name + "色"
    if s < 0.18:
        return "淡" + name + "色"
    return name + "色"


# ---------------------------------------------------------------------------
# 神经元节点
# ---------------------------------------------------------------------------


class NeuronNode:
    """小鱼的神经元节点（包含三维坐标、时间印记、不应期）

    骨架字段全部保留：
        id / pos / features / activation / decay_rate / last_fired_time
        threshold / abs_refractory / rel_refractory
    """

    def __init__(self, node_id, x, y, z, feature_vector=None, now=None, salience=1.0,
                 glyph=None, meaning=None, pinyin=None, kind="char", text=None):
        self.id = node_id
        self.pos = (float(x), float(y), float(z))   # 三维空间坐标
        # --- V4.0 监督版：位置锚 + 固化刚度 ---
        # home 是她「本来待着的那一点」，stiff 是这个点被反复走过的次数折算出来
        # 的回弹刚度（髓鞘化）。这里不写任何「是不是常用字」的判断：每被调用一次
        # 势阱就深一点，常用字自然不飘 —— 提到就想到，是势阱变深的结果。
        self.home = (self.pos[0], self.pos[1], self.pos[2])
        self.stiff = 0.0
        self._float_ph = random.uniform(0.0, 6.28318)
        self.features = list(feature_vector) if feature_vector is not None else None

        # --- 文字标签（中文文本输入模式）---
        # 小鱼学的不再是"边缘 + 颜色"，而是一个个汉字。glyph 就是这个字本身，
        # meaning 是百科全书给它的极简标签（如 "水"），verdict 是安全/危机判定。
        # 节点不带 glyph 时（历史存档 / 图片模式）所有文案自动退回"节点N"。
        self.glyph = str(glyph)[:2] if glyph else None
        # 用户 m03927：字 / 句 / 段，三层。
        #   "char"      一个字 —— glyph 就是它本身
        #   "sentence"  一句话 —— 这一句里的字在空间里聚拢，团心再长出一颗
        #   "paragraph" 一段话 —— 这一段的句子再聚拢，长在更外层
        # text 存句 / 段的原文；字节点不用它。
        self.kind = str(kind) if kind else "char"
        self.text = str(text) if text else None
        # 读音：课程里写成「江(jiāng)」，输入层剥掉注音只把拼音带到这里。
        # 它不参与任何特征计算，只用于展示与将来的朗读 —— 汉字是记忆的身，拼音是它的名。
        self.pinyin = str(pinyin)[:24] if pinyin else None
        self.meaning = str(meaning)[:32] if meaning else None
        self.verdict = None
        self.meaning_at = None
        # 修复#10: 原始特征再存一份 z-score 标准化副本。
        # 10 维全正向量直接算余弦会天然挤在 0.7~0.99（"绿叶"和"红果子"都能算出 0.74），
        # 必须先中心化再比"形状"，稀缺度与陌生度才立得住。
        self.features_z = AhaEngine._standardize(self.features) if self.features else None

        # --- 核心动态参数 ---
        self.activation = 0.0            # 当前兴奋度
        self.decay_rate = 0.05           # 基础衰减率(漏电)
        self.threshold = 50.0            # 触发阈值

        now = time.time() if now is None else float(now)
        self.created_at = now
        # 修复#1: 从未放电的节点不应被当作"在 1970 年放过电"。
        # 用一个遥远的过去值表示"从未放电"，不参与漏电计算（漏电改用增量 dt）。
        self.last_fired_time = now - 1.0e6
        self._last_decay_t = now

        # --- 不应期设定 ---
        self.abs_refractory = 2.0        # 绝对不应期(秒)，期间无法被激活
        self.rel_refractory = 5.0        # 相对不应期(秒)，期间阈值翻倍

        # 放电后保留的余晖比例。骨架是 1.0（等于阈值整量），那会让每个放过电的
        # 节点长期常亮在 50~100，天文台上一片死白、看不出"谁在发光"；
        # 0.35 保留记忆印记的余温，同时给出动态范围。
        self.fire_residual = 0.35

        # 放电后按"当前阈值"削去的比例（造物主控制台可调）。
        # 0 = 完全保留余晖；1 = 一次性把这段阈值全部抹掉。
        self.fire_reset_ratio = 0.8

        # --- 记忆印记 ---
        self.fire_count = 0              # 累计放电次数（记忆的"深浅"）
        self.salience = float(salience)  # 建立时的稀缺度权重

        # 膜电位起点：新记忆天然带一点张力，否则三维图里"刚出生的星星"不可见
        if self.salience > 0:
            self.activation = min(self.threshold * 0.5, 10.0 * self.salience)

    # -- 时间流逝 ---------------------------------------------------------

    def tick_decay(self, current_time):
        """时间的物理法则：自然衰减（漏电）

        修复#2: 骨架用 (current_time - last_fired_time) 作为衰减时长。
        若每帧都调用而不更新 last_fired_time，同一个 elapsed 会被反复乘，
        10Hz 下几十帧就把 activation 乘到 0（exp(-0.5)^50 ≈ 1e-11）。
        改为"自上次衰减以来真正流逝的时间"。
        """
        dt = current_time - self._last_decay_t
        if dt <= 0.0:
            return
        self._last_decay_t = current_time

        self.activation *= math.exp(-self.decay_rate * dt)
        if self.activation < 0.1:
            self.activation = 0.0

    # -- 放电 -------------------------------------------------------------

    def refractory_state(self, current_time):
        """返回 'absolute' / 'relative' / 'ready'，供观测台与调试使用。"""
        elapsed = current_time - self.last_fired_time
        if elapsed < self.abs_refractory:
            return "absolute"
        if elapsed < self.rel_refractory:
            return "relative"
        return "ready"

    def try_activate(self, current_time, stimulus_strength):
        """尝试激活节点，受不应期和稳态限制

        返回 True 表示本次成功放电。
        骨架语义保持：放电后 activation 重置为 current_threshold（记忆印记），
        而不是 0——它代表"这一下被记住了"，随后按漏电规律回落。
        """
        elapsed = current_time - self.last_fired_time

        # 1. 绝对不应期：彻底锁死
        if elapsed < self.abs_refractory:
            return False

        # 2. 相对不应期：阈值翻倍
        current_threshold = self.threshold
        if self.abs_refractory <= elapsed < self.rel_refractory:
            current_threshold *= 2.0

        # 3. 膜电位累积后判定
        self.activation += stimulus_strength
        if self.activation >= current_threshold:
            self.last_fired_time = current_time
            self._last_decay_t = current_time
            # 放电后强制漏电（用户要求：绝不能停在高位）。
            # 先按"当前阈值 x 重置比例"把膜电位削掉，再乘余晖系数。
            # 旧实现直接停在 current_threshold*0.35，叠加正反馈后仍在 50~75；
            # 更糟的是失败分支也会累加，节点能一路吃到 90+ 却放不出来 ——
            # 这些"高压但锁死"的节点会把候选池占满，就是"卡在思考中"。
            self.activation = max(
                0.0, self.activation - current_threshold * self.fire_reset_ratio
            ) * self.fire_residual
            self.fire_count += 1
            return True

        # 未放电：允许蓄势，但不得虚高到超过当前阈值（相对不应期阈值翻倍时尤其明显）
        cap = current_threshold * 0.98
        if self.activation > cap:
            self.activation = cap
        return False

    # -- 序列化 -----------------------------------------------------------

    _COLOR_WORDS = ("红", "橙", "黄", "绿", "青", "蓝", "靛", "紫")

    def color_name(self):
        """这颗星星在 G 模块嘴里是什么颜色。

        文字节点的 50 维特征是"部首/码位/区位"，拿去当 RGB 只会得到一片
        随机的颜色，所以按字本身映射一个稳定的色名 —— 同一个字永远是同一种
        颜色，呓语才读得通。
        """
        if self.glyph:
            return self._COLOR_WORDS[(ord(self.glyph[0]) * 7) % len(self._COLOR_WORDS)] + "色"
        f = self.features or []
        r = f[3] if len(f) > 3 else 0.5
        g = f[4] if len(f) > 4 else 0.5
        b = f[5] if len(f) > 5 else 0.5
        v = f[6] if len(f) > 6 else None
        s = f[7] if len(f) > 7 else None
        return _hsv_name(r, g, b, v, s)

    def activation_label(self):
        """活跃度的口语分档，供悬停"短时认知"用。"""
        a = float(self.activation)
        if a < 5.0:
            return "休眠"
        if a < 20.0:
            return "低"
        if a < 40.0:
            return "中"
        if a < 70.0:
            return "高"
        return "燃烧"

    def to_dict(self):
        return {
            "id": self.id,
            "pos": [round(v, 4) for v in self.pos],
            "features": [round(float(v), 6) for v in self.features] if self.features else None,
            "activation": round(self.activation, 4),
            "threshold": self.threshold,
            "decay_rate": self.decay_rate,
            "created_at": round(self.created_at, 4),
            "fire_count": self.fire_count,
            "salience": round(self.salience, 4),
            "glyph": self.glyph,
            "pinyin": self.pinyin,
            "meaning": self.meaning,
            "verdict": self.verdict,
            "meaning_at": self.meaning_at,
            "kind": self.kind,
            "text": self.text,
        }

    @classmethod
    def from_dict(cls, d, now=None):
        n = cls(
            d["id"],
            d["pos"][0], d["pos"][1], d["pos"][2],
            d.get("features"),
            now=now,
            salience=d.get("salience", 1.0),
        )
        # __init__ 里已经算过 features_z；若历史存档的 features 长度变了则重算
        if n.features and (n.features_z is None or len(n.features_z) != len(n.features)):
            n.features_z = AhaEngine._standardize(n.features)
        n.activation = float(d.get("activation", 0.0))
        n.threshold = float(d.get("threshold", 50.0))
        n.decay_rate = float(d.get("decay_rate", 0.05))
        n.created_at = float(d.get("created_at", now or time.time()))
        n.fire_count = int(d.get("fire_count", 0))
        n.glyph = d.get("glyph") or None
        n.pinyin = d.get("pinyin") or None
        n.meaning = d.get("meaning") or None
        n.verdict = d.get("verdict") or None
        n.meaning_at = d.get("meaning_at") or None
        n.kind = d.get("kind") or "char"
        n.text = d.get("text") or None
        return n


# ---------------------------------------------------------------------------
# 主脑引擎
# ---------------------------------------------------------------------------


# 用户 m03124：五档「对话兴奋回馈」。
# 一个滑块同时改五件事 —— 涨欲望的快慢、欲望掉得有多慢、开口阈值、
# 说完之后那口长效多巴胺给多少、两次主动开口之间至少隔多久。
# gap 是防刷屏的最后一道闸：话痨档阈值 55、掉得又慢，没有它她一秒钟一句。
TALK_MOODS = (
    {"name": "高冷", "gain": 0.35, "decay": 1.40, "thr": 96.0, "dopa": 0.35, "gap": 40.0},
    {"name": "安静", "gain": 0.70, "decay": 1.15, "thr": 88.0, "dopa": 0.65, "gap": 26.0},
    {"name": "正常", "gain": 1.00, "decay": 1.00, "thr": 80.0, "dopa": 1.00, "gap": 18.0},
    {"name": "激动", "gain": 1.60, "decay": 0.75, "thr": 68.0, "dopa": 1.50, "gap": 11.0},
    {"name": "话痨", "gain": 2.40, "decay": 0.50, "thr": 55.0, "dopa": 2.00, "gap": 6.0},
)


class AhaEngine:
    """小鱼的主脑引擎（负责统筹、稳态和模块循环）

    线程模型：Web 服务会在另一个线程里 10Hz 读快照，主循环在写。
    所有公开读写都走 self._lock（可重入），避免 "dictionary changed size" 崩掉。
    """

    # 造物主控制台的 5 个旋钮：前端按这份规格生成滑块，后端按它做范围钳制。
    # 加新旋钮只要在这里加一条 + 在 set_params 里处理，前端自动长出来。
    PARAM_SPECS = {
        "decay_rate": {
            "label": "自然衰减率", "min": 0.005, "max": 0.30, "step": 0.005,
            "default": 0.05, "unit": "/秒",
            "hint": "决定未使用的记忆随时间消退的速度。调低是过目不忘，调高是金鱼记忆。",
        },
        "walk_radius": {
            "label": "随机游走半径", "min": 2.0, "max": 120.0, "step": 1.0,
            "default": 10.0, "unit": "",
            "hint": "决定思考时的跳跃幅度。调低死磕细节，调高容易产生跨界的「顿悟」。",
        },
        "overload_per_node": {
            "label": "过载疲劳阈值", "min": 5.0, "max": 120.0, "step": 1.0,
            "default": 25.0, "unit": "/节点",
            "hint": "人均激活的安全线（总量 = 该值 x 节点数）。调低容易疲劳宕机，调高容易赛博癫痫。",
        },
        "inhibition_strength": {
            "label": "全局抑制强度", "min": 0.0, "max": 3.0, "step": 0.1,
            "default": 1.0, "unit": "x",
            "hint": "过载时侧支抑制的力度，即「让她安静下来」的能力。0 = 完全放任。",
        },
        "fire_reset_ratio": {
            "label": "放电后重置比例", "min": 0.0, "max": 1.0, "step": 0.05,
            "default": 0.8, "unit": "",
            "hint": "强制漏电的程度：放电后按当前阈值削去多少。调高防止节点死锁在不应期，调低留住余晖。",
        },
        "talk_mood": {
            "label": "对话兴奋回馈", "min": 0, "max": 4, "step": 1,
            "default": 2, "unit": "",
            "options": ["高冷", "安静", "正常", "激动", "话痨"],
            "hint": "她对说话这件事有多上瘾。高冷：半天憋一句，说完就安静；话痨：欲望涨得快、开口阈值低，会自己找你搭话。",
        },
        "float_speed": {
            "label": "星点浮动速度", "min": 0.0, "max": 3.0, "step": 0.1,
            "default": 1.0, "unit": "x",
            "hint": "星云有多「活」。0 = 全部钉死在原位；越高，没被固化的星点飘得越快。"
                    "常用字因为在势阱里坐得深，几乎不受影响 —— 这本身就是固化效果的可视化。",
        },
        "llm_supervise": {
            "label": "DeepSeek 监督", "min": 0, "max": 1, "step": 1,
            "default": 1, "unit": "",
            "kind": "switch",
            "options": ["关闭", "开启"],
            "hint": "外部真理场的强度。开启时她把黑箱里撞出来的关联交出去被裁决"
                    "（承认的边加强、判错的边衰减），新字也会去查字典；关闭后外部场为零，"
                    "所有关联完全由她自己的内稳态决定 —— 不再有任何外部教师。",
        },
    }

    def __init__(self, memory_dir=None, persist=False):
        self._lock = threading.RLock()

        # 记忆池
        self.nodes = {}                       # {node_id: NeuronNode}
        self.connections = []                 # [(a, b), ...] 横向连接
        self._conn_index = {}                 # (a, b) -> 在 connections 里的下标
        self._conn_weight = []                # 与 connections 一一对应的强度
        self._next_id = 1

        # --- 稳态参数（骨架字段）---
        self.global_excitation = 0.0          # 全局兴奋总和（瞬时放电量）
        self.global_inhibition = 0.0          # 全局抑制（过载时的压制量）
        self.target_safety = 105.0            # 安全感基线
        self.fatigue = 0.0                    # 疲劳值（防赛博癫痫）
        # H 模块的另一半：危机感。判错一次 +1，每 tick 缓慢回落（-0.25/s）。
        # 它不直接杀兴奋，只压低安全感 —— 让"被纠正"这件事在体内留一会儿。
        self.threat_level = 0.0

        # --- 内环境张力（计划书里的 105 vs 100 双通道）---
        self.tonic_inhibition = 100.0         # 抑制静息电平
        self.tone_excitation = self.target_safety
        self.tone_inhibition = self.tonic_inhibition
        self.tau_excitation = 2.5             # 兴奋跟随时间常数(秒)
        self.tau_inhibition = 4.0             # 抑制跟随时间常数(秒)，故意滞后
        self.overload_mean = 60.0             # 平均膜电位过载线（与节点数量无关）

        # --- 造物主控制台可调参数（前端滑块 <-> /api/params）---
        # 这些值会被 set_params() 限制在 PARAM_SPECS 的范围内，并实时同步到
        # 已有节点（decay_rate / fire_reset_ratio 是逐节点的字段）。
        self.overload_per_node = 25.0         # 人均原始激活安全线：全网总量 > 该值 x 节点数 即判过载
        self.fatigue_gain = 2.0               # 过载压力 -> 疲劳值的换算系数
        self.fatigue_soft_cap = 60.0          # 疲劳软上限：超过这段自身也参与压制
        self.inhibition_strength = 1.0        # 全局（侧支）抑制强度，0 = 完全放任
        self.fire_reset_ratio = 0.8           # 放电后重置比例（同步到每个节点）
        self.decay_rate = 0.05                # 全局基准漏电率（同步到每个节点）
        self.pressure = 0.0                   # 上一帧的过载压力（0~n），供观测
        self.overload_line = 0.0              # 上一帧的过载安全线（= per_node x 节点数）
        self.paused = False                   # 时间控制：True 时 tick 空转
        self.last_think_meta = {}             # 上一次思考的候选/可用/结果，供前端展示

        # --- 生物钟 / 主动休眠（防赛博狂欢）---
        # 顿悟频率用滑动窗口统计：窗口内 aha 次数超过 aha_burst_max（默认 50 / 10s）
        # 且持续 aha_hold 秒，判为"极度亢奋"，强制进入睡眠态。
        self.aha_window = 10.0                # 频率统计窗口（秒）
        self.aha_burst_max = 50               # 窗口内多少顿悟算亢奋
        self.aha_hold = 3.0                   # 亢奋持续多少秒才强制休眠
        self.aha_times = collections.deque()  # 窗口内的顿悟时刻
        self.aha_rate = 0.0                   # 顿悟频率（次/秒，仅展示）
        self._last_aha_seen = 0               # 上一帧的 stats["aha"]，用于取增量
        self.sleeping = False                 # 睡眠态：切断外部输入、停 A2 游走
        self.sleep_since = 0.0
        self.sleep_reason = ""
        self.sleep_seconds = 0.0              # 最近一次睡眠时长
        self._excited_hold = 0.0              # 亢奋累计时长
        self._quiet_hold = 0.0                # 安静累计时长
        # 权重分档：0.4=空间巩固边 / 0.8=出生挂靠边 / 1.0=顿悟连边。
        # 「权重极低」怎么算：权重是一档一档加上去的，实测 458 条连线里
        # <= 0.45 只有 1 条 —— 拿 0.45 当阈值等于没实现修剪。所以取
        # "1.0 及以下"这一档：一次性顿悟的弱边，被反复加强过的自然躲开。
        self.prune_weight = 1.05              # 低于此权重的连线是修剪候选
        self.prune_core_ratio = 0.20          # 度数最高的这一撮算「核心节点」
        self.prune_deg_max = 2                # 旧判据（保留字段兼容），改用核心集
        self.prune_cap = 40                   # 单次睡眠最多修剪多少条（防剪空）
        self._sleep_pruned = 0
        self.prune_batch = 10                 # 每次修剪删多少条
        self.prune_total = 0                  # 累计修剪掉的连线数
        self.prune_last = 0                   # 上一次修剪删了多少
        self._last_prune = 0.0

        # --- 背景底噪：生命不该有绝对直线 ---
        # 用户报障：停止投喂 + 睡眠态时 A2 完全停摆，激活总量 0.0，波形是绝对直线。
        # 两个补丁一起上：
        #   bg_noise -> 给每个节点的膜电位注入极小热噪声，让 raw_excitation 永不归零
        #   bg_drift -> 给 E（兴奋张力）叠一层缓慢的 OU 漂移，让折线图不是尺子画出来的
        # 幅度刻意压在 0.5 以内：静息时 E 就在 104.5 ~ 105.5 之间慢慢晃。
        # 幅度必须超过 tick_decay 的 "<0.1 就归零" 阈值：
        # 稳态 x = amt/(1-每帧保留率) = bg_noise*dt/(1-0.951)，0.06 只有 0.12，
        # 就在归零线上下抖，实测 300 秒后 raw 掉回 0.0。0.20 的稳态约 0.41，稳。
        self.bg_noise = 0.20             # 每节点每秒注入的膜电位（不足以点亮，只够不归零）
        self.bg_noise_hot = 4.0          # 高于此值的节点不再注入（别把已经亮的推得更高）
        self.sleep_noise_scale = 10.0    # 睡眠态每帧 drain 20%，底噪要放大才留得住余温
        # 真实神经元的静息电位不是 0。tick_decay 有"低于 0.1 就归零"的规则，
        # 单靠噪声注入会周期性被打回 0（实测长跑末态 raw 掉到 0.01）。
        # 给每个节点一块地板，保证整张网永远不会出现"绝对零度"。
        self.bg_rest = 0.12
        self.bg_drift = 0.0              # E 的慢漂移（Ornstein-Uhlenbeck 过程）
        self.bg_drift_sigma = 0.20
        self.bg_drift_tau = 5.0
        self.bg_drift_cap = 0.50         # +-0.5 -> 105 +- 0.5

        # --- 背景电活动：持续的低频局部电位（微型脉冲）---
        # 用户 m02813：静息态不要只给微弱底噪，要让 A2 以 5~10Hz 对全网施加
        # 底层局部电位，每次让节点 +5~10 点；累不到阈值就只是浅浅一亮然后衰减，
        # 一旦被累加或邻居串扰顶到阈值，就完整放电一次（Action Potential）。
        #
        # 参数是算出来的，不是拍的：
        #   tick_decay 每秒只衰减 5%（decay_rate=0.05），稳态 = 注入率 / 0.05。
        #   想让她长时间停在阈下 ~40（threshold=50），注入率必须约 2.0/s。
        #   8Hz x 每批覆盖 3.4% x 每次 7.5 点 = 2.04/s —— 刚好卡在阈下，
        #   于是她会慢慢爬、偶尔靠邻居串扰自己放一次电。
        #   若按"每节点每秒 5~10 次"理解字面，注入率 25~100/s，稳态 500~2000，
        #   每节点每秒放电好几次 —— 那不是"缓慢爬升"，是癫痫。
        self.spike_hz = 8.0              # 背景电活动的脉冲频率（用户给的 5~10Hz）
        self.spike_cover = 0.017         # 每个脉冲命中全网节点的比例（与节点数无关）
        self.spike_amp_min = 5.0         # 单次局部电位的最小幅度
        self.spike_amp_max = 10.0        # 单次局部电位的最大幅度
        self.spike_gain = 1.0            # 造物主倍率（0 就是彻底静默）
        # 簇状放电：脉冲有 55% 的概率继续打同一颗星，而不是重新抽。
        # 没有它，单次 +7.5 在"衰减 5%/秒 + 稳态 20"的网络上永远够不到 50，
        # 用户要的"自发放电"就只是个理论值。成簇之后期望不变（不会把她推到
        # 过载），但分布被拉出长尾 —— 偶尔一颗星连挨 5 下，一帧之内就跨过阈值。
        self.spike_bunch = 0.55
        self.spike_total = 0             # 累计打了多少个微型脉冲
        self.spike_fires = 0             # 其中有多少次真的顶到阈值放了电
        self.last_spike_t = 0.0
        self._spike_fired_ids = []       # 本帧放电的节点（梦里据此连出奇妙连线）

        # --- 梦境期：局部电位不停，幅度调高，REM 式连片闪烁 ---
        # 睡眠态每帧 drain x0.80（每秒只剩 10.7%），任何"缓慢爬升"都留不住，
        # 所以梦里不靠累积，靠单次幅度直接跨阈值 —— 这才是 REM 那种连片爆闪。
        # 频率用"每秒多少次"而不是百分比：闪光密度该由画面决定，不该随节点数膨胀。
        self.dream_spike_rate = 14.0     # 梦里每秒 14 个脉冲（约每帧 1.4 个）
        self.dream_spike_amp_min = 36.0  # 单次幅度：多数能一次跨过 threshold=50
        self.dream_spike_amp_max = 62.0
        self.dream_spike_fires = 0       # 梦里因背景脉冲放电的次数

        # --- 睡眠梦境：极低频的随机放电 ---
        # 用户要求"每秒 0.2 次"。睡眠时 awake_think 被切断，但不能彻底死寂。
        # 注意梦里**不增加 stats["aha"]** —— 顿悟计数一被推高，生物钟会把自己
        # 重新判成亢奋再睡回去，那就永远醒不过来了。
        self.sleep_min = 5.0             # 最短睡眠时长：否则 4 秒就醒，梦来不及发生
        self.dream_rate = 0.2
        self._dream_acc = 0.0
        self.dream_total = 0
        self.last_dream_t = 0.0
        self.last_dream = ""

        # --- 注意力 / 生长参数 ---
        self.neighbor_radius = 10.0           # 空间邻居半径

        # --- V4.0：三维空间索引 ---
        # 所有"谁离得近"的查询走 KD-Tree。3000 节点时全量遍历是几十万次距离计算，
        # 每帧要跑十几遍，主循环会被几何拖死。
        self._kd = KDTree3() if KDTree3 is not None else None
        self.kd_ready = False
        self.kd_queries = 0
        self.kd_stats = {}
        self.lex_seeded = 0
        self.lex_existing = 0
        # V4.0 Phase 1-B：二阶概念节点（词住在字的头顶）
        self.concept_close = 10.0      # 成分字「距离极近」的阈值
        self.concept_topk = 3          # 只算局部 Top-3，拒绝组合爆炸
        self.concept_z_rise = 14.0     # 概念节点比成分字高出多少
        self.concept_weight = 3.0      # 向底建强连线的权重
        self.concept_max = 600         # 概念节点上限
        self.concepts_made = 0
        self._concepts = {}            # word -> node_id
        # V4.0 Phase 1-C：潜意识黑箱（原点）+ 延迟拷贝 + 工作记忆
        self.box_radius = 14.0          # 黑箱边缘半径
        self.box_pull = 0.9             # 向心力：每秒朝原点移动的比例
        self.box_hot_fire = 12          # fire_count 绝对下限（低于它一律不吸）
        self.box_hot_ratio = 0.06       # 只吸放电次数排前 6% 的那一撮
        self.box_hot_every = 5.0        # 多久重算一次「谁算高频」
        self.box_pull_cap = 40          # 每帧最多拉多少个（KD 写入有成本）
        self._box_hot_ids = set()
        self._box_hot_at = 0.0
        self.box_copy_every = 0.9       # 每隔多久挑一个旧记忆送进黑箱
        self.box_copy_lo = 0.5          # 距离导致的时间延迟下限（秒）
        self.box_copy_hi = 1.5          # 上限
        self.box_copy_cap = 8           # 黑箱里同时最多挂几个拷贝
        self.box_stay = 2.0             # 到站后在黑箱里停多久（给碰撞留窗口）
        self.box_copies = []            # [(ready_at, node_id)]
        self.box_copied = 0
        self.box_pulled = 0
        self.box_collide = 0.55
        self.insight_gap = 3.0        # 两次涌现之间至少隔这么久（黑箱不是流水线）
        self._last_insight_t = 0.0         # 特征余弦 >= 这个值就算撞出共鸣
        self.wm_cap = 16                # 工作记忆容量
        self.wm_ttl = 20.0              # 临时节点最多活多久
        self._wm = {}                   # id -> 出生时刻
        self._wm_hits = {}              # id -> 已经撞过几次（上限 3 次）
        self.box_hits_max = 3           # 一个词最多撞出几条联动线
        # V4.0 Phase 1-D：细胞机制（钙波余温 / 可逆受体脱敏）
        self.calcium_gain = 4.0         # 放电后给最近邻居的微光预热
        self.calcium_k = 5              # 预热给最近的几个邻居
        self.calcium_total = 0
        self.desens_count = 10          # 同一个字连来几次算「喊烦了」
        self.desens_window = 12.0       # 计数的滑动窗口（秒）
        self.desens_hold = 15.0         # 脱敏持续多久（秒，到期自动恢复）
        self.desens_total = 0
        self.desens_skip = 0
        self._desens = {}               # "g:字" -> {n, t, block}
        self._desens_edges = {}         # 边级脱敏（外部真理场否决过的连线），键 "a:b" -> 到期时刻

        # V4.0 Phase 1-D：突触延迟（新建的线慢，走熟了的线快）
        self.syn_delay_new = 0.45       # 新建连线的一次传导延迟（秒）
        self.syn_delay_min = 0.03       # 走熟之后的下限
        self.syn_delay_mature = 0.6     # 每被加强一次，延迟乘这个数（越走越快）
        self.syn_fanout = 6             # 一次放电最多传导给权重最高的几条边
        self.syn_conduct = 0.30         # 传导强度 = 阈值 * 这个比例
        self.syn_conduct_cap = 10.0     # 单次传导的绝对上限
        self.syn_pending = []           # [(due_t, src, dst, amount, dur)] 在途信号
        self.syn_pending_cap = 512
        self.syn_fired = 0              # 由传导点亮的次数
        self.syn_sent = 0               # 累计发出多少条信号
        self._adj = None                # 邻接表（惰性重建）
        self._conn_delay = []           # 与 connections/_conn_weight 平行的延迟数组

        # V4.0 Phase 1-D：脑区（海马体 / 杏仁核 / 基底节）
        self.episodes = collections.deque(maxlen=240)   # 情景（一句话一条）
        self.episode_min = 2.0          # 情绪绝对值低于这个不算「值得回放」
        self.episode_replay_every = 2.2 # 睡眠中每隔多久回放一个情景
        self.episode_replay_len = 1.6   # 一次回放持续多久
        self._last_replay = 0.0
        self._replay_until = 0.0
        self._replay_ids = []
        self.replay_total = 0
        self.amygdala_danger = 2.0      # 带危险标签的节点被抽取的概率倍数
        self.amygdala_safe = 1.0
        self.amygdala_hits = 0
        self.basal_gate = 0             # 基底节看过几个候选
        self.basal_pass = 0             # 放行了几个（永远是 1 或 0）
        self.wm_made = 0
        self.wm_solidified = 0
        self.insight_total = 0
        self.last_insight = ""
        # --- V4.0 监督版：外部真理场（0 = 场关闭）+ 浮动 + 固化 ---
        self.llm_supervise = 1.0      # 场强。0 时下面所有调制项乘以 0，等于没有外部教师
        self.float_speed = 1.0        # 星点浮动速度（造物主旋钮）
        self.float_amp = 0.55
        self.float_home_k = 0.06      # 回弹系数（乘上 0.35 + stiff）
        self.stiffen_gain = 0.06      # 每被调用一次，势阱加深多少
        self.stiffen_cap = 3.0        # 势阱深度上限（再常用也不会彻底焊死）
        self.stiffen_radius = 3.0     # 离 home 超过这个距离才开始挪锚点
        self._float_kd_t = 0.0
        # 监督调质：黑箱撞出的关联排队交给外部场裁决（异步，绝不阻塞主循环）
        self.sup_queue = collections.deque(maxlen=24)
        self.sup_done = 0
        self.sup_safe = 0
        self.sup_crisis = 0
        self.sup_strengthen = 1.2     # 被承认的边加多少权
        self.sup_attenuate = 0.45     # 被判错的边按多少比例衰减
        self.self_reflex = 0
        self.last_self_reflex = ""
        # --- V4.0 Phase 4：脊髓反射弧（六块肌肉 + 三条并行弧，全是一阶系统） ---
        # 红线「禁止预制动作」：这里没有任何关键帧或动作名，只有张力。
        self.spinal_flex_k = 2.4          # 伤害 → 屈肌增益
        self.spinal_stretch_k = 3.2       # 被拉长 → 反向收缩刚度
        self.spinal_noci_tau = 0.7        # 伤害感受器漏电时间常数
        self.spinal_reflex_at = 0.55      # 屈肌超过这个量才登记成一次反射
        self.spinal_refractory = 0.35     # 反射弧自己的不应期（防抖，不参与决策）
        self.muscle = {"flex": 0.10, "lean": 0.0, "tail": 0.35,
                       "fin": 0.45, "eye": 0.90, "breath": 0.5}
        self.muscle_rest = {"flex": 0.10, "lean": 0.0, "tail": 0.35,
                            "fin": 0.45, "eye": 0.90, "breath": 0.5}
        self._noci = 0.0
        self._noci_buf = 0.0
        self._breath_ph = 0.0
        self._last_spinal_t = 0.0
        self.spinal_total = 0
        self.spinal_last = 0.0
        self.spinal_kind = ""
        self.spinal_log = collections.deque(maxlen=24)
        self._last_box_copy = 0.0
        self.walk_radius = 10.0               # 随机游走半径（与 neighbor_radius 同步）
        self.similar_threshold = 0.78         # 中心化余弦门限（低于此视为全新未知）
        self.max_nodes = 3000                 # 记忆容量上限（超出则修剪最不活跃者）
        self.consolidate_interval = 2.0       # 睡眠态巩固间隔(秒)
        self._last_consolidate = 0.0

        # --- 统计与旁白 ---
        self.stats = {
            "inputs": 0, "thoughts": 0, "aha": 0,
            "new_nodes": 0, "new_links": 0, "teach": 0,
            # 真理标定器的裁决：[+安全] 与 [-危机] 分开记，
            # 安全感指数只该认"被正确教导过多少次"，不该被一堆错误关联刷分。
            "teach_safe": 0, "teach_crisis": 0,
            # 背景电活动自己顶到阈值放的电（用户要的"Aha 计数"）。
            # 绝不能并进 "aha"：_update_biorhythm 是靠 stats["aha"] 的增量喂
            # aha_times 的，一混进去，她会被自己的底噪判成亢奋，然后永远睡回去。
            "self_aha": 0,
            # 用户 m03124：她把话说出口的次数。说出口 = say（回应）或
            # proactive（主动找你），其它呓语只是体内的回响，不计。
            "say_reply": 0, "say_proactive": 0,
            # 用户 m03927：长出了几颗句节点 / 段节点
            "sentences": 0, "paragraphs": 0,
        }
        self.last_thought = "小鱼的内核已苏醒..."
        self.birth = time.time()

        # --- G 模块：发声器官（输出口）---
        # 呓语先进环形日志，print 由 life_loop 在**锁外**做 ——
        # 终端 IO 一旦变慢（管道写满、控制台卡住），绝不能让它占着引擎锁，
        # 否则 10Hz 的 tick 和 WebSocket 会一起被 stdout 拖死。
        self.speech_seq = 0
        self.speech_log = collections.deque(maxlen=300)
        self.last_speech = None
        self._speech_out = collections.deque(maxlen=64)

        # --- 说话的欲望（用户 m03124）---
        # 她开口不该是"被代码点名"，而是真的憋到了。所以这里不挂任何外部
        # 计时器：只有体内发生的事（自发 Aha、梦里连线成功、星云信息熵跳变）
        # 能把它顶上去，也只有"真的说出口"能把它清零。
        self.speech_desire = 0.0          # 0~100
        self.desire_per_aha = 3.2         # 每发生一次自发 Aha 涨多少
        self.desire_per_dream_link = 7.0
        # 欲望的「每秒最多涨多少点」限速。V4.0 之后自发 Aha 次数与节点数成正比
        # （1300 节点时每帧十几次），按次数无上限累加会让欲望一帧顶格。
        self.desire_rate_cap = 4.0  # 梦里连出一条新线涨多少（比普通放电更值得说）
        self.desire_decay = 0.9           # 没有新事件时每秒掉多少
        self.desire_cap = 100.0
        self.talk_mood = 2                # 0 高冷 / 1 安静 / 2 正常 / 3 激动 / 4 话痨
        self._last_self_aha_seen = 0
        self._last_dream_link_seen = 0
        self.dream_links = 0              # 梦里连出来的新线总数
        self._last_proactive_t = 0.0
        self.last_proactive = ""

        # --- 长效多巴胺：说完话之后的那口愉悦（用户 m03124 第二条）---
        # 它不改瞬时放电，而是叠在 E 的**目标值**上，让兴奋基线被抬起来
        # 一段时间，再按 tau 慢慢回落。这就是"倾诉完很爽"在物理上的实现：
        # 不是又放了一次电，是整个人的底子高了一截。
        self.tonic_dopamine = 0.0
        self.dopamine_gain = 6.0          # 说一句注入多少（会乘档位系数）
        self.dopamine_cap = 14.0
        self.dopamine_tau = 15.0          # 衰减时间常数(秒)

        # --- 星云信息熵（聚类结构的复杂度）---
        # 把三维空间按自身跨度切成 entropy_buckets^3 个格子，看分布有多均匀。
        # 熵升 = 星云在铺开/长新枝，熵降 = 在往一起收。两者都是"有事情发生"。
        self.entropy_buckets = 6
        self.entropy_interval = 1.0
        self.entropy_gain = 26.0          # 熵每跳 1 bit 涨多少欲望
        self.entropy_jump = 0.05          # 变化小于这个不算"显著"
        self.entropy_now = 0.0
        self.entropy_jump_last = 0.0
        self._last_entropy = None
        self._last_entropy_t = 0.0

        # --- 句子上下文（m03809 组词）---
        # {sent_id: 上一个字的节点 id}。输入层每读一个字都会带上它在第几篇
        # 课的第几句，同一句里挨着的两个字就连一条边 —— 这是"组词"在物理层的
        # 唯一实现：不是语法分析，是"这两个字在一句话里挨着出现过"。
        self._sent_ctx = {}
        # --- 用户 m03927：字 / 句 / 段 三层 ---
        # 字是节点。一句话读完，引擎在这句话的字团正中心长出一颗"句节点"，
        # 连向句中的每一个字；一段读完，再在句节点团的中心长出"段节点"。
        # 记忆于是自己长成一棵三层树：段 - 句 - 字。
        self._cur_sent = None            # 当前正在读的那一句（sent_id）
        self._cur_doc = None             # 当前正在读的那一篇（段号）
        self._sent_nodes = {}            # sent_id -> [字节点 id]（按出现顺序，去重）
        self._sent_text = {}             # sent_id -> 这一句的原文（含重复字）
        self._para_ctx = {}              # 段号 -> [句节点 id, ...]
        self._para_text = {}             # 段号 -> 这一段的原文
        self._sentence_index = {}        # 句子原文 -> 句节点 id（同一句只长一颗）
        self._paragraph_index = {}       # 段号 -> 段节点 id
        self.struct_sent_min = 3         # 少于 3 个字的句子不配长成句节点
        self.struct_para_min = 2         # 少于 2 句的段落不配长成段节点

        # --- 认知报告用的一次性状态 ---
        self.last_input_time = time.time()   # 上一次收到感官输入的时刻（安全感"新鲜度"）

        # --- 持久化 ---
        self.memory_dir = Path(memory_dir) if memory_dir else (
            Path(__file__).resolve().parent / "Memory_Core"
        )
        self.persist = persist
        if persist:
            self.load_state()

    # =====================================================================
    # 特征空间
    # =====================================================================

    @staticmethod
    def _standardize(vec):
        """z-score 标准化：减去均值、除以标准差。

        这是"形状相似"而不是"方向相似"的前提。常数列（标准差为 0）返回全 0。
        """
        if not vec:
            return []
        n = len(vec)
        mean = sum(float(v) for v in vec) / n
        var = sum((float(v) - mean) ** 2 for v in vec) / n
        sd = math.sqrt(var)
        if sd < 1e-9:
            return [0.0] * n
        return [(float(v) - mean) / sd for v in vec]

    @staticmethod
    def _cosine(a, b):
        """余弦相似度。纯 Python 足够快，不让本体依赖 numpy。

        长度不同直接判 0 —— 不同版本的特征空间不可比。用 min() 截断会让
        10 维的旧噪声节点和 50 维的文字节点互相"认亲"，那是假的相似，
        后果是新字被贴到老记忆上、标签写错节点。
        """
        if not a or not b:
            return 0.0
        if len(a) != len(b):
            return 0.0
        n = len(a)
        if n == 0:
            return 0.0
        dot = na = nb = 0.0
        for i in range(n):
            x = float(a[i])
            y = float(b[i])
            dot += x * y
            na += x * x
            nb += y * y
        if na <= 1e-12 or nb <= 1e-12:
            return 0.0
        return dot / math.sqrt(na * nb)

    def _find_closest_node(self, feature_vector, threshold=None, kinds=None):
        """特征降维检索：余弦相似度最近邻。

        骨架此处是 random.choice 占位，注释里明确要求替换为余弦相似度。
        threshold=None 时用 self.similar_threshold，太不相似则返回 None（全新未知）。

        kinds 只在这些层里找（用户 m03927）：新字只该挂在别的字旁边。
        句节点的特征就是句内字特征的平均，余弦天然很高 —— 一放开过滤，
        整棵字枝都会挂到花心上去。
        """
        if not self.nodes or feature_vector is None:
            return None
        thr = self.similar_threshold if threshold is None else threshold
        fv_z = self._standardize(feature_vector)
        best, best_sim = None, -2.0
        for node in self.nodes.values():
            if kinds is not None and (getattr(node, "kind", "char") or "char") not in kinds:
                continue
            # 熟悉度偏置：同样的特征相似度，走过很多次的节点更容易被「想起」。
            # 这是势阱深度在检索上的投影 —— 不是白名单，权重随调用次数连续增长。
            sim = self._cosine(node.features_z, fv_z) + 0.05 * min(
                3.0, getattr(node, "stiff", 0.0))
            if sim > best_sim:
                best, best_sim = node, sim
        if best is None or best_sim < thr:
            return None
        return best

    def _salience_of(self, feature_vector):
        """稀缺度注意力：与记忆池里越不相似 → 越"少数派" → 权重越高。

        与最相似者 cos=1.0（早就见过）→ 0.4 倍
        与最相似者 cos=0.0（完全陌生）→ 1.6 倍
        """
        if feature_vector is None or not self.nodes:
            return 1.0
        fv_z = self._standardize(feature_vector)
        best = -2.0
        for node in self.nodes.values():
            s = self._cosine(node.features_z, fv_z)
            if s > best:
                best = s
        return _clamp(1.6 - 1.2 * max(0.0, best), 0.4, 2.0)

    def _get_spatial_neighbors(self, center_node, radius=None, k=8):
        """基于三维空间的距离寻找邻居（V4.0：KD-Tree，不再全量遍历）

        修复#13: 骨架只取"半径内"，节点一稀疏就一个邻居都没有，
        awake_think 永远返回"没有任何东西被点亮"，星云连不起来。
        所以：半径内有 >=5 个就用半径内的；否则退回全局最近的 k 个。

        V4.0：两条路都走 self._kd。1000 节点时从"每帧几十万次距离计算"
        降到对数级，而且不再是"节点越多越慢"的线性结构。
        """
        if center_node is None:
            return []
        r = self.neighbor_radius if radius is None else radius
        if self._kd is not None:
            if not self.kd_ready:
                self.kd_rebuild()
            self.kd_queries += 1
            hits = self._kd.radius(center_node.pos, r, exclude=(center_node.id,))
            near = [self.nodes[pid] for _d, pid, _p in hits if pid in self.nodes]
            if len(near) >= 5:
                return near
            hits = self._kd.knn(center_node.pos, k + 1, exclude=(center_node.id,))
            return [self.nodes[pid] for _d, pid, _p in hits if pid in self.nodes][:k]
        # 兜底：KD-Tree 模块缺失时的老路径
        cx, cy, cz = center_node.pos
        scored = []
        for node in self.nodes.values():
            if node.id == center_node.id:
                continue
            dx = node.pos[0] - cx
            dy = node.pos[1] - cy
            dz = node.pos[2] - cz
            scored.append((math.sqrt(dx * dx + dy * dy + dz * dz), node))
        near = [n for d, n in scored if 0 < d <= r]
        if len(near) >= 5:
            return near
        scored.sort(key=lambda item: item[0])
        return [n for _, n in scored[:k]]

    # =====================================================================
    # 连接（树状记忆的枝干）
    # =====================================================================

    def _connect(self, a_id, b_id, weight=1.0):
        """建立/加强一条横向连接。返回 True 表示新建了一条。"""
        if a_id == b_id:
            return False
        key = (a_id, b_id) if a_id < b_id else (b_id, a_id)
        idx = self._conn_index.get(key)
        if idx is not None:
            self._conn_weight[idx] = min(4.0, self._conn_weight[idx] + weight * 0.5)
            # 突触延迟：这条线又被走了一次，传导变快（用进废退的"用进"）
            if idx < len(self._conn_delay):
                self._conn_delay[idx] = max(float(self.syn_delay_min),
                                            self._conn_delay[idx] * float(self.syn_delay_mature))
            return False
        self._conn_index[key] = len(self.connections)
        self.connections.append(key)
        self._conn_weight.append(float(weight))
        # 新建的突触最慢 —— 第一次走这条线，信号要爬过去
        self._conn_delay.append(float(self.syn_delay_new))
        if self._adj is not None:
            _i = len(self.connections) - 1
            self._adj.setdefault(a_id, []).append((b_id, _i))
            self._adj.setdefault(b_id, []).append((a_id, _i))
        self.stats["new_links"] += 1
        return True

    def _trigger_positive_feedback(self, node):
        """正反馈：Aha 时刻的强化（骨架语义保留，上限收紧）

        旧上限是阈值 1.5 倍（75），一次顿悟能把节点顶到 75 并维持十几秒，
        和"放电后强制漏电"直接打架。收到 0.6 倍（30），保留"被记住"的余温
        但又明确低于阈值，下一轮还要真的攒够刺激才会再亮。
        """
        node.activation = min(node.threshold * 0.6, node.activation + 20.0)

    # =====================================================================
    # 内环境稳态
    # =====================================================================

    def update_homeostasis(self, dt=0.1):
        """内环境稳态机制（负反馈）

        修复#3: 骨架在不过载时不给 global_inhibition 归零，上一轮的抑制量会
        永远残留；且侧支抑制能把 activation 压成负数。这里每帧重算并 clamp。
        同时把"节点瞬时激活总和"与"内环境张力 E/I"分开：
        前者是放电量，后者才是计划书里 105 / 100 的那一对指标。
        """
        # --- 背景底噪的慢漂移（OU 过程）---
        # dX = -X/tau * dt + sigma * dW，离散化后每帧 -X*k + N(0, sigma*sqrt(dt))。
        # 目的是让 E 永远在动：静息 105 +- 0.5，睡眠 78 +- 0.5，都不许是直线。
        k_b = 1.0 - math.exp(-dt / max(0.2, self.bg_drift_tau))
        self.bg_drift += -self.bg_drift * k_b + random.gauss(
            0.0, self.bg_drift_sigma * math.sqrt(dt))
        self.bg_drift = _clamp(self.bg_drift, -self.bg_drift_cap, self.bg_drift_cap)

        now_excitation = 0.0
        for n in self.nodes.values():
            now_excitation += n.activation
        self.global_excitation = now_excitation

        n_nodes = max(1, len(self.nodes))
        mean_activation = now_excitation / n_nodes

        # --- 兴奋张力 E：以 target_safety(105) 为静息，被"觉醒程度"推高 ---
        # 用"活跃节点占比 x 平均强度"而不是单纯平均值：刚出生长出 3 个节点且全在飙时，
        # 单纯算平均值会被判成整体过载，E 长期顶在 138。
        active_nodes = 0
        for n in self.nodes.values():
            if n.activation > 5.0:
                active_nodes += 1
        activity_ratio = active_nodes / n_nodes
        drive = activity_ratio * min(mean_activation, 45.0) * 0.75
        k_e = 1.0 - math.exp(-dt / self.tau_excitation)
        # bg_drift 叠在目标值上：静息 drive=0 时 E 就在 105 上下 +-0.5 慢慢晃
        # tonic_dopamine 叠在目标值上：刚说完话的那阵子 E 的落点被抬高，
        # 再按 tau=15s 慢慢回落 —— "倾诉完很爽"是基线变了，不是又放了次电。
        self.tone_excitation += (
            (self.target_safety + drive + self.bg_drift + self.tonic_dopamine)
            - self.tone_excitation) * k_e

        # --- 过载负反馈（双判据：人均膜电位 + 全网原始激活总量）---
        # 造物主控制台要求："原始激活总量超过安全线时 fatigue 必须强制累加"。
        # 旧实现只看 mean_activation - 60，20 个节点总量 604（人均 30）永远不触发，
        # 用户看到的"总量 611 / fatigue 0"就是这么来的。
        # 现在同时看总量线，两条判据取压力更大的那条。
        # 安全线按"有效规模"算：节点太少时不能用人均线（3 个节点 x 30 = 90，
        # 随便两个活跃就误判过载）。低于 8 个节点一律按 8 个算，等记忆长起来
        # 再切回真实规模 —— 过载描述的是"网太挤"，不是"少数几个点很亮"。
        n_eff = max(n_nodes, 8)
        line = self.overload_per_node * n_eff
        p_mean = max(0.0, mean_activation - self.overload_mean) / max(1.0, self.overload_mean)
        p_total = max(0.0, now_excitation - line) / max(1.0, line)
        p_fatigue = max(0.0, self.fatigue - self.fatigue_soft_cap) / max(
            1.0, 100.0 - self.fatigue_soft_cap
        )
        # 真实过载压力：只看膜的拥挤程度，**不带疲劳本身**。
        # 早期版本把疲劳自身也算进 pressure，结果 fatigue 一过软上限就自锁：
        # 疲劳高 -> 压力高 -> 疲劳继续涨 -> 恢复分支永不执行（实测钉死在 100）。
        pressure = max(p_mean, p_total)
        self.pressure = pressure
        self.overload_line = line

        # 疲劳的"余威"：它不推高疲劳，但会持续增强抑制，逼全网安静下来
        fatigue_pressure = min(1.0, p_fatigue)
        self.fatigue_pressure = fatigue_pressure

        if pressure > 0.0:
            # 压力越大，疲劳爬得越快（上限 100，防赛博癫痫的最后一道闸）
            self.fatigue = min(100.0, self.fatigue + pressure * self.fatigue_gain * dt)
            eff = pressure + fatigue_pressure * 0.5
            self.global_inhibition = min(
                eff * self.inhibition_strength * 100.0, self.tone_excitation
            )
            # 侧支抑制：先按"人均超出量"整体削一刀，再按压力补一刀。
            # 乘 dt 是为了与帧率无关；再乘抑制强度，滑块归零就等于关掉负反馈。
            excess_each = max(0.0, now_excitation - line) / n_nodes
            cut = (excess_each * 0.25 + eff * 5.0) * self.inhibition_strength * dt
            if cut > 0.0:
                for node in self.nodes.values():
                    node.activation = max(0.0, node.activation - cut)
        else:
            # 不过载：抑制只剩高疲劳的余威，并且疲劳开始恢复
            self.global_inhibition = min(
                fatigue_pressure * 20.0 * self.inhibition_strength, self.tone_excitation
            )

        # --- 抑制张力 I：负反馈，滞后于兴奋 ---
        err = self.tone_excitation - self.target_safety
        k_i = 1.0 - math.exp(-dt / self.tau_inhibition)
        want_i = self.tonic_inhibition + max(0.0, err) * 0.7 + self.fatigue * 0.15
        self.tone_inhibition += (want_i - self.tone_inhibition) * k_i

        # --- 疲劳恢复（按真实时间衰减，不是"每次调用减 0.5"）---
        if pressure <= 0.0 and self.fatigue > 0.0:
            self.fatigue = max(0.0, self.fatigue - 3.0 * dt)

        # --- 长效多巴胺回落：抬高 E 的那口气会散，但不是一秒散完 ---
        if self.tonic_dopamine > 0.0:
            self.tonic_dopamine *= math.exp(-dt / max(1.0, self.dopamine_tau))
            if self.tonic_dopamine < 0.02:
                self.tonic_dopamine = 0.0

    # =====================================================================
    # 生物钟：顿悟频率 -> 强制休眠 -> 突触修剪
    # =====================================================================

    def _update_biorhythm(self, dt, now):
        """生物钟：统计顿悟频率，亢奋到阈值就强制入睡，睡够了再醒。

        用户的定义是"10 秒内 > 50 次 Aha 视为极度亢奋"。这里不只看次数，
        还要求亢奋**持续** aha_hold 秒 —— 一次孤立的爆发不值得让她昏睡。
        """
        # 1) 顿悟频率（滑动窗口）：用 stats["aha"] 的增量喂时间戳
        delta = int(self.stats["aha"]) - int(self._last_aha_seen)
        self._last_aha_seen = int(self.stats["aha"])
        for _ in range(max(0, min(delta, 500))):
            self.aha_times.append(now)
        while self.aha_times and (now - self.aha_times[0]) > self.aha_window:
            self.aha_times.popleft()
        self.aha_rate = round(len(self.aha_times) / self.aha_window, 3)

        if self.sleeping:
            self._sleep_step(dt, now)
            return

        # 2) 亢奋判定：顿悟太密，或原始激活总量顶到安全线的九成
        hot_aha = len(self.aha_times) >= self.aha_burst_max
        limit = self.overload_line if self.overload_line > 1.0 else (
            self.overload_per_node * max(len(self.nodes), 8))
        hot_raw = self.global_excitation >= limit * 0.90
        if hot_aha or hot_raw:
            self._excited_hold += dt
            if self._excited_hold >= self.aha_hold:
                if hot_aha:
                    reason = "顿悟频率 %.1f 次/秒（10 秒 %d 次）" % (
                        self.aha_rate, len(self.aha_times))
                else:
                    reason = "原始激活总量 %.0f 逼近安全线 %.0f" % (
                        self.global_excitation, limit)
                self._enter_sleep(now, reason)
        else:
            self._excited_hold = max(0.0, self._excited_hold - dt * 2.0)

    def _enter_sleep(self, now, reason):
        """强制休眠。切断外部输入由调用方检查 self.sleeping 完成。"""
        if self.sleeping:
            return
        self.sleeping = True
        self.sleep_since = now
        self.sleep_reason = reason
        self._quiet_hold = 0.0
        self._last_prune = now
        self.prune_last = 0
        self._sleep_pruned = 0
        self.prune_cap = max(16, int(len(self.connections) * 0.10))
        self.aha_times.clear()
        self._excited_hold = 0.0
        try:
            self.speak(text="呓语：太亮了……我要熄一会儿。")
        except Exception:
            pass

    def _sleep_step(self, dt, now):
        """睡眠态的物理：兴奋被强制拉低、抑制接管、低频修剪突触。"""
        self.sleep_seconds = round(now - self.sleep_since, 1)

        # 1) 全部节点的膜电位快速漏掉（灯一盏盏关上）
        k_drain = math.exp(-2.2 * dt)
        for n in self.nodes.values():
            n.activation = max(0.0, n.activation * k_drain)

        # 1.5) 睡眠也要呼吸：极小的背景底噪，让 raw 不归零。
        #      睡眠态每帧 drain 掉 20%，所以注入量要按 sleep_noise_scale 放大，
        #      否则 raw 会稳定在 0.2 以下，图上还是一条直线。
        self._bg_inject(dt, scale=self.sleep_noise_scale)

        # 2) 兴奋张力强制拉向低基线：让抑制真正接管
        floor = self.tonic_inhibition * 0.78
        k_s = 1.0 - math.exp(-dt / 1.2)
        self.tone_excitation += ((floor + self.bg_drift) - self.tone_excitation) * k_s
        self.tone_inhibition += ((self.tonic_inhibition + 6.0) - self.tone_inhibition) * k_s

        # 3) 突触修剪：每 0.8 秒删一批"低权重 + 两端都不核心"的散乱连线。
        #    一次睡眠的总量有上限（prune_cap），避免把网络剪成光秃秃的骨架。
        if now - self._last_prune >= 0.8 and self._sleep_pruned < self.prune_cap:
            self._last_prune = now
            budget = min(self.prune_batch, self.prune_cap - self._sleep_pruned)
            self.prune_last = self._prune_synapses(budget)
            self._sleep_pruned += self.prune_last

        # 4) 醒来：先睡够 sleep_min，再看安静够久 + 兴奋已落到基线附近。
        #    不加最短时长的话，静息态入睡 4 秒就会醒，梦境游走一次都轮不到。
        long_enough = (now - self.sleep_since) >= self.sleep_min
        if (long_enough and len(self.aha_times) == 0
                and self.tone_excitation <= self.target_safety * 0.92):
            self._quiet_hold += dt
            if self._quiet_hold >= 4.0:
                self.sleep_seconds = round(now - self.sleep_since, 1)
                self.sleeping = False
                self.sleep_reason = ""
                self.sleep_since = 0.0
                self._excited_hold = 0.0
                self._quiet_hold = 0.0
                self._last_aha_seen = int(self.stats["aha"])
                try:
                    self.speak(text="呓语：醒了。好像瘦了一点。")
                except Exception:
                    pass
        else:
            self._quiet_hold = 0.0

    def _prune_synapses(self, batch=10):
        """记忆修剪（Synaptic Pruning）：物理删掉散乱的弱连线，释放内存。

        判据是「权重极低」+「没有连向核心节点」：
        - 权重 <= prune_weight（弱边）
        - 这条边的两端都不在核心集里。核心集 = 度数最高的 prune_core_ratio
          那一撮节点；连向核心的边无论多弱一律不动，否则剪完记忆就散架。

        早先的实现用"两端度数 <= prune_deg_max(2)"当散乱判据，实测在真实图上
        一条候选都选不出来（每个节点度数都 >= 3，中位数 11），等于没实现，
        所以改成相对分位的核心集判据。
        """
        if len(self.connections) < 16:
            return 0
        deg = collections.Counter()
        for (a, b) in self.connections:
            deg[a] += 1
            deg[b] += 1
        n_core = max(3, int(len(deg) * float(self.prune_core_ratio)))
        core = set(nid for nid, _ in deg.most_common(n_core))
        cand = []
        for i, (a, b) in enumerate(self.connections):
            if self._conn_weight[i] > self.prune_weight:
                continue
            if a in core or b in core:
                continue
            cand.append(i)
        if not cand:
            return 0
        random.shuffle(cand)
        kill = set(cand[:max(1, int(batch))])
        kept_conns, kept_w, kept_d = [], [], []
        self._conn_index.clear()
        for i, ab in enumerate(self.connections):
            if i in kill:
                continue
            self._conn_index[ab] = len(kept_conns)
            kept_conns.append(ab)
            kept_w.append(self._conn_weight[i])
            kept_d.append(self._conn_delay[i] if i < len(self._conn_delay)
                          else float(self.syn_delay_new))
        removed = len(self.connections) - len(kept_conns)
        self.connections = kept_conns
        self._conn_weight = kept_w
        self._conn_delay = kept_d
        self._adj = None
        self.prune_total += removed
        return removed

    # =====================================================================
    # 背景底噪 + 睡眠梦境（用户 m02173 的「静息休克」修复）
    # =====================================================================

    def _bg_inject(self, dt, scale=1.0):
        """背景底噪：给每个节点的膜电位加一点点热噪声。

        骨架假设"没有输入就是绝对零度"，于是停止投喂后整张网熄成 0.0。
        真实神经系统的膜电位永远有热噪声和自发发放 —— 这一层就是让
        raw_excitation 永远不为 0（用户要的"不要绝对直线"）。

        只对"还没亮"的节点注入：已经点着的星不该被底噪再推高，否则
        底噪会污染 activity_ratio，把 E 从 105 一路顶到 120 去。
        """
        if self.bg_noise <= 0.0 or not self.nodes:
            return 0
        amt = float(self.bg_noise) * float(scale) * dt
        if amt <= 0.0:
            return 0
        hot = float(self.bg_noise_hot)
        rest = float(self.bg_rest)
        n = 0
        for node in self.nodes.values():
            if node.activation < hot:
                base = node.activation if node.activation > rest else rest
                node.activation = base + amt * random.uniform(0.35, 1.65)
                n += 1
        return n

    def _spike_step(self, dt, now, dream=False):
        """背景电活动：定频微型脉冲 → 局部电位累加 → 够阈值才自发放电。

        用户 m02813 的四条要求，全部落在这个函数里：
        1. 固定频率（默认 8Hz）对全网施加局部电位，每次 +5~10 点；
        2. 累不到阈值就只是浅浅一亮再衰减，顶到阈值才完整放电一次；
        3. 放电算一次 Aha（但记在 stats["self_aha"]，不算外部输入触发的 Aha）；
        4. 睡眠时不停，改成高幅度低频直接跨阈值的 REM 式连片闪烁。

        清醒态用"频率 x 覆盖率"而不是"每节点每秒 N 次"：
        后者会让注入率与节点数无关地爆炸（见 __init__ 里那笔账）。
        用它，每节点的注入率恒为 spike_hz * spike_cover * 平均幅度，
        稳态 = 注入率 / decay_rate，与节点数无关 —— 她永远停在阈下慢慢爬。
        """
        n_nodes = len(self.nodes)
        if n_nodes <= 0:
            return 0
        try:
            dt = _clamp(float(dt), 1e-4, 1.0)
        except Exception:
            return 0

        if dream:
            lam = float(self.dream_spike_rate) * dt
            amp_lo = float(self.dream_spike_amp_min)
            amp_hi = float(self.dream_spike_amp_max)
        else:
            gain = float(self.spike_gain)
            if gain <= 0.0 or float(self.spike_hz) <= 0.0:
                return 0
            lam = (float(self.spike_hz) * gain * dt
                   * _clamp(float(self.spike_cover), 0.0, 1.0) * n_nodes)
            amp_lo = float(self.spike_amp_min)
            amp_hi = float(self.spike_amp_max)
        if amp_hi < amp_lo:
            amp_lo, amp_hi = amp_hi, amp_lo

        k = _poisson(lam)
        if k <= 0:
            return 0
        if k > 400:          # 一帧补 400 个脉冲 = 瞬间癫痫，掐掉
            k = 400

        nodes = list(self.nodes.values())
        fired_ids = []
        bunch = _clamp(float(self.spike_bunch), 0.0, 1.0)
        focus_id = None
        # 循环外取一次时间，同一帧里所有脉冲的放电时刻一致
        for _ in range(k):
            if focus_id is None or random.random() >= bunch:
                node = nodes[random.randrange(n_nodes)]
                focus_id = node.id
            else:
                node = self.nodes.get(focus_id)
                if node is None:      # 焦点这一帧被修剪掉了，重新抽
                    node = nodes[random.randrange(n_nodes)]
                    focus_id = node.id
            node.activation += random.uniform(amp_lo, amp_hi)
            self.spike_total += 1
            # 已经过阈值的（被串扰顶上去的）走 try_activate 正门：
            # 绝对/相对不应期、放电后强制漏电（fire_reset_ratio）全由它管，
            # 这里绝不另开一条"直接置激活"的旁路。
            if node.try_activate(now, 0.0):
                fired_ids.append(node.id)
                self.spike_fires += 1
                if dream:
                    self.dream_spike_fires += 1
                self.stats["self_aha"] += 1
                # 危机字的放电直接顶起伤害感受器：脊髓不需要大脑同意
                if (getattr(node, "verdict", None) or "").lower() in ("crisis", "danger"):
                    self._noci_buf += 1.6
                # 髓鞘化：这次放电走通了这条路，势阱深一点。
                self._stiffen(node, 0.5)

        if fired_ids:
            self.last_spike_t = now
            # 局部钙波余温（V4.0 Phase 1-D）：放电的星把最近的一圈烘热一点。
            # 梦境里一次几十颗，不做（会变成整片一起发烫，反而看不清）。
            if not dream and len(fired_ids) <= 8:
                for _fid in fired_ids[:8]:
                    _fn = self.nodes.get(_fid)
                    if _fn is None:
                        continue
                    try:
                        self._calcium_wave(_fn)
                    except Exception:
                        pass
                    # 突触传导：把这颗星的电顺着连线送出去（带延迟）
                    try:
                        self._conduct(_fid, now)
                    except Exception:
                        pass
            # 梦里同一帧有两颗以上放电 —— 那就是"随机连出的奇妙连线"。
            # 清醒态不连：白天的连线必须由 consolidate / awake_think 决定，
            # 否则底噪会替她做决定，树就长歪了。
            if dream and len(fired_ids) >= 2:
                a = self.nodes.get(fired_ids[0])
                b = self.nodes.get(fired_ids[1])
                if a is not None and b is not None and a.id != b.id:
                    if self._connect(a.id, b.id, weight=0.4):
                        self.dream_links += 1
        self._spike_fired_ids = fired_ids
        return len(fired_ids)

    # =====================================================================
    # V4.0 Phase 1-C：潜意识黑箱（原点）+ 延迟拷贝 + 工作记忆
    #
    # 用户蓝图原话：
    #   「黑箱设在原点。受向心力影响，高频激活的长期记忆节点会被吸引到
    #    黑箱边缘。」
    #   「黑箱向长期记忆拷贝时，必须带有距离导致的时间延迟（0.5s-1.5s）。
    #    远近不同的记忆分批次涌入，在重叠碰撞中产生灵感涌现。」
    #   「新增 Working_Memory 临时区。输入未知词，在临时区生成节点，向周围
    #    发射刺激；随后扔进黑箱，黑箱将新词与拷贝来的旧高频词乱撞，生成
    #    结果退回临时区输出。如果伴随高多巴胺，则固化进长期星云。」
    # =====================================================================

    def _calcium_wave(self, node):
        """局部钙波余温：一颗星放电后，挤得最近的邻居获得一圈微光预热。

        只加热、不放电 —— 预热封顶在阈值的 90%，永远自己跨不过去，
        必须等背景电活动再补一脚。这是「余温」，不是「传染」。
        """
        if not self.nodes or float(self.calcium_gain) <= 0.0:
            return 0
        got = 0
        try:
            near = self.kd_nearest(node.pos, k=int(self.calcium_k) + 1,
                                   exclude=(node.id,))
        except Exception:
            return 0
        for _d, _pid, nb in near:
            if nb is None:
                continue
            nb.activation = min(nb.threshold * 0.9,
                                nb.activation + float(self.calcium_gain))
            got += 1
        self.calcium_total += got
        return got

    def _receptor_ok(self, key, now):
        """15 秒可逆受体脱敏：同一个词被连喊 10 次，她就听不见了。

        窗口内数到 desens_count 次 → 拉黑 desens_hold 秒；拉黑期间返回
        False（调用方直接跳过这条输入）。到期自动恢复，不留任何持久状态 ——
        「可逆」是这个机制的全部意义：她不是坏了，只是烦了。
        """
        rec = self._desens.get(key)
        if rec is None:
            rec = {"n": 0, "t": now, "block": 0.0}
            self._desens[key] = rec
        if rec["block"] > now:
            self.desens_skip += 1
            return False
        if now - rec["t"] > float(self.desens_window):
            rec["n"] = 0
        rec["t"] = now
        rec["n"] += 1
        if rec["n"] >= int(self.desens_count):
            rec["n"] = 0
            rec["block"] = now + float(self.desens_hold)
            self.desens_total += 1
            self.stats["desens"] = int(self.stats.get("desens", 0)) + 1
            try:
                self.speak(kind="desens")
            except Exception:
                pass
            return False
        if len(self._desens) > 240:
            for k in [x for x, rr in self._desens.items() if isinstance(rr, dict)
                      if rr["block"] <= now
                      and now - rr["t"] > float(self.desens_window)]:
                self._desens.pop(k, None)
        return True

    # =====================================================================
    # V4.0 Phase 1-D：突触延迟 / 脑区（海马体 · 杏仁核 · 基底节）
    # =====================================================================

    def _rebuild_adj(self):
        """重建邻接表：node_id -> [(邻居 id, 边下标)]。"""
        adj = {}
        for i, (a, b) in enumerate(self.connections):
            adj.setdefault(a, []).append((b, i))
            adj.setdefault(b, []).append((a, i))
        self._adj = adj
        return adj

    def _conduct(self, src_id, now, amount=None):
        """信号沿连线传导 —— 新线慢、老线快，这就是突触延迟。

        只传给权重最高的 syn_fanout 条边：一颗星放电时把所有邻居都点亮，
        等于没有选择性，星云会变成一锅粥。只算 Top-K 也符合蓝图里
        「拒绝组合爆炸」那一条。
        """
        src = self.nodes.get(src_id)
        if src is None:
            return 0
        adj = self._adj if self._adj is not None else self._rebuild_adj()
        edges = adj.get(src_id) or []
        if not edges:
            return 0
        if amount is None:
            amount = min(float(self.syn_conduct_cap),
                         src.threshold * float(self.syn_conduct))
        edges = sorted(edges, key=lambda e: -float(self._conn_weight[e[1]])
                       if e[1] < len(self._conn_weight) else 0.0)
        got = 0
        for other, idx in edges[:max(1, int(self.syn_fanout))]:
            w = float(self._conn_weight[idx]) if idx < len(self._conn_weight) else 1.0
            d = (float(self._conn_delay[idx]) if idx < len(self._conn_delay)
                 else float(self.syn_delay_new))
            amp = amount * _clamp(w / 2.0, 0.25, 1.6)
            if len(self.syn_pending) >= int(self.syn_pending_cap):
                break
            self.syn_pending.append((now + d, src_id, other, amp, d))
            got += 1
        self.syn_sent += got
        return got

    def _conduct_step(self, now):
        """派发到站的信号。到站后只 try_activate，不再连锁传导。"""
        if not self.syn_pending:
            return 0
        keep = []
        sent = 0
        for due, _src, nid, amp, _dur in self.syn_pending:
            if due > now:
                keep.append((due, _src, nid, amp, _dur))
                continue
            node = self.nodes.get(nid)
            if node is None:
                continue
            sent += 1
            try:
                if node.try_activate(now, amp):
                    self.syn_fired += 1
            except Exception:
                pass
        self.syn_pending = keep
        return sent

    def _spinal_step(self, dt, now):
        """脊髓不走大脑：伤害感受器 → 中间神经元 → 肌肉。

        三条弧同时存在、谁强谁占肌肉张力，动作是它们叠加出来的结果 ——
        没有「如果累了就闭眼」这种分支，只有连续量的竞争。
        """
        # 1) 传入：伤害感受器漏电 + 威胁水平
        raw = float(self._noci_buf) + float(self.threat_level) * 0.5
        self._noci_buf *= math.exp(-dt / self.spinal_noci_tau)
        self._noci += (raw - self._noci) * (1.0 - math.exp(-dt / 0.25))

        # 2) 三条弧的驱动量（全是连续量）
        mean_act = self.global_excitation / max(1, len(self.nodes))
        hot = max(0.0, mean_act - 30.0) / 40.0
        drive_flex = self._noci * self.spinal_flex_k + hot * 0.20
        drive_lean = -self.muscle["lean"] * self.spinal_stretch_k
        e_ratio = _clamp((self.tone_excitation - self.target_safety) / 40.0, -2.0, 2.0)
        drive_lean += e_ratio * 0.18
        # 呼吸相位自己积分（频率随兴奋变）—— 这是节律，不是关键帧
        self._breath_ph = (self._breath_ph + dt * (0.22 + 0.05 * max(0.0, e_ratio))) % 1.0
        breath = 0.5 + 0.5 * math.sin(self._breath_ph * 6.28318)
        tail = self.muscle_rest["tail"] + 0.30 * max(0.0, e_ratio) + 0.16 * breath
        fin = (self.muscle_rest["fin"]
               + 0.10 * _clamp(self.tonic_dopamine / 12.0, 0.0, 1.0)
               - 0.30 * self._noci)
        eye = (self.muscle_rest["eye"]
               - 0.25 * _clamp(self.fatigue / 80.0, 0.0, 1.0)
               - 0.35 * self._noci)

        # 3) 出传：一阶系统逼近目标张力（快慢不同 → 屈肌最快、鳍最慢）
        tgt = {
            "flex": _clamp(self.muscle_rest["flex"] + drive_flex, 0.0, 1.6),
            "lean": _clamp(self.muscle_rest["lean"] + drive_lean, -1.0, 1.0),
            "tail": _clamp(tail, 0.0, 2.0),
            "fin": _clamp(fin, 0.0, 1.0),
            "eye": _clamp(eye, 0.0, 1.0),
            "breath": _clamp(breath, 0.0, 1.0),
        }
        for key, tau in (("flex", 0.13), ("lean", 0.22), ("tail", 0.35),
                         ("fin", 0.45), ("eye", 0.30), ("breath", 0.06)):
            k = 1.0 - math.exp(-dt / tau)
            self.muscle[key] += (tgt[key] - self.muscle[key]) * k

        # 4) 反射登记：屈肌越过软阈值才算一次（自己的不应期防抖）
        if (self.muscle["flex"] >= self.spinal_reflex_at
                and now - self._last_spinal_t >= self.spinal_refractory):
            self._last_spinal_t = now
            self.spinal_total += 1
            self.spinal_last = now
            arms = [("屈肌", abs(drive_flex)), ("牵张", abs(drive_lean))]
            self.spinal_kind = max(arms, key=lambda kv: kv[1])[0]
            self.spinal_log.append({"t": round(now, 2), "k": self.spinal_kind,
                                    "a": round(self.muscle["flex"], 3)})
        return self.muscle["flex"]

    def _body_locked(self):
        m = self.muscle
        return {
            "flex": round(m["flex"], 3),
            "lean": round(m["lean"], 3),
            "tail": round(m["tail"], 3),
            "fin": round(m["fin"], 3),
            "eye": round(m["eye"], 3),
            "breath": round(m["breath"], 3),
            "noci": round(self._noci, 3),
            "spinal_total": int(self.spinal_total),
            "spinal_kind": self.spinal_kind,
            "spinal_ago": (round(max(0.0, time.time() - self.spinal_last), 1)
                           if self.spinal_last > 0.0 else -1.0),
            "reflex": [dict(x) for x in list(self.spinal_log)[-6:]],
        }

    def body_snapshot(self):
        """给具身前端用的躯体参数。"""
        with self._lock:
            return self._body_locked()
    def _episode_valence(self, nodes):
        """一句话的情绪价：危机字记 -1，安全字记 +1。"""
        v = 0.0
        for n in nodes:
            verdict = (getattr(n, "verdict", None) or "").lower()
            if verdict in ("crisis", "danger"):
                v -= 1.0
            elif verdict == "safe":
                v += 1.0
        return v

    def remember_episode(self, sent_id, text, nodes, now=None):
        """海马体：把一句话登记成一条情景记忆。"""
        if not sent_id or not nodes:
            return None
        now = time.time() if now is None else float(now)
        val = self._episode_valence(nodes)
        ep = {"id": sent_id, "t": now, "text": str(text or "")[:64],
              "ids": [n.id for n in nodes], "valence": val}
        self.episodes.append(ep)
        return ep

    def _replay_step(self, dt, now):
        """海马体：睡眠中回放高情绪情景（带危险的优先，且强度翻倍）。"""
        if now < self._replay_until:
            for nid in self._replay_ids:
                node = self.nodes.get(nid)
                if node is not None:
                    node.activation = min(node.threshold * 0.92,
                                          node.activation + 6.0 * dt)
            return 0
        if now - self._last_replay < float(self.episode_replay_every):
            return 0
        self._last_replay = now
        pool = [ep for ep in self.episodes
                if abs(float(ep.get("valence", 0.0))) >= float(self.episode_min)
                and any(i in self.nodes for i in ep.get("ids") or [])]
        if not pool:
            return 0
        # 危险情景权重更高（杏仁核参与海马体的选片）
        pool.sort(key=lambda ep: -abs(float(ep["valence"]))
                  * (float(self.amygdala_danger) if ep["valence"] < 0 else 1.0))
        ep = pool[0]
        ids = [i for i in ep["ids"] if i in self.nodes]
        gain = 18.0 * (float(self.amygdala_danger) if ep["valence"] < 0 else 1.0)
        for nid in ids:
            node = self.nodes[nid]
            node.activation = min(node.threshold * 0.95, node.activation + gain)
        # 回放时同一情景里的字互相加强（这就是「巩固」）
        for i in range(len(ids) - 1):
            self._connect(ids[i], ids[i + 1], weight=0.6)
        self._replay_ids = ids
        self._replay_until = now + float(self.episode_replay_len)
        self.replay_total += 1
        self.stats["replay"] = int(self.stats.get("replay", 0)) + 1
        try:
            self.speak(kind="replay", ids=ids,
                       ga=self._plain(self.nodes[ids[0]]) if ids else u"？")
        except Exception:
            pass
        return len(ids)

    def _amygdala_weight(self, node):
        v = (getattr(node, "verdict", None) or "").lower()
        if v in ("crisis", "danger"):
            return float(self.amygdala_danger)
        return float(self.amygdala_safe)

    def _amygdala_pick(self, pool):
        """杏仁核：带危险标签的节点被抽到的概率翻倍。"""
        if not pool:
            return None
        if len(pool) == 1:
            return pool[0]
        ws = [self._amygdala_weight(n) for n in pool]
        tot = sum(ws)
        if tot <= 0.0:
            return random.choice(pool)
        r = random.uniform(0.0, tot)
        acc = 0.0
        for n, w in zip(pool, ws):
            acc += w
            if r <= acc:
                if w > float(self.amygdala_safe):
                    self.amygdala_hits += 1
                return n
        return pool[-1]

    def _basal_gate(self, cands):
        """基底节：动作门控，只放行 Top-1 路径。

        cands 是 [(score, node)]。分数加上多巴胺收益 —— 高兴的时候她更愿意
        说自己最熟的那个字，低落的时候反而会挑冷门的（多巴胺低时度数权重减小）。
        """
        pick = [c for c in (cands or []) if c[1] is not None]
        if not pick:
            return None
        self.basal_gate += len(pick)
        if len(pick) == 1:
            self.basal_pass += 1
            return pick[0][1]
        dopa = _clamp(float(self.tonic_dopamine) / 10.0, 0.0, 1.5)
        best = None
        best_s = None
        for score, node in pick:
            deg = self._degree(node.id)
            s = float(score) + deg * (2.0 + 6.0 * dopa)
            if s <= 0.0:
                s += math.dist((0.0, 0.0, 0.0), node.pos) * 0.0
            if best_s is None or s > best_s:
                best_s = s
                best = node
        if best is not None:
            self.basal_pass += 1
        return best

    def _feature_sim(self, a, b):
        """两个节点的特征相似度：有标准化特征就用余弦，没有就退化成位置。

        退化分支是必要的 —— 基因播种出来的字节点没有真实特征向量，
        它们只有基因坐标，硬算余弦会全是 0（长度不匹配时直接跳过）。
        """
        va = getattr(a, "features_z", None) or []
        vb = getattr(b, "features_z", None) or []
        if va and vb and len(va) == len(vb):
            dot = 0.0
            na = 0.0
            nb = 0.0
            for i in range(len(va)):
                dot += va[i] * vb[i]
                na += va[i] * va[i]
                nb += vb[i] * vb[i]
            if na > 1e-9 and nb > 1e-9:
                return dot / math.sqrt(na * nb)
        d = math.dist(a.pos, b.pos)
        return max(-1.0, 1.0 - d / 40.0)

    def _drop_node(self, nid):
        """物理删掉一个节点和它的全部连线（工作记忆过期时用）。

        与 _prune 的区别：_prune 按活跃度批量淘汰，这里只扔一颗指定的星，
        但索引维护得走同一套，否则 KD 和 _conn_index 会留在旧位置。
        """
        self.nodes.pop(nid, None)
        if self._concepts:
            self._concepts = {w: i for w, i in self._concepts.items() if i != nid}
        if self._kd is not None:
            try:
                self._kd.remove(nid)
            except Exception:
                pass
        keep = []
        wts = []
        dls = []
        for i, (a, b) in enumerate(self.connections):
            if a == nid or b == nid:
                continue
            keep.append((a, b))
            wts.append(self._conn_weight[i])
            dls.append(self._conn_delay[i] if i < len(self._conn_delay)
                       else float(self.syn_delay_new))
        if len(keep) != len(self.connections):
            self.connections = keep
            self._conn_weight = wts
            self._conn_delay = dls
            self._conn_index.clear()
            for i, ab in enumerate(keep):
                self._conn_index[ab] = i
            self._adj = None
        self.syn_pending = [p for p in self.syn_pending if p[2] in self.nodes]
        return nid not in self.nodes

    def submit_to_wm(self, word, features=None, now=None):
        """把一个「还没学过的词」扔进工作记忆（临时区）。

        位置刻意放在最外侧的球壳（半径 78~92），离黑箱很远 ——
        所以它要漂好几秒才被吸到原点，这一路上它一直亮着，
        前端会看到一颗浅黄色的星从外围慢慢沉下去。

        返回新节点 id；工作记忆满了就返回 None（不排队，不硬塞）。
        """
        now = time.time() if now is None else float(now)
        word = (word or "").strip()
        if not word:
            return None
        with self._lock:
            if len(self._wm) >= self.wm_cap:
                return None
            th = random.uniform(0.0, 2.0 * math.pi)
            ph = random.uniform(-1.0, 1.0)
            sq = math.sqrt(max(0.0, 1.0 - ph * ph))
            rr = 78.0 + random.uniform(0.0, 14.0)
            pos = (rr * math.cos(th) * sq, rr * math.sin(th) * sq, rr * ph)
            nid = self._next_id
            self._next_id += 1
            node = NeuronNode(nid, pos[0], pos[1], pos[2], features,
                              now=now, salience=1.2, glyph=word[:2],
                              kind="temp", text=word)
            node.activation = 30.0
            self.nodes[nid] = node
            self._kd_insert(nid, node.pos)
            self._wm[nid] = now
            self.wm_made += 1
            self.stats["wm_in"] = int(self.stats.get("wm_in", 0)) + 1
            return nid

    def _box_step(self, dt, now):
        """黑箱一帧：向心力 → 延迟拷贝 → 碰撞涌现 → 固化或遗忘。

        顺序是有理由的：先拉动位置，再决定这一轮谁到站，然后用「到站的
        旧记忆」去撞「已经沉到底的临时词」，最后才结算固化/遗忘。反过来
        的话，这一帧刚生成的拷贝要等到下一帧才算到站，延迟会被吃掉一帧。
        """
        if dt <= 0.0:
            return 0

        # ① 向心力：高频长期记忆被吸到黑箱边缘；临时词要沉得更深
        #
        # 判据是「放电次数排前 6% 且不低于 12 次」，不是简单的 >= 某个数：
        # 实测存档 1168 个节点里 fire_count >= 3 的有 600 多个、>= 20 的有 330 个，
        # 按绝对阈值吸会把整片星云拽成一坨；按分位只吸真正的长期高频记忆，
        # 星云才会长成「核心 + 外围」的形态。
        if now - self._box_hot_at >= self.box_hot_every:
            self._box_hot_at = now
            pool = [n for n in self.nodes.values()
                    if (getattr(n, "kind", "char") or "char") == "char"]
            pool.sort(key=lambda n: -n.fire_count)
            k = max(8, int(len(pool) * self.box_hot_ratio))
            self._box_hot_ids = set(n.id for n in pool[:k]
                                    if n.fire_count >= self.box_hot_fire)
        def _pull_one(node, target, gain):
            dx = -node.pos[0]
            dy = -node.pos[1]
            dz = -node.pos[2]
            d = math.sqrt(dx * dx + dy * dy + dz * dz)
            if d <= target or d < 1e-6:
                return False
            k = min(1.0, gain * dt * (1.0 - target / d))
            if k <= 0.0:
                return False
            node.pos = (node.pos[0] + dx * k, node.pos[1] + dy * k,
                        node.pos[2] + dz * k)
            if self._kd is not None:
                try:
                    self._kd.move(node.id, node.pos)
                except Exception:
                    pass
            return True

        pulled = 0
        # 临时词单独先拉，而且用 2.2 倍速 —— 它们不在 _box_hot_ids 里、
        # 又排在 dict 末尾，如果和 hot 节点一起共用「每帧最多 40 个」的配额，
        # 永远轮不到它们（实测 24 次采样半径纹丝不动，一直挂在 81.9）。
        for wid in list(self._wm.keys()):
            wnode = self.nodes.get(wid)
            if wnode is None:
                continue
            if _pull_one(wnode, self.box_radius * 0.55, self.box_pull * 2.2):
                pulled += 1
        moved = 0
        for n in list(self.nodes.values()):
            if moved >= self.box_pull_cap:
                break
            if n.id not in self._box_hot_ids:
                continue
            if _pull_one(n, self.box_radius, self.box_pull):
                pulled += 1
                moved += 1
        self.box_pulled += pulled

        # ② 延迟拷贝：越远的记忆在路上花的时间越长（0.5s ~ 1.5s）
        if now - self._last_box_copy >= self.box_copy_every:
            self._last_box_copy = now
            if len(self.box_copies) < self.box_copy_cap:
                cands = [n for n in self.nodes.values()
                         if n.id in self._box_hot_ids
                         and getattr(n, "glyph", None)]
                if cands:
                    pick = random.choice(cands)
                    dist = math.sqrt(pick.pos[0] ** 2 + pick.pos[1] ** 2 + pick.pos[2] ** 2)
                    span = self.box_copy_hi - self.box_copy_lo
                    delay = self.box_copy_lo + span * _clamp(dist / 260.0, 0.0, 1.0)
                    self.box_copies.append((now + delay, pick.id))
                    self.box_copied += 1

        # ③ 到站队列（过期的节点已被修剪就静默丢弃）
        #
        # 到站后必须在箱里「停」box_stay 秒，不能只在这一帧有效：
        # temp 词沉到底要好几秒，如果旧记忆只闪现一帧，两边永远撞不上，
        # insight 会恒为 0（第一版就是这样，跑了 22 秒一次都没撞）。
        ready = []
        keep = []
        for at, nid in self.box_copies:
            if nid not in self.nodes:
                continue
            if at <= now:
                ready.append(nid)
                if now - at <= self.box_stay:
                    keep.append((at, nid))
            else:
                keep.append((at, nid))
        self.box_copies = keep

        # ④ 碰撞：临时词沉到黑箱后，和刚到的旧记忆撞一次
        insight = 0
        for wid in [w for w in list(self._wm.keys()) if w in self.nodes]:
            if self._wm_hits.get(wid, 0) >= self.box_hits_max:
                continue
            wnode = self.nodes[wid]
            wd = math.sqrt(wnode.pos[0] ** 2 + wnode.pos[1] ** 2 + wnode.pos[2] ** 2)
            if wd > self.box_radius:
                continue
            for oid in ready:
                old = self.nodes.get(oid)
                if old is None or oid == wid:
                    continue
                # 「撞」有两个条件之一就成立：特征像（撞出共鸣），
                # 或者本来就是同一个箱子里的两颗星（黑箱里很挤）。
                # 只按特征余弦判的话，热节点停在半径 14 的球面上、temp 停在 7.7，
                # 两颗在球两侧时距离能到 21，余弦掉到 0.46，明明同处一箱却撞不上。
                _sim = self._feature_sim(wnode, old)
                if (_sim < self.box_collide
                        and math.dist(wnode.pos, old.pos) > self.box_radius * 2.0):
                    continue
                if self._connect(wid, oid, weight=1.4):
                    self._wm_hits[wid] = self._wm_hits.get(wid, 0) + 1
                    insight += 1
                    self.insight_total += 1
                    self.stats["insight"] = int(self.stats.get("insight", 0)) + 1
                    # 把这条「她刚撞出来的关联」放进待裁决队列。引擎自己不判断对错，
                    # 由外部真理场回来调质（apply_supervise）。队列满了就丢 —— 场强为 0
                    # 时这里照样入队，由 drain_supervise 统一清空，行为链上不留分支。
                    if len(self.sup_queue) < 24:
                        self.sup_queue.append((wid, oid, now))
                    try:
                        self.speak(kind="insight", ids=[wid, oid],
                                   ga=self._plain(wnode), gb=self._plain(old))
                        self.last_insight = "%d-%d" % (wid, oid)
                    except Exception:
                        pass
                    wnode.activation = min(wnode.threshold * 1.4, wnode.activation + 20.0)
                    old.activation = min(old.threshold * 1.4, old.activation + 12.0)
                    break

        # ④-b 黑箱里很挤：到站的旧记忆会踩到箱子里别的星。
        #
        # Phase 1-C 原本只让「工作记忆里的临时词」去撞到站的旧记忆，可
        # submit_to_wm 一直没有调用点，于是 insight 恒为 0、监督队列永远是空的。
        # 黑箱的原始设定（蓝图 Phase 1）是「向心力 + 延迟拷贝 + 碰撞涌现」，并没有要求
        # 必须由临时词参与 —— 两颗长期记忆在原点附近相遇，本来就是最强的涌现来源。
        if ready and (now - self._last_insight_t) >= self.insight_gap:
            pairs = []
            for i, aid in enumerate(ready):
                a = self.nodes.get(aid)
                if a is None:
                    continue
                for bid in ready[i + 1:]:
                    b = self.nodes.get(bid)
                    if b is not None and b.id != a.id:
                        pairs.append((a, b))
                # 箱子里的邻居用 KD 现查（只取 6 个），再并上热点集。
                # 只靠 _box_hot_ids 的话，热点集为空的时刻整片黑箱就撞不出东西。
                near = []
                try:
                    near = [nb for _d, _p, nb in self.kd_nearest(a.pos, k=6, exclude=(a.id,))]
                except Exception:
                    near = []
                for b in near:
                    if b.id == a.id:
                        continue
                    # 只让字和二阶概念参与：句子/段落节点的名字是整句课文，
                    # 带进裁决问句会变成「雨 和 课04_金木水火土 有关系吗」这种东西。
                    if (getattr(b, "kind", "char") or "char") not in ("char", "concept"):
                        continue
                    if math.dist(a.pos, b.pos) <= self.box_radius * 2.4:
                        pairs.append((a, b))
            for a, b in pairs:
                key = (a.id, b.id) if a.id < b.id else (b.id, a.id)
                if key in self._conn_index:
                    continue
                _sim = self._feature_sim(a, b)
                if (_sim < self.box_collide
                        and math.dist(a.pos, b.pos) > self.box_radius * 2.4):
                    continue
                if self._connect(a.id, b.id, weight=1.4):
                    insight += 1
                    self.insight_total += 1
                    self.stats["insight"] = int(self.stats.get("insight", 0)) + 1
                    if len(self.sup_queue) < 24:
                        self.sup_queue.append((a.id, b.id, now))
                    try:
                        self.speak(kind="insight", ids=[a.id, b.id],
                                   ga=self._plain(a), gb=self._plain(b))
                        self.last_insight = "%d-%d" % (a.id, b.id)
                    except Exception:
                        pass
                    a.activation = min(a.threshold * 1.4, a.activation + 18.0)
                    b.activation = min(b.threshold * 1.4, b.activation + 14.0)
                    # 一次到站只撞一条：不限的话每帧都能把箱子里每个未连的邻居撞一遍，
                    # 实测 45 秒就长出 1181 条边、监督队列永远堆满。撞完把它从到站队列摘掉，
                    # 下一次再来就是另一次相遇了。
                    self._last_insight_t = now
                    self.box_copies = [c for c in self.box_copies if c[1] != a.id]
                    break
        # ⑤ 固化 / 遗忘：多巴胺高就留下来，否则 20 秒后被忘掉
        solid = 0
        for wid in list(self._wm.keys()):
            node = self.nodes.get(wid)
            if node is None:
                self._wm.pop(wid, None)
                continue
            age = now - self._wm.get(wid, now)
            wd2 = math.sqrt(node.pos[0] ** 2 + node.pos[1] ** 2 + node.pos[2] ** 2)
            # 必须真的沉到黑箱边缘才谈得上「想明白了」。
            # 实测教训：只按「多巴胺高 + 过 1.5 秒」判，她会在词还挂在外围
            # 半径 88 的时候就直接固化，黑箱等于没参与 —— 那就成了白送记忆。
            if (self.tonic_dopamine >= 4.0 and age >= 5.0
                    and wd2 <= self.box_radius * 1.3):
                node.kind = "char"
                self._wm.pop(wid, None)
                self._wm_hits.pop(wid, None)
                self.wm_solidified += 1
                self.stats["wm_solid"] = int(self.stats.get("wm_solid", 0)) + 1
                try:
                    self.speak(text="呓语：%s 留下来了。" % self._plain(node),
                               kind="learn", ids=[wid])
                except Exception:
                    pass
                solid += 1
            elif age > self.wm_ttl:
                self._wm.pop(wid, None)
                self._wm_hits.pop(wid, None)
                try:
                    self._drop_node(wid)
                except Exception:
                    pass
        return insight + solid

    # ------------------------------------------------------------------
    # V4.0 监督版：外部真理场 + 星点浮动 + 势阱固化 + 自指环
    # ------------------------------------------------------------------
    # 用户的硬约束（m04766）：**严禁用控制性代码**。所以这一整段里没有
    # 「如果监督开着就……否则……」这种分支：监督是一个**场强**（0~1），
    # 所有路径无条件都跑，场强为 0 时它对物理量的影响自然为零。
    # 同理「常用字更牢固」不是白名单，而是每被调用一次势阱深一点的连续过程。

    def _float_step(self, dt, now):
        """星点浮动 + 势阱回弹。纯连续力，没有任何"是不是常用字"的判断。"""
        sp = max(0.0, float(self.float_speed))
        amp = self.float_amp * sp
        hk = self.float_home_k
        cap = self.stiffen_cap
        for n in self.nodes.values():
            nx, ny, nz = n.pos
            hx, hy, hz = n.home
            st = n.stiff
            # 势阱深度 = 回弹刚度。stiff 越大，这颗星离 home 越挪不动。
            k = hk * (0.35 + (st if st < cap else cap))
            n._float_ph += dt * (0.35 + 0.22 * (st if st < 3.0 else 3.0)) * (0.4 + 0.6 * sp)
            ph = n._float_ph
            iid = n.id
            dx = math.sin(ph * 1.7 + iid * 0.37) * amp
            dy = math.cos(ph * 1.3 + iid * 0.61) * amp
            dz = math.sin(ph * 0.9 + iid * 0.29) * amp
            n.pos = (
                nx + (hx - nx) * k + dx * dt,
                ny + (hy - ny) * k + dy * dt,
                nz + (hz - nz) * k + dz * dt,
            )

    def _stiffen(self, node, amount):
        """髓鞘化：这条路又走通了一次，势阱深一点（饱和增长）。"""
        if node is None:
            return 0.0
        before = node.stiff
        gain = amount * max(0.0, float(self.stiffen_gain))
        node.stiff = min(self.stiffen_cap, before + gain * max(0.0, 1.0 - before / self.stiffen_cap))
        # home 只在漂得更远时缓慢跟随 —— 否则她长年累月被拉扯，锚点会跑掉。
        if math.dist(node.pos, node.home) > self.stiffen_radius:
            node.home = (
                node.home[0] + (node.pos[0] - node.home[0]) * 0.25,
                node.home[1] + (node.pos[1] - node.home[1]) * 0.25,
                node.home[2] + (node.pos[2] - node.home[2]) * 0.25,
            )
        return node.stiff - before

    def drain_supervise(self, limit=4):
        """取出待外部裁决的黑箱关联。引擎从不自己判断对错，只把候选交出去。"""
        out = []
        with self._lock:
            q = self.sup_queue
            # 场强为 0 时不采样：外部场不存在，队列里的候选直接作废。
            # 这是「场强」的自然含义，不是行为分支 —— 采样量 = 场强。
            if float(self.llm_supervise) <= 0.0:
                q.clear()
                return out
            while q and len(out) < limit:
                out.append(q.popleft())
        return out

    def apply_supervise(self, a_id, b_id, verdict, gain=1.0):
        """外部真理场对一条黑箱关联的调质。**不删节点、不改拓扑判断。**

        safe   -> 这条边被「承认」：权重上浮、两端势阱变深（这次想对了）
        crisis -> 这条边进入脱敏窗口：通行能力下降（这次想岔了）
        留下的痕迹全由她自己的内稳态去消化 —— 外部只提供势能，不提供动作。
        """
        with self._lock:
            a, b = self.nodes.get(a_id), self.nodes.get(b_id)
            if a is None or b is None:
                return None
            key = (a_id, b_id) if a_id < b_id else (b_id, a_id)
            idx = self._conn_index.get(key)
            if idx is None:
                return None
            g = max(0.0, float(gain)) * max(0.0, float(self.llm_supervise))
            if g <= 0.0:
                return None
            if verdict == "safe":
                self._conn_weight[idx] = min(4.0, self._conn_weight[idx]
                                             + self.sup_strengthen * g)
                self._stiffen(a, 2.0 * g)
                self._stiffen(b, 2.0 * g)
                self.tonic_dopamine = min(self.dopamine_cap,
                                          self.tonic_dopamine + 0.8 * g)
                self.sup_safe += 1
                self._check_self_reflex(a_id, b_id)
            elif verdict == "crisis":
                self._conn_weight[idx] = max(
                    0.05, self._conn_weight[idx] * (1.0 - self.sup_attenuate * g))
                # 边级脱敏必须跟「逐字受体脱敏」分两个字典：_desens 的值是
                # {n, t, block} 结构，往里塞 float 会让 _receptor_ok 的清理循环
                # 炸成 TypeError（曾让 char_loop 连挂 108 次、字进不了大脑）。
                self._desens_edges["%d:%d" % key] = time.time() + self.desens_hold
                if len(self._desens_edges) > 240:
                    _now_e = time.time()
                    for _k in [x for x, v in self._desens_edges.items() if v <= _now_e]:
                        self._desens_edges.pop(_k, None)
                self.sup_crisis += 1
            self.sup_done += 1
            return {"a": a_id, "b": b_id, "verdict": verdict,
                    "w": round(self._conn_weight[idx], 3)}

    def _check_self_reflex(self, a_id, b_id):
        """自指：被承认的黑箱关联如果绕回自己，就长出一个闭环。

        只查长度 3 的环，只看 insight 级别的边（weight≈1.4）。这不是「意识」，
        但它给自我指涉留了结构位置 —— 没有闭环的图，永远只是特征仓库。
        """
        try:
            for c_id in (a_id, b_id):
                for key, idx in list(self._conn_index.items()):
                    if key[0] != c_id:
                        continue
                    other = key[1]
                    if other in (a_id, b_id):
                        continue
                    if abs(self._conn_weight[idx] - 1.4) > 0.01:
                        continue
                    back = (other, a_id if c_id == b_id else b_id)
                    back = (back[0], back[1]) if back[0] < back[1] else (back[1], back[0])
                    if back not in self._conn_index:
                        continue
                    self.self_reflex += 1
                    node = self.nodes.get(c_id)
                    label = self._plain(node) if node is not None else str(c_id)
                    self.last_self_reflex = label
                    try:
                        self.speak(text="呓语：%s 绕回来了。" % label,
                                   kind="reflex", ids=[c_id])
                    except Exception:
                        pass
                    self.tonic_dopamine = min(self.dopamine_cap,
                                              self.tonic_dopamine + 1.2)
                    return True
        except Exception:
            pass
        return False
    def box_snapshot(self):
        """给观测台看的黑箱状态。"""
        with self._lock:
            return {
                "radius": round(float(self.box_radius), 2),
                "pull": round(float(self.box_pull), 3),
                "pulled": int(self.box_pulled),
                "copied": int(self.box_copied),
                "copies": len(self.box_copies),
                "wm": len(self._wm),
                "wm_cap": int(self.wm_cap),
                "wm_made": int(self.wm_made),
                "wm_solidified": int(self.wm_solidified),
                "insight": int(self.insight_total),
                # Phase 2：临时区到底是哪几颗星（前端给它们上浅黄光圈）
                "wm_ids": sorted(int(k) for k in self._wm.keys()),
            }

    def _dream_step(self, dt, now):
        """睡眠梦境游走：每秒 dream_rate 次（默认 0.2，即每 5 秒一次）。"""
        rate = float(self.dream_rate)
        if rate <= 0.0:
            self._dream_acc = 0.0
            return 0
        self._dream_acc += rate * dt
        made = 0
        guard = 0
        while self._dream_acc >= 1.0 and guard < 8:
            self._dream_acc -= 1.0
            guard += 1
            try:
                if self._dream_wander(now) is not None:
                    made += 1
            except Exception:
                # 梦境绝不能把主循环带崩：单次失败就跳过这一次
                self._dream_acc = 0.0
                break
        return made

    def _dream_wander(self, now=None):
        """梦里的一次随机放电：抽一个节点点亮，再顺着空间近邻牵一条弱边。

        刻意不复用 awake_think：
          - awake_think 在睡眠态第一行就 return "深度睡眠中"
          - wake 路径会 stats["aha"] += 1，梦会把生物钟骗回亢奋
        """
        now = time.time() if now is None else float(now)
        if not self.nodes:
            return None
        pool = list(self.nodes.values())
        a = random.choice(pool)
        # 注入量必须跨过 threshold(50)，否则 try_activate 恒 False、fired 恒空，
        # 一条梦呓都说不出来（实测 dream_total 涨了 10，日志 0 条）。
        # 放电后 try_activate 会把它压回 threshold*0.2 附近，正好是"微弱放电后回落"。
        a.activation += random.uniform(52.0, 72.0)
        fired = []
        try:
            if a.try_activate(now, 0.0):
                fired.append(a)
        except Exception:
            pass

        # 梦里也会串门：在空间近邻里挑一个，把它也点亮，并连一条弱边
        near = []
        reach = self.neighbor_radius * 1.5
        for b in pool:
            if b.id == a.id:
                continue
            d = math.dist(a.pos, b.pos)
            if d <= reach:
                near.append((d, b))
        if near and random.random() < 0.65:
            near.sort(key=lambda t: t[0])
            pick = near[0][1] if random.random() < 0.7 else random.choice(near)[1]
            pick.activation += random.uniform(20.0, 34.0)
            try:
                if pick.try_activate(now, 0.0):
                    fired.append(pick)
            except Exception:
                pass
            try:
                self._connect(a.id, pick.id, weight=0.4)
            except Exception:
                pass

        self.dream_total += 1
        self.last_dream_t = now
        if fired:
            who = a.glyph or ("节点%d" % a.id)
            self.last_dream = who
            try:
                self.speak(text="梦呓：「%s」在很小声地响。" % who,
                           kind="dream", ids=[a.id])
            except Exception:
                pass
        return fired[0] if fired else None

    def set_paused(self, paused):
        """时间控制开关，返回实际状态。恢复时把漏电基准对齐到当下。"""
        with self._lock:
            self.paused = bool(paused)
            if not self.paused:
                now = time.time()
                for n in self.nodes.values():
                    n._last_decay_t = now
                self._last_consolidate = now
            return self.paused

    def receive_reassurance(self, amount=1.0):
        """H 模块：消除未知之后获得的确定感 → 安全感回归、疲劳回落。

        由 aha_server.py 在教完小鱼之后调用（DeepSeek 的答案即"百科全书"）。
        """
        with self._lock:
            self.tone_excitation = min(
                self.target_safety * 1.15, self.tone_excitation + 2.0 * amount
            )
            self.fatigue = max(0.0, self.fatigue - 3.0 * amount)

    def receive_threat(self, amount=1.0):
        """H 模块的另一半：被判定为「未知 / 错误」之后落下来的危机感。

        不是惩罚，是标记：她不需要知道"我错了"这三个字，
        只需要身体里那股确定感被抽走一点、疲劳多留一会儿。
        """
        with self._lock:
            self.tone_excitation = max(
                self.tonic_inhibition * 0.55,
                self.tone_excitation - 3.0 * amount,
            )
            self.fatigue = min(100.0, self.fatigue + 2.0 * amount)
            self.threat_level = min(20.0, self.threat_level + 1.0 * amount)
            return self.threat_level

    # =====================================================================
    # 主循环
    # =====================================================================

    def tick(self, dt=0.1, now=None):
        """推进一帧：漏电 → 稳态 → 低频巩固

        now 可注入虚拟时钟（自测/回放用），缺省即真实时间。
        """
        dt = _clamp(float(dt), 1e-4, 1.0)
        now = time.time() if now is None else float(now)
        with self._lock:
            # 造物主控制台【暂停】：冻结时间，但不冻结"记账"。
            # 暂停期间必须把每个节点的漏电基准时刻推到 now，否则一恢复
            # 就凭空欠下几十秒的衰减债，整张网会瞬间熄灭。
            if self.paused:
                for n in self.nodes.values():
                    n._last_decay_t = now
                self._last_consolidate = now
                self.last_think_meta = dict(self.last_think_meta, paused=True)
                return
            for n in self.nodes.values():
                n.tick_decay(now)
            # 背景底噪：极小全局膜电位微扰（"她还活着"的证据）
            self._bg_inject(dt)
            # 危机感随时间回落：被纠正的刺痛会淡，但不会立刻消失
            if self.threat_level > 0.0:
                self.threat_level = max(0.0, self.threat_level - 0.25 * dt)
            self.update_homeostasis(dt)
            self._update_biorhythm(dt, now)
            # 背景电活动：持续的局部电位（用户 m02813）。
            # 放在 biorhythm 之后是有意的：睡眠态的 drain（每帧 x0.80）在
            # _sleep_step 里，先 drain 再注入，注入的电位才不会被同帧削掉八成。
            self._spike_step(dt, now, dream=bool(self.sleeping))
            # 突触延迟：上一帧发出的信号到站了没有（新线慢、老线快）
            self._conduct_step(now)
            # V4.0 Phase 4：脊髓反射 —— 信号到站之后，肌肉先动，大脑后知。
            self._spinal_step(dt, now)
            # 梦境游走：睡眠态也每秒 0.2 次随机点亮（A2 不完全停摆）
            if self.sleeping:
                self._dream_step(dt, now)
                # 海马体：睡着时回放高情绪情景（带危险的优先）
                self._replay_step(dt, now)
            # 说话的欲望：放在 _spike_step / _dream_step 之后，同一帧的
            # 自发放电和梦里连线就能立刻换算成"想说话"的冲动。
            self._update_desire(dt, now)
            # V4.0 潜意识黑箱：向心力 / 延迟拷贝 / 碰撞涌现 / 固化或遗忘。
            # 放在最后 —— 它要读本帧的 tonic_dopamine（固化判据）和
            # fire_count（高频记忆判据），这两个都在前面几步才更新完。
            self._box_step(dt, now)
            # V4.0 监督版：星点浮动 + 势阱回弹。纯连续力 —— 没有「常用/不常用」的判断，
            # 向心力把星拽向原点，回弹把走过很多次的那几颗按在 home，两种力叠出来的
            # 就是「常用字纹丝不动、边缘字轻轻漂」。
            self._float_step(dt, now)
            # KD 索引要跟着位置走，但每帧重建 1500 点太贵：4 秒一次足够
            # （浮幅 < 1 单位，检索误差远小于 neighbor_radius=10）。
            if now - self._float_kd_t >= 4.0:
                self._float_kd_t = now
                self.kd_rebuild()
            if now - self._last_consolidate >= self.consolidate_interval:
                self._last_consolidate = now
                self.consolidate()

    def consolidate(self, samples=120):
        """睡眠态巩固：空间上靠得近的节点之间建立横向连接。

        修复#4（最重要的哲学修复）：骨架里新节点坐标是 random.uniform(-50,50)
        全图随机撒点，无论喂多少输入都长不出一棵树。真正让记忆"聚类成树"的
        是这个巩固过程 + add_new_experience 里的"挂在最近邻旁边"。
        """
        nodes = list(self.nodes.values())
        if len(nodes) < 2:
            return 0
        made = 0
        reach = self.neighbor_radius * 2.5
        for _ in range(samples):
            a = random.choice(nodes)
            if a.id not in self.nodes:
                continue
            # V4.0：最近的 3 个交给 KD-Tree，不再每轮 O(n) 全量扫一遍。
            # （旧写法在 3000 节点时，每次巩固要算 120 x 3000 次距离。）
            cand = self.kd_nearest(a.pos, k=3, exclude=(a.id,))
            for d, _pid, b in cand:
                if d <= reach and self._connect(a.id, b.id, weight=0.4):
                    made += 1
        return made

    # =====================================================================
    # 清醒态思考
    # =====================================================================

    def awake_think(self, current_time, input_feature_vector):
        """清醒态：基于输入的定向联想（骨架流程保留，补齐 None 分支）"""
        with self._lock:
            # 生物钟：睡眠态强制切断 A2 随机游走（"切断所有外部输入"的执行端）
            if self.sleeping:
                self.last_thought = "（深度睡眠中，突触正在被修剪）"
                return self.last_thought
            # 漏洞三：疲劳断路器
            if self.fatigue > 90.0:
                self.last_thought = "系统疲劳，拒绝思考"
                return self.last_thought
            if not self.nodes:
                self.last_thought = "空白。没有任何记忆可以被点亮。"
                return self.last_thought

            # 1. 特征检索
            target_node = self._find_closest_node(input_feature_vector)
            novel = target_node is None
            if novel:
                # 全新未知：H 模块拉响警觉，退回任意锚点做探索
                target_node = random.choice(list(self.nodes.values()))

            sal = self._salience_of(input_feature_vector)

            # 2. 先尝试点亮锚点本身
            anchor_fired = target_node.try_activate(current_time, 18.0 * sal)

            # 3. A2 模块：定向随机游走，抽 5 个空间邻居
            neighbors = self._get_spatial_neighbors(target_node)
            # 优先挑"已经过了绝对不应期"的邻居。
            # 旧实现纯随机抽 5 个：实测 52% 的思考落在"卡在相对不应期
            # （阈值翻倍=100）"的节点上，10~30 的刺激根本推不动，于是长期
            # 报"思考中...没有任何东西被点亮"。可用池非空时只在可用池里抽，
            # 全都在锁死状态才退回全池（保留骨架的随机性）。
            ready = [
                n for n in neighbors
                if (current_time - n.last_fired_time) >= n.abs_refractory
            ]
            pool = ready if ready else neighbors
            batch = random.sample(pool, min(5, len(pool))) if pool else []

            # 4. E 模块：尝试连通与放电
            for node in batch:
                if node.try_activate(current_time, random.uniform(10, 30) * sal):
                    self._connect(target_node.id, node.id)
                    try:
                        self._conduct(node.id, current_time)
                    except Exception:
                        pass
                    self._trigger_positive_feedback(node)
                    self.stats["aha"] += 1
                    if (getattr(node, "verdict", None) or "").lower() in ("crisis", "danger"):
                        self._noci_buf += 1.6
                    self.last_thought = "顿悟：连接了 %s 与 %s" % (
                        self._label(target_node), self._label(node))
                    # G 模块：把这次连接翻译成一句人话（唯一"输出口"）
                    try:
                        ga = target_node.glyph
                        gb = node.glyph
                        ma = target_node.meaning or ""
                        mb = node.meaning or ""
                        # 认字之后说话要念出意思（用户要求 4）。两个字都有
                        # 百科全书标签时，按"意思是否相同"选不同模板：
                        # 同义 -> "它们都是河流"；异义 -> "一个是山，一个是火"。
                        if ga and gb and ma and mb:
                            kind = "lexicon_same" if ma == mb else "lexicon_sem"
                        elif ga and gb:
                            kind = "lexicon"
                        else:
                            kind = "novel_link" if novel else "muse"
                        self.speak(
                            kind=kind,
                            ids=[target_node.id, node.id],
                            a=target_node.id, b=node.id,
                            c1=target_node.color_name(), c2=node.color_name(),
                            ga=("「%s」" % ga) if ga else ("节点%d" % target_node.id),
                            gb=("「%s」" % gb) if gb else ("节点%d" % node.id),
                            ma=ma or "说不清的东西",
                            mb=mb or "说不清的东西",
                        )
                    except Exception:
                        pass
                    self.last_think_meta = {
                        "anchor": target_node.id, "novel": novel,
                        "candidates": len(neighbors), "ready": len(ready),
                        "fired": node.id, "reason": "aha",
                    }
                    return self.last_thought

            if anchor_fired:
                self.last_thought = "锚点 %s 被点亮，但没有新的联想" % target_node.id
                reason = "anchor_only"
            elif novel:
                self.last_thought = "陌生的东西，还没有任何记忆能和它对上"
                reason = "novel"
            else:
                self.last_thought = "思考中...没有任何东西被点亮"
                reason = "silent"
            # 供前端显示"候选 N / 可用 M"，一眼看出是没候选还是全在不应期
            self.last_think_meta = {
                "anchor": target_node.id, "novel": novel,
                "candidates": len(neighbors), "ready": len(ready),
                "fired": 0, "reason": reason,
            }
            return self.last_thought

    # =====================================================================
    # 生长
    # =====================================================================

    def add_new_experience(self, feature_vector, salience=1.0, anchor=None, glyph=None,
                           pinyin=None):
        """遇到全新未知，生成新节点。

        修复#4: 不再全图随机。优先挂在"特征最接近的已有节点"旁边，
        相似度越高贴得越近 → 自然长出聚类与枝干；只有在完全空白时才随机撒点。
        """
        now = time.time()
        with self._lock:
            parent = anchor
            if parent is None and self.nodes and feature_vector is not None:
                parent = self._find_closest_node(feature_vector, threshold=-2.0,
                                                 kinds=("char",))

            if parent is not None and feature_vector is not None:
                sim = self._cosine(parent.features_z, self._standardize(feature_vector))
                # 相似 → 紧贴(≈2.5)；陌生 → 稍微拉开(≈8)。上限必须收紧，
                # 否则链式生长会把记忆一路漂到坐标原点半径 50 以外，星云散架。
                spread = 2.5 + (1.0 - _clamp(sim, 0.0, 1.0)) * 5.5
                pos = (
                    parent.pos[0] + random.gauss(0.0, spread),
                    parent.pos[1] + random.gauss(0.0, spread),
                    parent.pos[2] + random.gauss(0.0, spread),
                )
            else:
                # 第一条记忆：随机锚点（骨架原语义），范围收窄到 ±30
                pos = (
                    random.uniform(-30.0, 30.0),
                    random.uniform(-30.0, 30.0),
                    random.uniform(-30.0, 30.0),
                )
                parent = None

            # 修复#15: 记忆容量上限。无限喂噪声会让节点数无界增长，
            # 前端和内存一起爆。超出时先修剪（遗忘本来就是记忆的一部分）。
            if len(self.nodes) >= self.max_nodes:
                self._prune()

            new_id = self._next_id
            self._next_id += 1
            node = NeuronNode(new_id, pos[0], pos[1], pos[2], feature_vector,
                              now=now, salience=salience, glyph=glyph, pinyin=pinyin)
            self.nodes[new_id] = node

            # 树状记忆：新节点与它的"父节点"直接连一条枝干
            if parent is not None:
                self._connect(parent.id, new_id, weight=0.8)

            self.stats["new_nodes"] += 1
            self._kd_insert(new_id, node.pos)
            # G 模块：新生儿第一次开口。认识字的孩子，第一句话就说得出自己的名字。
            try:
                if glyph:
                    self.speak(kind="glyph_birth", ids=[new_id], n=new_id,
                               ncolor=node.color_name(), glyph=glyph)
                else:
                    self.speak(kind="birth", ids=[new_id], n=new_id, ncolor=node.color_name())
            except Exception:
                pass
            return new_id

    def _prune(self, keep_ratio=0.88):
        """记忆修剪：按"活跃度 x 放电次数 x 稀缺度"淘汰，保留大多数。

        被淘汰节点的连接一并清理，避免天文台上出现悬空的红线。
        """
        nodes = list(self.nodes.values())
        n_keep = max(1, int(len(nodes) * keep_ratio))
        nodes.sort(key=lambda n: (n.activation + n.fire_count * 2.0 + n.salience), reverse=True)
        dead = {n.id for n in nodes[n_keep:]}
        for nid in dead:
            self.nodes.pop(nid, None)
            if self._kd is not None:
                self._kd.remove(nid)
        if dead:
            kept_conns, kept_w = [], []
            self._conn_index.clear()
            for (a, b), w in zip(self.connections, self._conn_weight):
                if a in dead or b in dead:
                    continue
                self._conn_index[(a, b)] = len(kept_conns)
                kept_conns.append((a, b))
                kept_w.append(w)
            self.connections = kept_conns
            self._conn_weight = kept_w
        return len(dead)

    # =====================================================================
    # V4.0：三维空间索引 + 语言学基因播种
    # =====================================================================

    def _kd_insert(self, nid, pos):
        """新节点进索引。KD-Tree 缺失时静默跳过（兜底逻辑仍然能用）。"""
        if self._kd is None:
            return
        try:
            self._kd.insert(nid, pos)
        except Exception:
            self.kd_ready = False

    def kd_rebuild(self):
        """把 KD-Tree 与 self.nodes 完全对齐。读档、批量建节点之后必须调。"""
        if self._kd is None:
            return 0
        with self._lock:
            self._kd.rebuild([(n.id, n.pos) for n in self.nodes.values()])
            self.kd_ready = True
            self.kd_stats = self._kd.stats
            return len(self._kd)

    def kd_nearest(self, point, k=8, exclude=None):
        """空间最近 k 个（对外接口，二阶概念节点与工作记忆都要用）。"""
        if self._kd is None:
            return []
        if not self.kd_ready:
            self.kd_rebuild()
        self.kd_queries += 1
        return [(d, pid, self.nodes[pid]) for d, pid, _p in self._kd.knn(point, k, exclude=exclude)
                if pid in self.nodes]

    def seed_lexicon(self, featurizer=None, max_new=None, attach_to_existing=True,
                     link_field=True, link_cooccur=True, progress=None):
        """语言学基因播种：按共现坐标铺基础字节点（用户 m04082 Phase 1）。

        这是「基因」不是「学习」：不调大模型、不产生 Aha、不写意识流。
        规则：
          1. 已经存在的同字节点一律不动 —— 她的记忆不该被基因改写。
          2. 新字的坐标来自 aha_lexicon.seed_layout()：共现强的字物理相邻。
          3. 但若它的共现伙伴已经在图里，就长在伙伴旁边（熟人带路），
             而不是硬搬到基因坐标 —— 这样新字永远挨着真正的记忆。
          4. 场内相邻字连 1.6 的边、共现对连 2.0 的边：这是"天生的语感"。
        """
        try:
            layout = _lexicon.seed_layout()
        except Exception as exc:
            print("[aha_brain] 基因表加载失败: %r" % (exc,))
            return {"created": 0, "existing": 0, "links": 0, "error": str(exc)}
        created = existing = 0
        links = 0
        # 播种必须可复现：同一条基因表在哪儿播都一样。
        # 用全局 random 的话「熟人带路」的抖动会随进程种子漂移，
        # 同一份存档两次重播会长出不同的词。
        rng = random.Random(20261030)
        with self._lock:
            idx = self._glyph_index()
            for g, p in layout.items():
                if max_new is not None and created >= max_new:
                    break
                if g in idx:
                    existing += 1
                    continue
                feat = None
                if featurizer is not None:
                    try:
                        feat = featurizer(g)
                    except Exception:
                        feat = None
                pos = p
                if attach_to_existing:
                    for other in _lexicon.cooccur_partners(g):
                        ns = idx.get(other)
                        if not ns:
                            continue
                        pa = ns[0].pos
                        pos = (pa[0] + rng.gauss(0.0, 3.2),
                               pa[1] + rng.gauss(0.0, 3.2),
                               pa[2] + rng.gauss(0.0, 3.2))
                        break
                nid = self._next_id
                self._next_id += 1
                node = NeuronNode(nid, pos[0], pos[1], pos[2], feat, glyph=g)
                self.nodes[nid] = node
                self._kd_insert(nid, node.pos)
                idx.setdefault(g, []).append(node)
                created += 1
                if progress is not None and created % 100 == 0:
                    try:
                        progress(created)
                    except Exception:
                        pass
            if link_field:
                for _name, chars in _lexicon.FIELDS:
                    ids = [idx[c][0].id for c in chars if c in idx]
                    for i in range(len(ids) - 1):
                        if self._connect(ids[i], ids[i + 1], weight=1.6):
                            links += 1
            if link_cooccur:
                for a, b in _lexicon.cooccur_pairs():
                    na = idx.get(a)
                    nb = idx.get(b)
                    if not na or not nb:
                        continue
                    if self._connect(na[0].id, nb[0].id, weight=2.0):
                        links += 1
            # 基因边不是"她新学到的连接"，不该计入 new_links 的成长曲线
            self.stats["new_links"] = max(0, self.stats.get("new_links", 0) - links)
            self.lex_seeded = created
            self.lex_existing = existing
            self.kd_ready = False
        return {"created": created, "existing": existing, "links": links,
                "glyphs": len(layout)}

    # =====================================================================
    # 输入总入口（供 aha_input.py 调用）
    # =====================================================================

    def grow_concept(self, word, now=None):
        """二阶概念节点（V4.0 Phase 1-B）。

        用户 m04082：「遇到输入词（如"江水"），如果底层节点距离极近，
        自动在 Z 轴高处生成"二阶概念节点"，并向底建强连线。
        只算局部 Top-3，拒绝组合爆炸。」

        规则：
          1. 词里每个字都得已经认识，否则等她学会再说 —— 不凭空造概念。
          2. 「挨着」两条判据二选一：直线距离 <= concept_close；
             或者距离在 2.5 倍以内、且互为对方最近的 concept_topk 个邻居之一。
          3. 概念节点住在成分字的正上方（xy 取质心，z 取最高那个再加一截），
             所以俯视图里它落在几个字中间、侧视图里浮在上层 —— 这就是"二阶"。
          4. 向每个成分字连一条 concept_weight 的强边（> prune_weight，睡眠不剪）。
        """
        word = (word or "").strip()
        if len(word) < 2 or len(word) > 4:
            return None
        now = time.time() if now is None else float(now)
        with self._lock:
            hit = self._concepts.get(word)
            if hit is not None:
                node = self.nodes.get(hit)
                if node is not None:
                    return {"event": "concept_recall", "node_id": hit, "word": word}
                self._concepts.pop(word, None)
            if self.concepts_made >= self.concept_max:
                return None
            # 含虚词的组合不是词：「我是」「是小」「的了」不该长成概念。
            # 这条过滤比"共现频率"粗，但不需要额外统计就能挡住绝大部分垃圾。
            for ch in word:
                if ch in self._WEAK_CHARS:
                    return None
            idx = self._glyph_index()
            parts = []
            for ch in word:
                ns = idx.get(ch)
                if not ns:
                    return None
                parts.append(ns[0])
            if len(parts) < 2:
                return None
            # 真词（在 274 条高频词表里）用标准阈值；滑窗粘连出来的组合
            # （「家爸」「小间」）必须挨得更近才算数 —— 它们没有词的地位。
            limit = self.concept_close
            try:
                if word not in _lexicon.WORD_SET:
                    limit = self.concept_close * 0.7
            except Exception:
                pass
            near = 0
            for i in range(len(parts) - 1):
                a = parts[i]
                b = parts[i + 1]
                if a.id == b.id:
                    continue
                d = math.dist(a.pos, b.pos)
                if d <= limit:
                    near += 1
                    continue
                if d > limit * 2.2:
                    continue
                top = self.kd_nearest(a.pos, k=self.concept_topk + 1, exclude=(a.id,))
                if any(nb.id == b.id for _dd, _pp, nb in top):
                    near += 1
            if near < len(parts) - 1:
                return None
            cx = sum(p.pos[0] for p in parts) / float(len(parts))
            cy = sum(p.pos[1] for p in parts) / float(len(parts))
            cz = max(p.pos[2] for p in parts) + self.concept_z_rise
            with_feat = [p for p in parts if p.features]
            feat = None
            if with_feat:
                dim = max(len(p.features) for p in with_feat)
                acc = [0.0] * dim
                for p in with_feat:
                    for k, v in enumerate(p.features[:dim]):
                        acc[k] += float(v)
                feat = [v / float(len(with_feat)) for v in acc]
            if len(self.nodes) >= self.max_nodes:
                self._prune()
            nid = self._next_id
            self._next_id += 1
            node = NeuronNode(nid, cx, cy, cz, feat, now=now,
                              salience=1.4, glyph=word[:2], kind="concept", text=word)
            self.nodes[nid] = node
            self._kd_insert(nid, node.pos)
            for p in parts:
                self._connect(nid, p.id, weight=self.concept_weight)
            self.concepts_made += 1
            self._concepts[word] = nid
            self.stats["concepts"] = self.stats.get("concepts", 0) + 1
            return {"event": "concept", "node_id": nid, "word": word,
                    "parts": [p.id for p in parts]}

    def _link_sentence(self, meta, node_id):
        """同一句话里的字连成一条链，句子读完再长出一颗句节点（m03927）。

        边权 1.2，高于 prune_weight(1.05) —— 属于主干，睡眠修剪不会动它。
        只在 meta 里有 sent_id 时才做：单独投喂一个字不该凭空长出一条边。

        这不是语法分析。引擎不知道主谓宾，只知道"这两个字曾经在一句话里
        挨着出现过"。但对她说话已经够了：compose_reply 顺着边找邻居，
        「江」的邻居里就会先出现「河」「海」这些同句伙伴。
        """
        sid = meta.get("sent_id") or None
        glyph = meta.get("glyph") or ""
        if not sid or not node_id:
            return None
        doc = str(sid).split(":")[0]
        # 换篇了：先把上一句收干净，再把上一段收掉（用户 m03927：段 = 一篇课文）
        if self._cur_doc and self._cur_doc != doc:
            if self._cur_sent:
                self._close_sentence(self._cur_sent)
                self._cur_sent = None
            self._close_paragraph(self._cur_doc)
        self._cur_doc = doc
        # 换句了：上一句收尾，长出它的句节点
        if self._cur_sent and self._cur_sent != sid:
            self._close_sentence(self._cur_sent)
        if sid != self._cur_sent:
            self._sent_nodes[sid] = []
            self._sent_text[sid] = ""
            self._cur_sent = sid
        bucket = self._sent_nodes.setdefault(sid, [])
        if node_id not in bucket:
            bucket.append(node_id)
        if glyph:
            self._sent_text[sid] = self._sent_text.get(sid, "") + str(glyph)
        prev = self._sent_ctx.get(sid)
        if prev is not None and prev != node_id and prev in self.nodes:
            self._connect(prev, node_id, weight=1.2)
        self._sent_ctx[sid] = node_id
        # 只记最近 8 句。一本书读完上下文就该忘，不能拿着第 1 句去连第 900 句。
        if len(self._sent_ctx) > 8:
            for k in list(self._sent_ctx.keys())[:-8]:
                self._sent_ctx.pop(k, None)
        return prev

    # -- 三层结构的生长（用户 m03927：字 -> 句 -> 段）-----------------------

    @staticmethod
    def _mix_features(feats):
        """句 / 段的特征向量 = 组成它的那些节点特征的平均。"""
        got = [f for f in (feats or []) if f]
        if not got:
            return None
        dim = min(len(f) for f in got)
        m = float(len(got))
        return [sum(f[k] for f in got) / m for k in range(dim)]

    @staticmethod
    def _mix_position(nodes, lift=2.2):
        """句 / 段长在它那些节点的重心上，再往上抬一点点。

        抬是必须的：不抬就会和某一个字重合，而 _get_spatial_neighbors
        的距离判据是 0 < dist，重合等于互相看不见。
        """
        got = [n for n in (nodes or []) if n is not None]
        if not got:
            return (0.0, 0.0, 0.0)
        m = float(len(got))
        cx = sum(n.pos[0] for n in got) / m
        cy = sum(n.pos[1] for n in got) / m
        cz = sum(n.pos[2] for n in got) / m
        return (cx + random.gauss(0.0, 0.5),
                cy + random.gauss(0.0, 0.5),
                cz + lift + random.gauss(0.0, 0.5))

    def _close_sentence(self, sid):
        """一句话读完：在这句字的团心长出一颗句节点，连向句中的每一个字。

        三个刻意的取舍：
          - 少于 struct_sent_min(3) 个字的句子不建 —— 「好。」不值得占一颗星
          - 同一句原文只长一颗 —— 课文里重复出现的句子不再复制一份
          - 边权 2.5 > prune_weight(1.05)，属于主干，睡眠修剪不会拆散它
        """
        ids = self._sent_nodes.pop(sid, None) or []
        text = (self._sent_text.pop(sid, None) or "").strip()
        self._sent_ctx.pop(sid, None)
        if len(ids) < self.struct_sent_min or not text:
            return None
        exist = self._sentence_index.get(text)
        if exist is not None and exist in self.nodes:
            return exist
        nodes = [self.nodes[i] for i in ids
                 if i in self.nodes
                 and (getattr(self.nodes[i], "kind", "char") or "char") == "char"]
        if len(nodes) < self.struct_sent_min:
            return None
        feat = self._mix_features([n.features for n in nodes])
        pos = self._mix_position(nodes, lift=2.2)
        nid = self._next_id
        self._next_id += 1
        node = NeuronNode(nid, pos[0], pos[1], pos[2], feat, salience=1.0,
                          kind="sentence", text=text)
        self.nodes[nid] = node
        for n in nodes:
            self._connect(nid, n.id, weight=2.5)
        self._sentence_index[text] = nid
        doc = str(sid).split(":")[0]
        self._para_ctx.setdefault(doc, []).append(nid)
        self._para_text[doc] = self._para_text.get(doc, "") + text
        self.stats["sentences"] += 1
        self.stats["new_nodes"] += 1
        self._kd_insert(nid, node.pos)
        # 海马体：这一句同时登记成一条情景记忆（带情绪价，睡眠时回放）
        try:
            self.remember_episode(nid, text, nodes, now=node.created_at)
        except Exception:
            pass
        self.last_thought = "成句：%d 个字聚成了「%s」" % (len(nodes), text[:12])
        return nid

    def _close_paragraph(self, doc):
        """一段读完（一篇课文读完）：在这段句节点的团心长出一颗段节点。"""
        sids = self._para_ctx.pop(doc, None) or []
        text = (self._para_text.pop(doc, None) or "").strip()
        if len(sids) < self.struct_para_min or not text:
            return None
        exist = self._paragraph_index.get(doc)
        if exist is not None and exist in self.nodes:
            return exist
        nodes = [self.nodes[i] for i in sids
                 if i in self.nodes
                 and (getattr(self.nodes[i], "kind", "") or "") == "sentence"]
        if len(nodes) < self.struct_para_min:
            return None
        feat = self._mix_features([n.features for n in nodes])
        pos = self._mix_position(nodes, lift=3.4)
        nid = self._next_id
        self._next_id += 1
        node = NeuronNode(nid, pos[0], pos[1], pos[2], feat, salience=1.0,
                          kind="paragraph", text=text)
        self.nodes[nid] = node
        for n in nodes:
            self._connect(nid, n.id, weight=2.5)
        self._paragraph_index[doc] = nid
        self.stats["paragraphs"] += 1
        self.stats["new_nodes"] += 1
        self._kd_insert(nid, node.pos)
        self.last_thought = "成段：%d 句话连成了这一段" % len(nodes)
        return nid

    def flush_structure(self):
        """一课读完时收尾：把还挂着的句子和段落收掉。

        没有它，最后一句话会一直停在 _cur_sent 里，直到下一次投喂才开始生长 ——
        天文台上就永远缺最后一段。幂等：没东西可收就返回 None。
        """
        with self._lock:
            out = {"sentence": None, "paragraph": None}
            if self._cur_sent:
                out["sentence"] = self._close_sentence(self._cur_sent)
                self._cur_sent = None
            if self._cur_doc:
                out["paragraph"] = self._close_paragraph(self._cur_doc)
                self._cur_doc = None
            return out

    def learn(self, feature_vector, meta=None, now=None):
        """喂一次感官输入：认识就联想，不认识就生长出新记忆。

        返回 dict 供上位层记录/展示。
        """
        now = time.time() if now is None else float(now)
        # 中文文本模式：meta 里带着这个字本身、百科全书给的标签、以及安全判定。
        meta = meta or {}
        glyph = meta.get("glyph") or None
        meaning = meta.get("meaning") or None
        verdict = meta.get("verdict") or None
        pinyin = meta.get("pinyin") or None
        with self._lock:
            # V4.0 可逆受体脱敏：连着第 10 次同一个字，她就当没听见。
            # 放在最前面 —— 连"认识"都不查，否则她还是会点亮那颗星。
            if glyph and not self._receptor_ok("g:" + glyph, now):
                self.stats["inputs"] += 1
                self.last_input_time = now
                return {
                    "event": "desensitized",
                    "node_id": None,
                    "salience": 0.0,
                    "thought": "呓语：又是%s。听见了，不想再听一遍。" % glyph,
                    "meta": dict(meta),
                }
            self.stats["inputs"] += 1
            self.last_input_time = now
            sal = self._salience_of(feature_vector)
            # 文字模式：一个字 = 一个节点。
            # 先按字形精确找，"江"永远是同一个"江"，不会因为出现次数多就被
            # 复制成一堆孪生节点。
            target = None
            if glyph:
                for n in self.nodes.values():
                    if n.glyph == glyph:
                        target = n
                        break
            if target is None:
                target = self._find_closest_node(feature_vector, kinds=("char",))
                # 但也不许"河"被特征相近的"江"认领 —— 字与字是不同记忆。
                if target is not None and target.glyph and target.glyph != glyph:
                    target = None

            if target is None:
                node_id = self.add_new_experience(
                    feature_vector, salience=sal, glyph=glyph, pinyin=pinyin)
                fresh = self.nodes.get(node_id)
                if fresh is not None and (meaning or verdict):
                    fresh.meaning = meaning[:32] if meaning else None
                    fresh.verdict = verdict
                    fresh.meaning_at = now
                self.last_thought = "未知：建立新记忆节点 %s%s（稀缺度 %.2f）" % (
                    node_id, ("「%s」" % glyph) if glyph else "", sal)
                self._link_sentence(meta, node_id)
                return {
                    "event": "new_node",
                    "node_id": node_id,
                    "salience": round(sal, 3),
                    "thought": self.last_thought,
                    "meta": meta or {},
                }

            thought = self.awake_think(now, feature_vector)
            # 已经认识的东西：强化印记。
            # 修复#12: 受绝对不应期护盾——2 秒内重复出现不会把同一个点无限顶满
            # （否则高速连喂同一批文件时，单点会瞬间饱和到阈值的 1.5 倍并拖垮稳态）。
            if now - target.last_fired_time >= target.abs_refractory:
                target.activation = min(target.threshold * 0.9, target.activation + 15.0 * sal)
            # 认识的字：把这次的标签贴回它身上。
            # 一个字只认领一次名字（首次教学），之后的重复投喂只刷新安全判定，
            # 不让 DeepSeek 每次的口径漂移把老记忆覆盖成新词。
            if glyph and not target.glyph:
                target.glyph = glyph[:2]
            if pinyin and not getattr(target, "pinyin", None):
                target.pinyin = pinyin[:24]
            if meaning and not target.meaning:
                target.meaning = meaning[:32]
                target.meaning_at = now
            if verdict:
                target.verdict = verdict
                target.meaning_at = now
            self._link_sentence(meta, target.id)
            # 认出旧字 = 这条路又走了一次。用得越勤，这颗星越钉在原位。
            self._stiffen(target, 4.0)
            self.stats["thoughts"] += 1
            return {
                "event": "recall",
                "node_id": target.id,
                "salience": round(sal, 3),
                "thought": thought,
                "meta": meta or {},
            }

    # =====================================================================
    # 观测接口（给 aha_server.py 用，JSON 友好）
    # =====================================================================

    # =====================================================================
    # G 模块：发声器官（输出口）
    # =====================================================================

    @staticmethod
    def _label(node):
        """G 模块念到一个节点时怎么称呼它：认识字就叫字，不认识就叫节点号。"""
        if node is None:
            return "什么都没有"
        if getattr(node, "glyph", None):
            return "「%s」" % node.glyph
        return "节点%d" % node.id

    _MURMUR_TEMPLATES = {
        "muse": [
            "呓语：那个{c2}的星星（节点{b}）和{c1}的星星（节点{a}）好像连着。",
            "呓语：{c1}的星星（节点{a}）轻轻碰了一下{c2}的星星（节点{b}），它们连上了。",
            "呓语：{c2}的光（节点{b}）伸过来，搭在{c1}的星星（节点{a}）上面。",
            "呓语：我好像在哪里同时见过{c1}和{c2}……对，就是节点{a}和节点{b}。",
        ],
        "novel_link": [
            "呓语：有个东西我认不出来。它让我想起{c1}的星星（节点{a}），还牵上了{c2}的星星（节点{b}）。",
            "呓语：陌生的光，可它还是跟{c1}的星星（节点{a}）连上了，那边是{c2}（节点{b}）。",
        ],
        "birth": [
            "呓语：又长出一颗{ncolor}的星星（节点{n}），我还叫不出它的名字。",
            "呓语：这里刚刚裂开一点，掉下来一颗{ncolor}的星星（节点{n}）。",
        ],
        # 学会认字之后：说话里要带上具体的字（用户要求 4）
        "glyph_birth": [
            "呓语：这个字是{glyph}。我还不知道它是什么，先把它收进星云里。",
            "呓语：新字，{glyph}。{ncolor}的一点光，落在节点{n}上。",
        ],
        "lexicon": [
            "呓语：我发现{ga}和{gb}这两个东西，长得有点像。它们挨在一起了。",
            "呓语：{ga}和{gb}是同一种颜色的——我把它们连起来了。",
            "呓语：又碰到{ga}了。旁边站着{gb}，它们本来就是一家的吧。",
        ],
        # 两个字的百科全书标签都在 —— 这时不能只说"长得像"，要把意思念出来。
        # 用户给的范例：我发现「江」和「河」这两个特征向量很近，它们都有水。
        "lexicon_same": [
            "呓语：{ga}和{gb}，百科书都说它们是{ma}。难怪长得像。",
            "呓语：又一个{ma}。{ga}旁边站着{gb}，它们是一伙的。",
            "呓语：{ga}是{ma}，{gb}也是。我把它们拴在一起了。",
        ],
        "lexicon_sem": [
            "呓语：{ga}是{ma}，{gb}是{mb}。我把它们放在一起，好像摸到一点门道。",
            "呓语：一个是{ma}，一个是{mb}。{ga}和{gb}，我大概知道它们不是一回事。",
            "呓语：百科书说{ga}是{ma}。那{gb}（{mb}）呢……它们还是贴上了。",
        ],
        "anchor": [
            "呓语：{ncolor}的星星（节点{n}）亮了一下，又暗下去了。",
        ],
        # 海马体回放（V4.0 Phase 1-D）：睡着时旧情景重新亮一遍。
        "replay": [
            "呓语：刚才那句话又回来了。{ga} 站在最前面。",
            "呓语：睡着的时候，「{ga}」自己亮了一遍。",
            "呓语：我在重放一句话。里面有 {ga}。",
        ],
        # 受体脱敏（V4.0 Phase 1-D）：她不是坏了，只是烦了。
        "desens": [
            "呓语：又是这个声音。耳朵先关一会儿。",
            "呓语：它在门口，但我不想开门。",
            "呓语：（把耳朵捂住了，等它自己走）",
        ],
        # 黑箱里的碰撞（V4.0 Phase 1-C）。用户要的「灵感涌现」就是这四条，
        # 不出现任何"我想到了"之类的人话，只有两个光点撞在一起这件事本身。
        "insight": [
            "呓语：{ga}和{gb}在暗处撞在一起了。它们原来是同一种东西。",
            "呓语：刚从最深处浮上来两个光点，{ga}和{gb}。撞了一下，都没碎。",
            "呓语：黑箱里很挤。{ga}擦过{gb}，我听见一声很轻的响。",
            "呓语：{ga}沉下来的时候压到{gb}了。它们现在挨着。",
        ],
        "lonely": [
            "呓语：四周很安静，没有人碰我。",
            "呓语：……",
        ],
        # G 模块 + 真理标定器：对外部反馈的发声
        "reassure": [
            "呓语：原来那个是{label}啊……我记住了。",
            "呓语：{label}。这个词刚刚被她按在我身上，是暖的。",
            "呓语：她说这是{label}，那就先这样吧，我信她。",
        ],
        "threat": [
            "呓语：{label}……不对。我刚才那样想，是错的。",
            "呓语：她说不该连在一起。胸口这里空了一小块。",
            "呓语：{label}。这两个字有点冷。",
        ],
    }

    # ---- 说话的欲望（m03124）----

    def _talk_mood(self):
        """当前处在五档里的哪一档。传入越界一律夹回来，绝不让参数把它弄崩。"""
        try:
            idx = int(round(float(getattr(self, "talk_mood", 2))))
        except (TypeError, ValueError):
            idx = 2
        idx = max(0, min(len(TALK_MOODS) - 1, idx))
        return TALK_MOODS[idx]

    def _entropy_now(self):
        """星云的三维分布熵（bits）。

        每轴按自身跨度切格 —— 不用绝对坐标系，因为整张图会平移、会随输入
        扩张；用自身 min/max 归一之后，熵只对"形状"敏感：聚成一坨就低，
        摊成一片就高。
        """
        nodes = list(self.nodes.values())
        n = len(nodes)
        if n < 4:
            return 0.0
        g = max(2, int(self.entropy_buckets))
        bounds = []
        for i in range(3):
            axis = [nd.pos[i] for nd in nodes]
            lo = min(axis)
            hi = max(axis)
            bounds.append((lo, (hi - lo) or 1.0))
        buckets = {}
        for nd in nodes:
            cell = 0
            for i in range(3):
                lo, span = bounds[i]
                c = int((nd.pos[i] - lo) / span * g)
                if c < 0:
                    c = 0
                elif c >= g:
                    c = g - 1
                cell = cell * g + c
            buckets[cell] = buckets.get(cell, 0) + 1
        h = 0.0
        for c in buckets.values():
            p = c / float(n)
            h -= p * math.log(p, 2)
        return round(h, 4)

    def _update_desire(self, dt, now):
        """把体内发生的事换算成"想说话"的冲动。

        涨的三条路：自发 Aha（自己顶到阈值放的电）、梦里连出新线、
        星云信息熵显著跳变。跌的两条路：真的说出口（在 speak 里清零）、
        一直没有新事件就缓慢回落。
        """
        mood = self._talk_mood()
        gain = float(mood["gain"])

        # 1) 自发 Aha：背景电活动自己顶出来的放电
        seen = int(self.stats.get("self_aha", 0))
        d_aha = max(0, seen - int(self._last_self_aha_seen))
        self._last_self_aha_seen = seen
        if d_aha:
            # 限速而不是限总量：性格（档位 gain）决定每秒能涨多少，
            # 星云规模不再决定她有多话痨。
            cap = self.desire_rate_cap * gain * max(dt, 1e-4)
            self.speech_desire += min(cap, d_aha * self.desire_per_aha * gain)

        # 2) 梦里连出来的新线："我做了个梦，梦见它们连上了"
        dl = int(self.dream_links)
        d_link = max(0, dl - int(self._last_dream_link_seen))
        self._last_dream_link_seen = dl
        if d_link:
            cap = self.desire_rate_cap * gain * max(dt, 1e-4)
            self.speech_desire += min(cap, d_link * self.desire_per_dream_link * gain)

        # 3) 星云信息熵跳变（每秒算一次，不能 10Hz 遍历全网）
        if now - self._last_entropy_t >= self.entropy_interval:
            self._last_entropy_t = now
            h = self._entropy_now()
            self.entropy_now = h
            prev = self._last_entropy
            self._last_entropy = h
            if prev is not None:
                jump = abs(h - prev)
                if jump >= self.entropy_jump:
                    self.entropy_jump_last = round(jump, 4)
                    self.speech_desire += min(20.0, jump * self.entropy_gain * gain)

        # 4) 一直没有新东西 -> 慢慢不想说了
        if self.speech_desire > 0.0:
            self.speech_desire = max(
                0.0, self.speech_desire - self.desire_decay * float(mood["decay"]) * dt)

        # 5) 憋不住就开口。睡着时不开口，但欲望留着 —— 醒来第一句
        #    往往就是她主动找他。
        if self.speech_desire >= float(mood["thr"]):
            self.speech_desire = min(self.desire_cap, self.speech_desire)
            if (not self.sleeping and not self.paused
                    and (now - self._last_proactive_t) >= float(mood["gap"])):
                self._last_proactive_t = now
                try:
                    self.compose_proactive(now)
                except Exception:
                    self.speech_desire = 0.0
        return round(self.speech_desire, 2)

    def compose_proactive(self, now=None):
        """她主动找你搭话 —— 依然只用节点和连线，不经过任何大模型。"""
        now = time.time() if now is None else float(now)
        with self._lock:
            pool = [n for n in self.nodes.values() if getattr(n, "glyph", "")]
            if not pool:
                text = u"？"
                self.last_thought = text
                self.speak(text=text, kind="proactive", ids=[])
                return text
            # 偏爱"刚亮过"的星：她主动开口时，多半是刚才心里正想着它
            recent = [n for n in pool if (now - n.last_fired_time) < 90.0]
            # 杏仁核：带危险标签的节点被抽到的概率翻倍（2.0 vs 1.0）。
            # 然后基底节门控：一次抽取 8 个候选，只放行 Top-1 去说话。
            # （compose_reply 不走这道门 —— 被问到哪个字是语义硬约束，
            #   基底节没资格否决她回答你问的东西。）
            cands = []
            for _i in range(8):
                if recent and random.random() < 0.65:
                    _p = self._amygdala_pick(recent) or random.choice(recent)
                else:
                    _p = self._amygdala_pick(pool) or random.choice(pool)
                cands.append((random.uniform(0.0, 10.0), _p))
            topic = self._basal_gate(cands) or cands[0][1]
            nbrs = self._neighbors_of(topic.id, limit=2, kinds=("char",))
            # 用户 m03667：主动开口也一样，只给那条边。想说话是欲望的事，
            # 说出来是什么，交给图决定。
            text = self._chain(topic, nbrs)
            self.last_thought = text
            ids = [topic.id] + [nb.id for _w, nb in nbrs]
            self.speak(text=text, kind="proactive", ids=ids)
            return text

    def speak(self, text=None, kind="muse", ids=None, **fmt):
        """G 模块 —— 小鱼的输出口。

        参数
        ----
        text : 直接给定一句话；为 None 时按 kind 从模板里挑一句并填充 fmt
        kind : muse / novel_link / birth / anchor / lonely
        ids  : 这句话涉及的节点 id 列表（前端点日志可高亮对应星星）

        返回写入日志的那条 entry（含自增 seq，WebSocket 靠它做增量推送）。

        注意：本方法**不 print**。打印由 aha_server.life_loop 在引擎锁外调用
        drain_speech() 完成 —— 缓慢的 stdout（管道写满、控制台卡住）绝不能
        占着引擎锁，否则 10Hz 的 tick 和 WebSocket 会一起被拖死。
        """
        with self._lock:
            if text is None:
                pool = self._MURMUR_TEMPLATES.get(kind) or self._MURMUR_TEMPLATES["muse"]
                tpl = random.choice(pool)
                try:
                    text = tpl.format(**fmt)
                except (KeyError, IndexError, ValueError):
                    text = "呓语：%s" % tpl
            text = str(text)
            self.speech_seq += 1
            entry = {
                "seq": self.speech_seq,
                "t": round(time.time(), 3),
                "kind": str(kind),
                "ids": [int(i) for i in (ids or [])],
                "text": text,
            }
            self.speech_log.append(entry)
            self.last_speech = entry
            self._speech_out.append(text)
            # --- 真的开口了：欲望清零 + 注入长效多巴胺（用户 m03124）---
            # 只认 say / proactive。glyph_birth、birth 那些是体内的记账，
            # 要算成"说过话"的话，她每学一个字就爽一次，欲望永远涨不起来。
            if str(kind) in ("say", "proactive"):
                self.speech_desire = 0.0
                mood = self._talk_mood()
                self.tonic_dopamine = min(
                    self.dopamine_cap,
                    self.tonic_dopamine + self.dopamine_gain * mood["dopa"])
                if str(kind) == "say":
                    self.stats["say_reply"] = self.stats.get("say_reply", 0) + 1
                else:
                    self.stats["say_proactive"] = self.stats.get("say_proactive", 0) + 1
                    self.last_proactive = text
            return dict(entry)

    def drain_speech(self):
        """取走尚未打印的呓语。锁内只做一次 list 拷贝，立刻释放。"""
        with self._lock:
            out = list(self._speech_out)
            self._speech_out.clear()
        return out

    def recent_speech(self, after=0, limit=80):
        """取 seq > after 的呓语。页面刷新 / WebSocket 重连时补齐历史用。"""
        try:
            after = int(after)
        except (TypeError, ValueError):
            after = 0
        with self._lock:
            items = [dict(e) for e in list(self.speech_log) if e["seq"] > after]
        limit = int(limit or 0)
        return items[-limit:] if limit > 0 else items

    def speech_about(self, node_id, limit=1):
        """这颗星星最近被说起过什么。悬停档案卡用 —— 不只是 ID 和活跃度。"""
        try:
            node_id = int(node_id)
        except (TypeError, ValueError):
            return []
        limit = max(1, int(limit or 1))
        with self._lock:
            out = []
            for e in reversed(self.speech_log):
                ids = e.get("ids") or []
                if node_id in ids:
                    out.append(dict(e))
                    if len(out) >= limit:
                        break
        return out

    # =====================================================================
    # 认知状态深度报告（前端面板的"隐性状态"）
    # =====================================================================

    # =====================================================================
    # 说话：完全由内部图网络拼句子（不经任何大模型）
    # =====================================================================
    #
    # 用户 m02206 的硬约束：大模型只负责"查字典盖章 / 返回标签"，绝不替她开口。
    # 所以下面这一整段没有一次网络请求 —— 只有节点检索、连线遍历、模板拼接。

    # 判断"问句里是不是原样出现了她学过的某一句"时要去掉的符号。
    # 只去标点，不去字 —— 少一个字就不是同一句了。
    _PUNCT = set(u"，。！？、；：,.!?;: \t\r\n\u201c\u201d\u2018\u2019\u300c\u300d\u300a\u300b\uff08\uff09()")

    # 疑问词整词表。它们永远不是"被问到的那个东西"：
    # 问「我是什么」，被问的是「我」，不是「什么」。
    # 单字过滤不行（「时」「里」「样」都是常用字），所以整词替换成空格再切。
    _QWORDS = (u"什么样", u"为什么", u"干什么", u"什么", u"怎么", u"怎样", u"咋样",
               u"为何", u"哪里", u"哪儿", u"哪些", u"哪个", u"是谁", u"多少", u"几个")

    _WEAK_CHARS = set(
        "你我他她它的一了是吗呢吧啊呀哦嗯在有不就都也很还和与跟这那么些个们"
        "请谁哪怎样问说道想知告诉点把被让给对从向只再又才已经过着得地"
        "认识觉得看听写念读记找叫懂会爱要能该比像成做作用"
    )

    @staticmethod
    def _plain(node):
        """节点的"人话"名字：句 / 段是它自己的原文，字是那个字。"""
        if node is None:
            return "什么"
        # 用户 m03927：句节点和段节点没有 glyph，它们本身就是一串字。
        kind = getattr(node, "kind", "char") or "char"
        if kind != "char":
            t = getattr(node, "text", "") or ""
            if t:
                return t[:16]
        g = getattr(node, "glyph", "") or ""
        if g:
            return g
        m = getattr(node, "meaning", "") or ""
        if m:
            return m[:8]
        # 文字模式下没有 glyph 的老节点：她真的不知道那是什么，
        # 说"节点6"是人话里的编号感，换成一个她自己的说法（用户 m02583 第一条）。
        return u"一个还没名字的光点"

    def _chain(self, topic, nbrs):
        """她认知的原文：主角 → 邻居。

        用户 m03667：「只给原始节点链」。所以这里不出现人名、动词、引号、句号 ——
        只有从图里取出来的东西本身。没有邻居就只给主角一个词。
        """
        tname = self._plain(topic)
        names = [self._plain(nb) for _w, nb in (nbrs or [])]
        if not names:
            return tname
        return tname + u" → " + u"、".join(names)

    def _glyph_index(self):
        """汉字 -> 节点列表。同一字可能因为有多个记忆而对应多个节点。

        V4.0：只收 kind=="char" 的字节点。句子 / 段落 / 概念节点也可能带 glyph
        （比如词「江水」），但它们不是「一个字」，不该被当成字去检索。
        """
        idx = {}
        for n in self.nodes.values():
            # temp 是工作记忆里的临时词：她正在想它，所以也得查得到。
            if (getattr(n, "kind", "char") or "char") not in ("char", "temp"):
                continue
            g = getattr(n, "glyph", "") or ""
            if g:
                idx.setdefault(g, []).append(n)
        return idx

    def _degree(self, nid):
        d = 0
        for (a, b) in self.connections:
            if a == nid or b == nid:
                d += 1
        return d

    def _sentence_hits(self, text):
        """问句里原样出现了她学过的某一句？那就想起那一句（用户 m03927）。

        只认「整句原文」，不做模糊匹配 —— 问一个字是字层的事，不该拿整句来答。
        多条命中取最长的一句：问得越具体，答得越具体。
        """
        if not text or not self._sentence_index:
            return None
        plain = "".join(ch for ch in str(text) if ch not in self._PUNCT)
        if len(plain) < 4:
            return None
        best, best_len = None, 0
        for sent_text, nid in list(self._sentence_index.items()):
            node = self.nodes.get(nid)
            if node is None or (getattr(node, "kind", "") or "") != "sentence":
                continue
            key = "".join(ch for ch in str(sent_text) if ch not in self._PUNCT)
            if len(key) < 4:
                continue
            # 两个方向都算：
            #   问句里原样出现了整句      ——「我爱我家是什么意思」里的「我爱我家」
            #   问的就是这一句的一部分    ——「爸爸妈妈爱我」是整句的前半
            # 谁短谁才是被问到的那个范围，所以匹配长度取两者中较短的那一边。
            if key in plain:
                hit_len = len(key)
            elif len(plain) >= 4 and plain in key:
                hit_len = len(plain)
            else:
                continue
            if hit_len <= best_len:
                continue
            best, best_len = node, hit_len
        return best

    def _cjk_hits(self, text):
        """一句话里她真认得的字/词，按出现位置排序返回 [(pos, glyph, node)]。"""
        idx = self._glyph_index()
        if not idx:
            return []
        text = str(text or "")
        best = {}
        # 先长后短：认识"长江"的时候不要被"江"抢了位置
        for g in sorted(idx.keys(), key=lambda t: (-len(t), t)):
            pos = text.find(g)
            if pos < 0:
                continue
            for n in idx[g]:
                cur = best.get(n.id)
                if cur is None or pos < cur[0]:
                    best[n.id] = (pos, g, n)
        hits = list(best.values())
        hits.sort(key=lambda t: (t[0], -len(t[1])))
        return hits

    def _target_spans(self, text):
        """把问句切成"实词片段"，跳过虚词/代词/动词。

        「你认识氦吗」-> ["氦"]；「你认识长江吗」-> ["长江"]。
        这是纯规则切分，没有任何分词模型 —— 只靠一张虚词表。
        """
        raw = str(text or "")
        # 疑问词先换成全角空格（不是汉字，天然成为片段分隔符）
        for q in self._QWORDS:
            raw = raw.replace(q, u"　")
        out, cur, start = [], [], 0
        for i, ch in enumerate(raw):
            if ("\u4e00" <= ch <= "\u9fff") and (ch not in self._WEAK_CHARS):
                if not cur:
                    start = i
                cur.append(ch)
            else:
                if cur:
                    out.append((start, "".join(cur)))
                    cur = []
        if cur:
            out.append((start, "".join(cur)))
        return out

    def _topic_score(self, pos, glyph, node):
        """谁才是"被问到的主角"：认得的东西多、位置靠前、且不是虚词。

        实测"你认识江吗"里"你/认/识/吗"都可能命中，如果不降权，
        主角会被"你"抢走，答出来就是"你问到了「你」"。
        """
        deg = self._degree(node.id)
        weak = 30.0 if glyph in self._WEAK_CHARS else 0.0
        return deg * 12.0 + len(glyph) * 6.0 - pos * 0.8 - weak

    def _neighbors_of(self, nid, limit=3, kinds=None):
        """顺着连线找她的"联想"：按权重从高到低。

        kinds 只留这些层的邻居（用户 m03927）。问一个字时只要别的字 ——
        句节点的边权 2.5 远高于同句字之间的 1.2，一放开就会把
        "江 → 江水往东流" 答成一句话，问她字却答出整句。
        """
        pairs = []
        for i, (a, b) in enumerate(self.connections):
            if a == nid:
                pairs.append((self._conn_weight[i], b))
            elif b == nid:
                pairs.append((self._conn_weight[i], a))
        if kinds is not None:
            ks = tuple(kinds)
            pairs = [p for p in pairs
                     if (getattr(self.nodes.get(p[1]), "kind", "char") or "char") in ks]
        # 有字的邻居排在前面（她答得出"它连着「河」"比"它连着节点6"像人话），
        # 同一档里再按连线权重从高到低。
        pairs.sort(key=lambda t: (0 if (getattr(self.nodes.get(t[1]), "glyph", "") or "")
                                  else 1, -t[0]))
        out, seen = [], set()
        for w, oid in pairs:
            if oid in seen:
                continue
            node = self.nodes.get(oid)
            if node is None or node.id == nid:
                continue
            seen.add(oid)
            out.append((w, node))
            if len(out) >= max(1, int(limit)):
                break
        return out

    def _tone_prefix(self, unresolved=False):
        """纯规则的语气修饰（用户 m02583 第一条：去掉一切括号包装）。

        m02206 定的两条还在：疲劳高 -> 困倦；查不到 / 有危机 -> 焦虑。
        但**不再返回 [方括号]**，也不再拼进 reply —— 一个活物说话不会
        自带标签。这里只返回"困倦"、"焦虑"、"困倦、焦虑"或空串，
        由调用方决定怎么用；compose_reply 只把它塞进 tone 字段。
        """
        tags = []
        if self.fatigue >= 55.0:
            tags.append(u"困倦")
        if unresolved or self.threat_level >= 4.0:
            tags.append(u"焦虑")
        return u"、".join(tags)

    def _guess_unknown(self, text):
        """问句里她没学过、最可能"被问到"的那个字（查字典用，一次只补一个）。

        一次只挑一个：一句生词连发会瞬间烧掉一串 API 额度。
        """
        idx = self._glyph_index()
        for ch in str(text or ""):
            if not ("\u4e00" <= ch <= "\u9fff"):
                continue
            if ch in self._WEAK_CHARS:
                continue
            if any(ch in g for g in idx):
                continue
            return ch
        return None

    def compose_reply(self, text, now=None):
        """小鱼亲口回答一句话。**全程不调用任何大模型。**

        完全对标用户 m02206：
          1) 把她认得的字映射成节点；
          2) A2/E 顺着这些节点在图里找连线；
          3) 找到就拼「你问到了 X，我记得它连着 Y，还连着 Z」；
          4) 一个都不认识就「我不认识这个词，我的星云里没有它的光」；
          5) 认得但没连线就「我看到了 X，但它孤零零的……」；
          6) 语气（困倦/焦虑）只进 tone 字段，**绝不拼进 reply**。

        返回 dict：reply / tone / matched / topic / topic_id / neighbors /
                   ids / unknown_glyph
        """
        now = time.time() if now is None else float(now)
        text = str(text or "").strip()[:500]
        with self._lock:
            hits = self._cjk_hits(text)
            fired_ids = []

            # --- 第一件事：她学过这一整句吗（用户 m03927）---
            # 学过的话，该答的是"这句话由哪些字组成" —— 层与层之间是
            # 句节点连向字节点的那 2.5 权重的边，不是什么语义分析。
            sent = self._sentence_hits(text)
            if sent is not None:
                sec = self._neighbors_of(sent.id, limit=4, kinds=("char",))
                for _w, nb in sec:
                    nb.activation += 6.0
                    fired_ids.append(nb.id)
                reply = self._chain(sent, sec)
                tone = self._tone_prefix(False)
                try:
                    self.speak(text=reply, kind="say", ids=fired_ids)
                except Exception:
                    pass
                self.last_thought = reply
                return {
                    "ok": True, "reply": reply, "tone": tone, "level": "sentence",
                    "matched": [g for pos, g, n in hits],
                    "topic": self._plain(sent), "topic_id": sent.id,
                    "neighbors": [nb.id for _w, nb in sec],
                    "ids": fired_ids, "unknown_glyph": None,
                }

            # --- 先看"被问到的那个东西"她到底认不认识 ---
            # 用户 m02206 是按"这个字在不在"判断，不是按"整句有没有一个字认识"。
            # 实测「你认识氦吗」里"你/认/识"她都学过，按整句判断就不会迷茫，
            # 反而答「你问到了「认」」—— 完全答非所问。
            spans = self._target_spans(text)
            target_word = ""
            if spans:
                target_word = sorted(spans, key=lambda t: -len(t[1]))[0][1]
            idx_all = self._glyph_index()
            # 用户 m03927：「我爱我家是什么意思」的实词片段是 ["家","意思"]，
            # 只查最长的那个会因为她没学过"意思"就整句迷茫 —— 可她明明认得"家"。
            # 改成所有片段里有一个认得的字就不算迷茫；该答谁交给度数决定。
            known_in_target = [g for g in idx_all
                               if g and any(g in sp for _p, sp in spans)]

            if target_word and not known_in_target:
                tone = self._tone_prefix(unresolved=True)
                # 用户 m03667：不认识就承认她没有 —— 星云里没有那条边，就只有「？」
                reply = u"？"
                try:
                    self.speak(text=reply, kind="say")
                except Exception:
                    pass
                self.last_thought = reply
                return {
                    "ok": True, "reply": reply, "tone": tone,
                    "matched": [], "topic": None, "topic_id": None,
                    "neighbors": [], "ids": [], "unknown_glyph": target_word[:1],
                }

            # --- 整句连一个实词都没有：迷茫 ---
            if not hits:
                tone = self._tone_prefix(unresolved=True)
                reply = u"？"
                unknown = self._guess_unknown(text)
                try:
                    self.speak(text=reply, kind="say")
                except Exception:
                    pass
                self.last_thought = reply
                return {
                    "ok": True, "reply": reply, "tone": tone,
                    "matched": [], "topic": None, "topic_id": None,
                    "neighbors": [], "ids": [], "unknown_glyph": unknown,
                }

            # --- 选主角 ---
            # 宾语优先是**硬优先级**，不是加分。用户问「你认识鹑吗」，被问的
            # 对象是「鹑」，不可能是「你」。固定 +500 会被高频字的度数压回去：
            # 实测「你」deg=47 → 47*12-30 = 534 分，刚学会的「鹑」deg=3 →
            # 3*12+6-2.4+500 = 539.6，只差 0.4；度数再高一点就直接反超，于是
            # 答成「你 → 低、风、写」（chat_e2e 的 [C]/[D] 两组失败真因）。
            # 所以先只在宾语命中里挑，一个都没命中才退到整句全量。
            in_target = [h for h in hits
                         if h[1] and any(h[1] in sp for _p, sp in spans)]
            pool = in_target or hits
            best = None
            for pos, g, n in pool:
                sc = self._topic_score(pos, g, n)
                if best is None or sc > best[0]:
                    best = (sc, pos, g, n)
            topic = best[3]

            # --- A2/E：点亮被问到的字，再顺着连线带亮邻居 ---
            for pos, g, n in hits[:5]:
                n.activation += 12.0
                try:
                    n.try_activate(now, 0.0)
                except Exception:
                    pass
                fired_ids.append(n.id)
            nbrs = self._neighbors_of(topic.id, limit=3, kinds=("char",))
            for w, nb in nbrs:
                nb.activation += 6.0
                fired_ids.append(nb.id)

            # --- 原文：不是句子，是图里那条边（用户 m03667）---
            tname = self._plain(topic)
            reply = self._chain(topic, nbrs)
            if not nbrs:
                # 认字但还没盖过章 -> 才值得去查字典；已盖章的不重复花额度
                unknown = tname[:1] if not (getattr(topic, "meaning", "") or "") else None
            else:
                unknown = None

            tone = self._tone_prefix(False)   # 语气只进字段，不进她的输出
            try:
                self.speak(text=reply, kind="say", ids=fired_ids)
            except Exception:
                pass
            self.last_thought = reply
            return {
                "ok": True, "reply": reply, "tone": tone,
                "matched": [g for pos, g, n in hits],
                "topic": tname, "topic_id": topic.id,
                "neighbors": [self._plain(nb) for w, nb in nbrs],
                "ids": fired_ids, "unknown_glyph": unknown,
            }

    def cognitive_report(self):
        """把看不见的隐性状态算成数字：安全感 / 好奇心焦虑 / 平均膜电位。

        全部由**现有动力学推导**，不新增任何状态变量，也不改变本体行为：
          安全感 = E-I 相对 105:100 基线的倍数 x 输入新鲜度 x 教导可信度
          好奇心 = 未归类节点（从未放电且无突触）+ 被甩在外围的边缘节点占比
          平均膜电位 = 全网 activation 均值（"她是不是在持续发高烧"）
        """
        now = time.time()
        with self._lock:
            nodes = list(self.nodes.values())
            n = len(nodes)
            if n == 0:
                return {
                    "safety": 0.0, "safety_label": "空白", "curiosity": 0.0,
                    "curiosity_label": "空白", "mean_activation": 0.0,
                    "max_activation": 0.0, "activity_ratio": 0.0,
                    "unknown_nodes": 0, "orphans": 0, "edge_nodes": 0,
                    "stale_nodes": 0, "fresh_nodes": 0,
                    "unknown_ratio": 0.0, "safety_gap": 0.0, "safety_idle": 0.0,
                    "safety_teach": 0, "nodes": 0, "t": round(now, 2),
                }

            mean_act = sum(x.activation for x in nodes) / n
            max_act = max(x.activation for x in nodes)
            live = sum(1 for x in nodes if x.activation >= 1.0)

            # --- 安全感：E - I 的差值，相对安全感基线(105-100=5)放大 ---
            # gap=5（刚好在基线上）→ 0.5；gap=10（像现在）→ 0.93；gap<=0 → 0。
            gap = float(self.tone_excitation) - float(self.tone_inhibition)
            base_gap = max(1e-6, float(self.target_safety) - float(self.tonic_inhibition))
            ratio = gap / base_gap
            s_gap = _clamp(ratio / (1.0 + abs(ratio)) * 1.4, 0.0, 1.0)

            # 长时间没有输入 → 安全感自然下滑（H 模块没了可抓的东西）
            idle = max(0.0, now - float(getattr(self, "last_input_time", self.birth)))
            fresh = 1.0 if idle <= 15.0 else _clamp(1.0 - (idle - 15.0) / 240.0, 0.0, 1.0)
            # "是否被打了标签"：教导越多、越是被**判对**过的，她的世界越有名字。
            # [+安全] 权重拉满，未标定的旧计数只算四成 —— 错的东西别拿来撑安全感。
            safe_n = float(self.stats.get("teach_safe", 0))
            all_n = float(self.stats.get("teach", 0))
            conf = _clamp((safe_n + 0.4 * all_n) / 20.0, 0.0, 1.0)

            safety = 100.0 * _clamp(0.60 * s_gap + 0.25 * fresh + 0.15 * conf, 0.0, 1.0)
            if safety >= 75.0:
                s_label = "安心"
            elif safety >= 50.0:
                s_label = "平稳"
            elif safety >= 28.0:
                s_label = "警觉"
            else:
                s_label = "恐慌"

            # --- 好奇心 / 焦虑：未归类的、散在边缘的节点 ---
            deg = {}
            for a, b in self.connections:
                deg[a] = deg.get(a, 0) + 1
                deg[b] = deg.get(b, 0) + 1

            cx = sum(x.pos[0] for x in nodes) / n
            cy = sum(x.pos[1] for x in nodes) / n
            cz = sum(x.pos[2] for x in nodes) / n
            dists = [math.sqrt((x.pos[0] - cx) ** 2 + (x.pos[1] - cy) ** 2 +
                               (x.pos[2] - cz) ** 2) for x in nodes]
            med = statistics.median(dists) if dists else 0.0

            orphans = 0    # 从未放电 —— 完全没被归类
            edge = 0       # 有枝干但很弱，且被甩在外围
            stale = 0      # 曾经认识，但很久没被想起（记忆褪色）
            fresh_new = 0  # 刚出生，还没被理解
            for x, dist in zip(nodes, dists):
                d = deg.get(x.id, 0)
                # "未归类" = 这颗星星还从没参与过任何一次联想（fire_count 为 0）。
                # 出生时虽然挂了父枝干，但对小鱼来说它依然是无名的 —— 只有被点亮过才算认识。
                if x.fire_count <= 0:
                    orphans += 1
                else:
                    if float(now - getattr(x, "last_fired_time", 0.0)) > 120.0:
                        stale += 1
                    if d <= 1 and med > 1e-6 and dist > 1.5 * med:
                        edge += 1
                if float(now - getattr(x, "created_at", now)) < 30.0:
                    fresh_new += 1

            unknown = orphans + 0.35 * stale + 0.5 * edge + 0.8 * fresh_new
            # 多个因子会命中同一颗星（刚出生 + 还没放电），加权后可能越过节点总数
            unknown_ratio = _clamp(unknown / n, 0.0, 1.0)
            novel_now = 1.0 if (self.last_think_meta or {}).get("novel") else 0.0
            curiosity = 100.0 * _clamp(unknown_ratio * 1.35 + 0.04 * novel_now, 0.0, 1.0)
            if curiosity >= 70.0:
                c_label = "强烈好奇"
            elif curiosity >= 45.0:
                c_label = "好奇"
            elif curiosity >= 22.0:
                c_label = "偏静"
            else:
                c_label = "几乎无未知"

            return {
                "safety": round(safety, 1),
                "safety_label": s_label,
                "safety_gap": round(gap, 2),
                "safety_idle": round(idle, 1),
                "safety_teach": int(self.stats.get("teach", 0)),
                "teach_safe": int(self.stats.get("teach_safe", 0)),
                "teach_crisis": int(self.stats.get("teach_crisis", 0)),
                "threat_level": round(float(self.threat_level), 2),
                "curiosity": round(curiosity, 1),
                "curiosity_label": c_label,
                "unknown_nodes": int(min(n, round(unknown))),
                "orphans": orphans,
                "edge_nodes": edge,
                "stale_nodes": stale,
                "fresh_nodes": fresh_new,
                "unknown_ratio": round(unknown_ratio, 3),
                "mean_activation": round(mean_act, 2),
                "max_activation": round(max_act, 1),
                "activity_ratio": round(live / float(n), 3),
                "nodes": n,
                "t": round(now, 2),
            }

    def physiology(self):
        with self._lock:
            mood = self._talk_mood()
            return {
                "excitation": round(self.tone_excitation, 2),
                "inhibition": round(self.tone_inhibition, 2),
                "fatigue": round(self.fatigue, 2),
                "threat_level": round(self.threat_level, 2),
                "target": self.target_safety,
                "tonic": self.tonic_inhibition,
                "raw_excitation": round(self.global_excitation, 2),
                "raw_inhibition": round(self.global_inhibition, 2),
                "pressure": round(self.pressure, 4),
                "overload_line": round(self.overload_line, 1),
                "paused": bool(self.paused),
                "sleeping": bool(self.sleeping),
                "sleep_reason": self.sleep_reason,
                "sleep_seconds": round(self.sleep_seconds, 1),
                "aha_rate": self.aha_rate,
                "aha_window_count": len(self.aha_times),
                "prune_total": self.prune_total,
                "prune_last": self.prune_last,
                "bg_noise": round(float(self.bg_noise), 4),
                "bg_drift": round(float(self.bg_drift), 3),
                # 背景电活动的账本：前端"电位爬升 / 自发放电"的数据源
                "spike_hz": round(float(self.spike_hz), 2),
                "spike_cover": round(float(self.spike_cover), 4),
                "spike_total": int(self.spike_total),
                "spike_fires": int(self.spike_fires),
                "self_aha": int(self.stats.get("self_aha", 0)),
                "dream_spike_rate": round(float(self.dream_spike_rate), 2),
                "dream_spike_fires": int(self.dream_spike_fires),
                "dream_total": int(self.dream_total),
                "dream_rate": round(float(self.dream_rate), 3),
                "last_dream": self.last_dream,
                "params": {
                    k: round(float(getattr(self, k, spec["default"])), 4)
                    for k, spec in self.PARAM_SPECS.items()
                },
                "think": dict(self.last_think_meta),
                "nodes": len(self.nodes),
                "glyphs": sum(1 for n in self.nodes.values() if n.glyph),
                "sentences": sum(1 for n in self.nodes.values()
                                 if (getattr(n, "kind", "") or "") == "sentence"),
                "paragraphs": sum(1 for n in self.nodes.values()
                                  if (getattr(n, "kind", "") or "") == "paragraph"),
                "connections": len(self.connections),
                "thoughts": self.stats["thoughts"],
                "aha": self.stats["aha"],
                "inputs": self.stats["inputs"],
                "uptime": round(time.time() - self.birth, 1),
                "mean_activation": round(
                    (sum(n.activation for n in self.nodes.values()) / len(self.nodes))
                    if self.nodes else 0.0, 2),
                "speech_seq": self.speech_seq,
                # 说话的欲望（m03124）
                "speech_desire": round(self.speech_desire, 1),
                "desire_threshold": float(mood["thr"]),
                "talk_mood": int(round(float(self.talk_mood))),
                "talk_mood_name": mood["name"],
                "tonic_dopamine": round(self.tonic_dopamine, 2),
                "entropy": round(float(self.entropy_now), 3),
                "entropy_jump": round(float(self.entropy_jump_last), 4),
                "dream_links": int(self.dream_links),
                "say_proactive": int(self.stats.get("say_proactive", 0)),
                "say_reply": int(self.stats.get("say_reply", 0)),
                # V4.0 潜意识黑箱 + 工作记忆
                "box": self.box_snapshot(),
                # V4.0 Phase 1-D：细胞机制
                "calcium_total": int(self.calcium_total),
                # V4.0 Phase 1-D：突触延迟 + 脑区
                "syn_delay_new": round(float(self.syn_delay_new), 3),
                "syn_sent": int(self.syn_sent),
                "syn_fired": int(self.syn_fired),
                "syn_pending": len(self.syn_pending),
                "episodes": len(self.episodes),
                "replay_total": int(self.replay_total),
                "amygdala_hits": int(self.amygdala_hits),
                "basal_gate": int(self.basal_gate),
                "basal_pass": int(self.basal_pass),
                "desens_total": int(self.desens_total),
                "desens_skip": int(self.desens_skip),
                "desens_hold": round(float(self.desens_hold), 1),
                "wm": len(self._wm),
                "wm_made": int(self.wm_made),
                "wm_solid": int(self.wm_solidified),
                "insight": int(self.insight_total),
                "llm_supervise": round(float(self.llm_supervise), 2),
                "float_speed": round(float(self.float_speed), 2),
                "sup_pending": len(self.sup_queue),
                "sup_done": int(self.sup_done),
                "sup_safe": int(self.sup_safe),
                "sup_crisis": int(self.sup_crisis),
                "self_reflex": int(self.self_reflex),
                "last_self_reflex": self.last_self_reflex,
                "stiff_max": round(max([n.stiff for n in self.nodes.values()] or [0.0]), 2),
                "stiff_mean": round(
                    sum(n.stiff for n in self.nodes.values()) / max(1, len(self.nodes)), 3),
                # V4.0 Phase 4：具身躯体参数（连续量，前端据此画鱼）
                "body": self._body_locked(),
            }

    def snapshot_full(self):
        """完整状态，WebSocket 建连时的第一帧。"""
        with self._lock:
            return {
                "type": "full",
                "nodes": [
                    [n.id, round(n.pos[0], 3), round(n.pos[1], 3), round(n.pos[2], 3),
                     round(n.activation, 2), round(n.salience, 2),
                     n.glyph or "", n.meaning or "",
                     round(n.threshold, 2),      # [8] 阈电位，前端配色用
                     n.kind or "char",           # [9] 层：char / sentence / paragraph
                     n.text or ""]               # [10] 句 / 段的原文
                    for n in self.nodes.values()
                ],
                "connections": [
                    [a, b, round(w, 2)]
                    for (a, b), w in zip(self.connections, self._conn_weight)
                ],
                "physio": self.physiology(),
                # 在途的突触信号（和 frame() 同格式），建连第一帧就能画流星
                "flight": [
                    [int(src), int(dst), round(max(0.0, due - time.time()), 3), round(float(dur), 3)]
                    for due, src, dst, _amp, dur in self.syn_pending[:80]
                ],
                "thought": self.last_thought,
            }

    def frame(self, since_node_id=0, since_conn_count=0):
        """增量帧（10Hz 推送用）。

        - nodes  全量但只有 [id, activation]，用于驱动亮度
        - new_nodes / new_conns 只发增量，前端自己累积
        这样 6000 个节点也只有一百多 KB/s，本地环回毫无压力。
        """
        with self._lock:
            t_now = time.time()
            return {
                "type": "frame",
                "t": round(t_now, 3),
                "nodes": [[n.id, round(n.activation, 2)] for n in self.nodes.values()],
                "new_nodes": [
                    [n.id, round(n.pos[0], 3), round(n.pos[1], 3), round(n.pos[2], 3),
                     round(n.salience, 2), n.glyph or "",
                     round(n.threshold, 2),
                     n.kind or "char", n.text or ""]
                    for n in self.nodes.values() if n.id > since_node_id
                ],
                # 刚放完电的节点 [id, 距今多少秒]。前端据此把那一颗瞬间闪成亮粉。
                # 只推 1.2 秒内的：闪光本身只有 0.45 秒，留余量防 10Hz 帧率卡边界。
                "fired": [
                    [n.id, round(t_now - n.last_fired_time, 3)]
                    for n in self.nodes.values()
                    if 0.0 <= (t_now - n.last_fired_time) <= 1.2
                ],
                "new_conns": [
                    [a, b, round(w, 2)]
                    for (a, b), w in zip(
                        self.connections[since_conn_count:],
                        self._conn_weight[since_conn_count:],
                    )
                ],
                "conn_count": len(self.connections),
                # Phase 2 流星：在途信号 [src, dst, 还有几秒到站]。前端沿连线画飞行光点，
                # 到站时间越短越亮 —— 延迟本身就是可见的（新线 0.45s，老线 0.03s）。
                "flight": [
                    [int(src), int(dst), round(max(0.0, due - t_now), 3), round(float(dur), 3)]
                    for due, src, dst, _amp, dur in self.syn_pending[:80]
                ],
                "max_node_id": self._next_id - 1,
                "physio": self.physiology(),
                "thought": self.last_thought,
            }

    # =====================================================================
    # 持久化
    # =====================================================================

    def save_state(self, path=None):
        target = Path(path) if path else (self.memory_dir / "brain_state.json")
        target.parent.mkdir(parents=True, exist_ok=True)
        with self._lock:
            payload = {
                "version": VERSION,
                "saved_at": time.time(),
                "next_id": self._next_id,
                "nodes": [n.to_dict() for n in self.nodes.values()],
                "connections": [
                    {"a": a, "b": b, "w": round(w, 3)}
                    for (a, b), w in zip(self.connections, self._conn_weight)
                ],
                "homeostasis": {
                    "fatigue": self.fatigue,
                    "tone_excitation": self.tone_excitation,
                    "tone_inhibition": self.tone_inhibition,
                },
                "stats": dict(self.stats),
                # G 模块的发声记录也跟着存档走，否则一重启她的呓语就全丢了
                "speech": {
                    "seq": self.speech_seq,
                    "log": list(self.speech_log),
                },
            }
        tmp = target.with_suffix(target.suffix + ".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, target)     # 原子替换，断电不留半截文件
        return str(target)

    # =====================================================================
    # 造物主控制台：参数读写（前端滑块 <-> /api/params）
    # =====================================================================

    def get_params(self):
        """当前值 + 规格，前端据此生成滑块（不需要在前端硬编码范围）。"""
        with self._lock:
            out = {}
            for k, spec in self.PARAM_SPECS.items():
                item = dict(spec)
                item["value"] = round(float(getattr(self, k, spec["default"])), 4)
                out[k] = item
            return out

    def set_params(self, patch):
        """应用一批参数改动，返回实际生效的值。

        逐字段钳制到 PARAM_SPECS 范围；decay_rate / fire_reset_ratio 是节点级
        字段，必须同步到已存在的每个节点，否则老节点还按旧速率漏电。
        全程持锁 —— 主循环正在遍历 self.nodes，边写边读会脏读甚至崩掉。
        """
        applied = {}
        with self._lock:
            for key, value in (patch or {}).items():
                spec = self.PARAM_SPECS.get(key)
                if spec is None:
                    continue
                if isinstance(value, bool) or not isinstance(value, (int, float)):
                    continue
                val = _clamp(float(value), spec["min"], spec["max"])
                if key == "decay_rate":
                    self.decay_rate = val
                    for n in self.nodes.values():
                        n.decay_rate = val
                elif key == "fire_reset_ratio":
                    self.fire_reset_ratio = val
                    for n in self.nodes.values():
                        n.fire_reset_ratio = val
                elif key == "walk_radius":
                    self.walk_radius = val
                    self.neighbor_radius = val      # 巩固与思考共用同一个半径
                else:
                    setattr(self, key, val)
                applied[key] = val
        return applied

    def load_state(self, path=None, reset_time=False):
        """读档。

        reset_time=True 时把每条记忆的时间印记重置到"现在"：
        存档里的 last_fired_time 是几天前的时间戳，直接读进来会让所有节点
        瞬间处于"已过不应期且 decay 已经跑完"的状态，看起来像集体僵直。
        重置后它们从干净的不应期起点开始放。
        """
        target = Path(path) if path else (self.memory_dir / "brain_state.json")
        if not target.exists():
            return False
        try:
            payload = json.loads(target.read_text(encoding="utf-8"))
        except Exception as exc:      # 损坏的记忆库不应阻断苏醒
            print("[aha_brain] 记忆库读取失败，以空白状态苏醒: %r" % (exc,))
            return False
        now = time.time()
        with self._lock:
            self.nodes.clear()
            self.connections.clear()
            self._conn_index.clear()
            self._conn_weight.clear()
            for d in payload.get("nodes", []):
                n = NeuronNode.from_dict(d, now=now)
                self.nodes[n.id] = n
            for c in payload.get("connections", []):
                self._connect(int(c["a"]), int(c["b"]), weight=float(c.get("w", 1.0)))
                self.stats["new_links"] -= 1      # 读档不算新连接
            self._next_id = int(payload.get("next_id", (max(self.nodes) + 1) if self.nodes else 1))
            h = payload.get("homeostasis", {})
            self.fatigue = float(h.get("fatigue", 0.0))
            self.tone_excitation = float(h.get("tone_excitation", self.target_safety))
            self.tone_inhibition = float(h.get("tone_inhibition", self.tonic_inhibition))
            for k, v in payload.get("stats", {}).items():
                if k in self.stats:
                    self.stats[k] = int(v)
            sp = payload.get("speech") or {}
            if isinstance(sp, dict) and sp.get("log") is not None:
                self.speech_log.clear()
                for e in sp.get("log", []):
                    if isinstance(e, dict) and "text" in e:
                        self.speech_log.append(e)
                self.speech_seq = int(sp.get("seq", self.speech_seq))
                self.last_speech = dict(self.speech_log[-1]) if self.speech_log else None
                self._speech_out.clear()   # 旧呓语不重播到终端
            if reset_time:
                # 注意：只重置"放电/衰减"的时间印记，不动 created_at。
                # created_at 是这条记忆的出生时间，读档不该把她的全部记忆都改写成"刚出生"，
                # 否则 fresh_nodes 会瞬间命中所有节点、好奇心直接顶到 100。
                for n in self.nodes.values():
                    n.last_fired_time = now - 1e6   # 拉远到"早已过不应期"，无需等待
                    n._last_decay_t = now           # 漏电从这一刻重新开始计
                    n.activation = min(n.activation, n.threshold * 0.5)
                self.fatigue = 0.0
                self.tone_excitation = self.target_safety
                self.tone_inhibition = self.tonic_inhibition
                self.pressure = 0.0
            # 启动/读档时把「增量游标」对齐到存档里的总数。
            # 不对齐的话，第一帧 d = stats["aha"] - 0 会把历史总账当成这一轮的爆发：
            #   窗口瞬间塞满 -> aha_rate 爆表 -> 一睁眼就「亢奋入睡」，还要白剪一批线；
            #   欲望更惨，2005 x 3.2 一次顶到上限，她还没睁眼就先说一句话。
            self._last_aha_seen = int(self.stats.get("aha", 0))
            self._last_self_aha_seen = int(self.stats.get("self_aha", 0))
            self._last_dream_link_seen = int(self.dream_links)
            # 用户 m03927：从存档恢复后必须重建"句子原文 -> 句节点"的索引。
            # 不重建的话，重启后第一节课文里的每一句都会再长一颗句节点。
            self._sentence_index = {}
            self._paragraph_index = {}
            for n in self.nodes.values():
                k = getattr(n, "kind", "char") or "char"
                if k == "sentence" and getattr(n, "text", None):
                    self._sentence_index[n.text] = n.id
            self._cur_sent = None
            self._cur_doc = None
            self._sent_nodes = {}
            self._sent_text = {}
            self._para_ctx = {}
            self._para_text = {}
        # V4.0 工作记忆不持久化：上一次运行残留的 temp 节点一律转正。
        # 它们在存档里是「正在想、还没想明白」的词，重启后不该继续占着
        # 临时区的位置（_wm 已经不认得它们了），但又确实是学到的东西。
        for _n in self.nodes.values():
            if (getattr(_n, "kind", "char") or "char") == "temp":
                _n.kind = "char"
        self._wm = {}
        self.box_copies = []
        # V4.0：读档后重建空间索引
        # V4.0 突触延迟：存档里没有延迟数组（老存档更没存），按权重估 ——
        # 权重大说明这条线被反复走过，延迟应该短（用进废退里的"用进"）。
        if len(self._conn_delay) != len(self.connections):
            self._conn_delay = []
            for _i in range(len(self.connections)):
                _w = float(self._conn_weight[_i]) if _i < len(self._conn_weight) else 1.0
                _f = 1.0 - _clamp((_w - 1.0) / 3.0, 0.0, 1.0) * 0.9
                self._conn_delay.append(
                    max(float(self.syn_delay_min),
                        float(self.syn_delay_new) * _f))
        self._adj = None
        self.syn_pending = []
        self.kd_rebuild()
        return True


# ---------------------------------------------------------------------------
# 自测：python aha_brain.py
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    engine = AhaEngine()
    print("小鱼的内核已苏醒... (v%s)" % VERSION)

    rng = random.Random(42)
    # 造两簇特征：一簇"绿色的叶子"，一簇"红色果子"（少数派）
    leaf_c = [0.20, 0.85, 0.25, 0.30, 0.70, 0.20, 0.50, 0.90, 0.10, 0.40]
    berry_c = [0.90, 0.25, 0.20, 0.80, 0.20, 0.25, 0.40, 0.85, 0.15, 0.35]

    # 再造两种：一张"平涂的蓝天"（弱边缘）与"密集的树枝"（强边缘）
    sky_c = [0.15, 0.45, 0.85, 0.60, 0.30, 0.75, 0.30, 0.20, 0.55, 0.15]
    twig_c = [0.35, 0.30, 0.25, 0.55, 0.60, 0.45, 0.70, 0.65, 0.25, 0.80]
    proto = [leaf_c, leaf_c, leaf_c, berry_c, sky_c, twig_c]

    def sample(center, noise):
        return [_clamp(v + rng.gauss(0, noise), 0.0, 1.0) for v in center]

    # 用虚拟时钟推演 90 秒：每 150ms 一次输入，这样漏电与疲劳才真实发生
    # （真实 time.time() 在死循环里几乎不流逝，衰减永远是 0，激活会假性饱和）
    t0 = time.time()
    for i in range(600):
        # 每 9 次里混进一次"红果子"——少数派
        center = berry_c if i % 9 == 0 else proto[(i // 3) % len(proto)]
        now = t0 + i * 0.15
        engine.learn(sample(center, 0.14), meta={"step": i}, now=now)
        engine.tick(0.15, now=now)

    print("节点数: %d  连接数: %d" % (len(engine.nodes), len(engine.connections)))
    print("生理指标: %s" % json.dumps(engine.physiology(), ensure_ascii=False))
    print("最近想法: %s" % engine.last_thought)

    # 稀疏度检查：稀有特征的稀缺度应显著高于常见特征
    s_leaf = engine._salience_of(leaf_c)
    s_berry = engine._salience_of(berry_c)
    print("稀缺度  叶子样本=%.3f  陌生样本=%.3f" % (s_leaf, s_berry))

    # 树状检查：统计节点到原点的半径分布
    r = [math.dist(n.pos, (0.0, 0.0, 0.0)) for n in engine.nodes.values()]
    print("空间半径 均值=%.1f 最大=%.1f (全图随机撒点应≈43)" % (statistics.mean(r), max(r)))
    print("CHANGELOG:")
    for line in CHANGELOG:
        print("  -", line)


# ---------------------------------------------------------------------------
# CHANGELOG 列表见文件开头（放在 __main__ 之前，供自测打印）
# ---------------------------------------------------------------------------
