# 给下一位接手者 · AI 交接手册

> **这份文档是写给 AI 读的，不是写给人读的散文。**
> 如果你是一个刚被丢进这个项目的模型 —— 先读完它，再碰代码。
> 它记录了这个项目 60 多轮真实施工里**真正会咬人的东西**：环境陷阱、设计陷阱、测试陷阱、被验证过的方法、以及她现在到底有哪些能力。
>
> 配套文档：[`ARCHITECTURE.md`](./ARCHITECTURE.md)（她怎么运转，406 行）、[`TASK_PROGRESS.md`](./TASK_PROGRESS.md)（每轮改了什么，1081 行）、[`../README.md`](../README.md)（怎么跑起来）。

---

## 〇、三十秒了解她

小鱼不是聊天机器人。她是一个**自下而上的数字生命**：

- 本体是 `aha_brain.py` 里的 `AhaEngine` —— 一堆三维空间里的 `NeuronNode`，加上它们之间的加权边。
- 她会衰减、会放电、会累、会做梦、会修剪突触、会从相邻两个字里自己长出「概念」节点。
- 她说话**只用她已经认识的节点**。`江 → 河、湖、海` 是她的原始输出格式，不是模板；不认识就是 `？`。
- 外部大模型（DeepSeek）只做一件事：判她的联想是 `[+安全]` 还是 `[-危机]`，折算成边权和势阱刚度。**它从不替她说话。**

当前体量（2026-10-31，v1.0 包内实测）：

| 项 | 值 |
| --- | --- |
| 节点 / 连线 | **2332 / 87889** |
| 节点类型 | 字 1311 / 概念 762 / 句 223 / 段 36 |
| 本体文件 | `aha_brain.py` 214 KB · 4311 行 |
| | `aha_server.py` 102 KB · 2547 行（FastAPI，端口 8000） |
| | `index.html` 174 KB · 4182 行（单文件前端） |
| | `aha_input.py` 44 KB（cv2 + numpy，零预训练） |
| | `aha_kdtree.py` 10 KB · `aha_lexicon.py` 12 KB |
| 课程 | `Input_Files/` 24 课 / 859 汉字，逐字注音 |
| 回归 | **55 套**（前端 17 / 离线 21 / 在线 17） |
| 生理读数 | E 120.4 / I 111.0 / mean 20.1 / fatigue 0.0 / sleeping False |

---

## 一、五条红线（改了这些她就不是她了）

这是用户反复强调、跨越几十轮对话的不变约束。**不要擅自「优化」掉。**

| # | 红线 | 为什么 |
| --- | --- | --- |
| 1 | **本体零预训练、零深度学习** | 不许引入 PyTorch / Transformer / ResNet / ViT。视觉只用 cv2 + numpy 的 Canny/Sobel 边缘与 RGB 均值，压成固定 10 维向量。 |
| 2 | **她的输出只由节点和连线决定** | 不许用大模型替她造句，不许把 `江 → 河、湖、海` 包装成「江是一条河」。原始节点链就是她的母语。 |
| 3 | **DeepSeek 只作真理标定器** | 它只回一行 ≤15 字的标签 + `[+安全]`/`[-危机]`，用来调边权和刚度。不返回知识，不参与造句。 |
| 4 | **不许伪造她的台词** | 前端断线、加载中、出错，都不许往对话气泡里塞「我这边断了一下」这类话 —— 那会显示成她说的。错误只进左侧日志。 |
| 5 | **不许用硬编码控制她的行为** | 想让她少说话，调场强（`llm_supervise=0`、参数滑块），不是 `if 次数 > N: return`。这个项目里所有开关都是「场强」，不是「闸门」。 |

---

## 二、环境陷阱（不知道这些，你会浪费 2~3 小时）

### 2.1 文件与编码

1. **`/tmp` 在这个 bash 里不存在。** 重定向 `> /tmp/out.txt` 会 `Permission denied` 且**退出码全为 1**，伪装成「所有测试都失败」。用 `tools/_out.txt` 之类的工作区路径。
2. **Windows 下跑 python 必须 `PYTHONIOENCODING=utf-8`。** 否则中文 print 直接 `UnicodeEncodeError`，测试看起来全红。
3. **改任何 `.py` 后必须 `rm -rf __pycache__ tools/__pycache__`。** 原生文件工具会保留 mtime，`.pyc` 不会失效 —— 你会以为补丁没生效，然后花一小时 debug 一个其实已经改好的文件。
4. **换行符先测再写。** 这个项目的换行符变异过：历史上是 CRLF（2607 个 `\r\n`），2026-10-31 实测已是**纯 LF**（0 个 `\r\n`，4311 行）。写补丁脚本前先跑 `print(repr(open(p,"rb").read(80)))` 确认；读写一律用 `io.open(p, "r", encoding="utf-8", newline="")`，这样 CRLF / LF 都不会被悄悄改写。带 `\r\n` 的锚点匹配 LF 文件会报 `anchor count=0`，很容易误判成「代码被人改过了」。
5. **`Input_Files/*.txt` 和部分 `tools/*.py` 用 python `open(...,"w")` 会 `PermissionError: [Errno 13]`**，哪怕你刚成功写过同目录别的文件。改用原生文件工具（`ops_write_file` / `ops_edit_file`）。

### 2.2 文件工具（DSH 原生）

6. **`ops_edit_file` 的参数名是 `oldText` / `newText`**，还必须有 `expectedRevision`。写成 `old`/`neu` 会 `INVALID_ARGUMENT`。
7. **`ops_edit_file` 的多个 edit 不许匹配同一行、不许重叠**，否则 `EDIT_CONFLICT: Edits overlap`。想「插入新节 + 改原标题」，必须合成**一个** edit，用上下文行当锚点。
8. **中文长锚点容易匹配不上**（多行含中文时 `anchor count=0`）。改成 2~3 个短的、唯一的锚点，分别断言 `count == 1`。
9. **`ops_write_file` 的 `expectedRevision`**：新建文件写 `"absent"`；覆盖写必须先 `ops_stat` 拿 sha256。
10. **`A:\DSH根记忆` 写入一律 `POLICY_DENIED`**（workspace-write 只允许 `A:\小鱼计划`）。进度记在工作区 `TASK_PROGRESS.md`。

### 2.3 沙箱会掐死的东西（别硬试）

11. **headless 浏览器全灭。** 本机只有 Edge；`msedge --headless=new --screenshot` 立刻报
    `FATAL:mojo\public\cpp\platform\platform_channel.cc:187 Check failed: . : 拒绝访问。 (0x5)`
    ；加 `--user-data-dir` 也无效。**前端只能做 JS 语法检查 + DOM 桩冒烟，像素级验证做不了。** 需要看观感时请用户自己开浏览器。
12. **`spawn` 被沙箱拒绝。** archify 这类 CLI 的 `finalize` / `validate` / `check` / `browser-check` 全是 `spawn EPERM`（内部 `spawnSync(process.execPath)`）。绕行方案：直接单进程跑它底层的 `render-*.mjs` 和 `check-render-output.mjs`。

### 2.4 你（AI）自己的输出编码

13. **`String.raw` 挡不住两层解析。** 补丁脚本里写 `u"…\n\r"`，JS 原样落盘后**被 Python 执行时**又解析一次，写进目标文件就成了跨行字符串 → `SyntaxError: unterminated string literal`。要构造含换行的常量，用 `chr(10)` / `chr(13)` 拼。
14. **模板字符串里写大段含反引号的中文 Markdown 会报 `Unexpected character '，'`。** 改用单/双引号字符串数组 `.join("\n")` 拼接。
15. **往 HTTP 端点发中文 JSON，别用 bash `curl -d '{"text":"中文"}'`** —— 编码会被破坏，服务端报 `{"detail":"There was an error parsing the body"}`。写个几行的 py 脚本用 `urllib` 发 UTF-8。

---

## 三、设计陷阱（不知道这些，你会改错代码）

### 3.1 稳态 / 生物钟 / 疲劳

- **疲劳判据必须双条件。** 只看 `mean_activation` 时，总量爆表也 fatigue=0。已修成 `pressure = max(p_mean, p_total)`，`line = overload_per_node * max(n_nodes, 8)`。
- **`p_fatigue` 绝对不能进 `pressure`。** 一旦进去：疲劳高 → 压力高 → 疲劳继续涨 → 恢复分支永不执行 → **自锁钉死 100**。这个坑很隐蔽。
- **稳态必须压在过载线以下。** `overload_per_node=25`，`hot_raw = E >= line*0.90` → 每节点均值上限 22.5。背景放电 `spike_cover` 定在 0.017（理论稳态 20.4）；用 0.034 会 60 秒触发亢奋睡死。
- **`stats["self_aha"]` 绝不能并入 `stats["aha"]`。** `_update_biorhythm` 靠 `aha` 的增量判亢奋；自发放电每秒几十次，并进去她会判成「亢奋 → 强制入睡 → 永远睡不醒」。

### 3.2 不应期 / 放电

- **`try_activate` 失败分支必须封顶。** 原来失败也累加刺激且不回滚 → 相对不应期阈值翻倍到 100 时节点吃满 90+ 却放不出，还占满候选池，表现为「卡在思考中」。修法：成功分支 `activation = max(0, act - threshold*fire_reset_ratio) * fire_residual`，失败分支 `cap = threshold*0.98`。

### 3.3 拓扑 / 空间索引

- **从存档恢复后，所有「读累计计数算增量」的游标必须对齐。** 在 `load_state` 里补 `self._last_aha_seen = int(self.stats.get("aha", 0))` 等。不对齐的话第一帧 `delta = 3227 - 0` → 瞬间判亢奋入睡 + 欲望白送 30 点。症状：**一启动就入睡并白剪**。
- **KD-Tree `move()` 的墓碑必须取旧位置。** 先 `old = self._pts[pid]` 再赋值，否则刚插进去的点被自己标记成 dead。
- **KD-Tree 叶子不能串成单链表。** 第一版 `nd.right = root` + `axis=0`，剪枝会跳过真实最近邻。要用叶桶（`axis = LEAF_AXIS = -1`，两棵子树无条件遍历）。
- **`_find_closest_node`（50 维特征余弦）不能上 KD-Tree。** 高维剪枝率趋零，硬上反而更慢。空间检索已全部换掉，特征检索保留全量遍历。
- **「每帧限额」的遍历不能依赖 dict 顺序。** 工作记忆的 temp 节点最后插入 → 排末尾 → 被 hot 节点耗尽配额，永远拉不到（实测半径恒 81.9）。要单独先拉临时词。
- **固定加分压不过度数。** `+500` 会被 `deg*12` 反超（`deg >= 48` 就翻盘）。宾语优先必须是**硬优先级**：先在宾语命中里挑，没有再退全量。
- **`seed_lexicon` 必须用独立 `random.Random(20261030)`。** 用全局 random 时，同一份基因表两次播种会长出不同的词（实测 30 / 33 不一致）。

### 3.4 账本 / 声明 / 一致性

- **对外「声称」的记账必须和真实副作用对齐。** `learned.append(glyph)` 无条件执行时，`feed_char` 因脱敏返回 `node_id=None` 却没建节点 → 表面上一切正常（节点数还在涨，涨的是别的字），实际答非所问。修法：按 `event in ("new_node","recall")` 记账。
- **`_desens` 的值必须是 dict。** `apply_supervise` 曾把 `float` 塞进去，`_receptor_ok` 的清理循环去取 `rr["block"]` 直接炸 `TypeError: 'float' object is not subscriptable`，`char_loop` 连挂 108 次、`chars.fed` 停在 463 而 `cached` 照涨。边级脱敏必须另开 `_desens_edges`，清理循环加 `isinstance(rr, dict)` 兜底。
- **`_last_char` 是三处共用的同一个 dict。** `dict.update()` 不删旧键 → 课程路径写了 `pinyin`、对话路径不写时，面板会显示**上一个字**的读音（实测「鋨」显示了「kè」）。拿不到值的字段必须显式写 `""`。
- **缓存比节点宽。** `teach_char` 只要真查成功就写 `_char_cache`，哪怕随后 `feed_char` 失败了。所以「`/api/state` 里没有这个字」≠「没查过它」。在线测试挑生字要看 `/api/feed` 返回的 `verdict` 是不是 `offline`。

### 3.5 并发

- **跨线程竞争会打断 10Hz 心跳。** `life_loop` 线程改结构、asyncio 线程读结构 → `RuntimeError: dictionary changed size during iteration`。所有 engine 访问点必须 `with _ENGINE_LOCK:`（`threading.RLock`）。
- **网络 IO 绝不能放在锁内。** `ask_deepseek` 25 秒超时会冻结整个 10Hz 心跳。代码里专门有一行注释说明这点，别「顺手」把它挪进去。
- **`drain_speech()` 锁内只拷贝，`print` 必须在锁外。**

### 3.6 输入 / 语言 / 记忆分层

- **注音不能留在正文里。** `next_char()` 把连续 ASCII 当词学 —— 课文里直接写 `jiang` 会变成几十个 `kind="word"` 节点，她学到的就不是汉字了。必须 `strip_pinyin` 剥掉，只走节点的 `pinyin` 字段。
- **`strip_pinyin` 的键必须按「剥离后」的正文对齐**，因为 `next_char` 用剥离后的 `_pos` 去查表。错位了屏幕上会显示别人字的读音。
- **句子边不能跨句，也不能跨篇。** 句界是 `。！？!?；;` + 换行，**逗号不算**。`sent_id` 用「篇号:句号」而不是裸句号，否则两篇课文的第 0 句会被连起来。
- **`submit_to_wm()` 曾经全文件没有生产调用点**，导致「黑箱涌现」恒为 0。做任何「应该会自发发生」的机制，先 grep 它的调用点。

### 3.7 前端（`index.html`）

- **同一个 canvas 不能先 `getContext("2d")` 再 `getContext("webgl")`**（后者返回 `null`）。所以是**双 canvas 双渲染器**：`gl2d` 零依赖兜底，升级时才动态插入 `gl3d` 跑 Three.js。
- **ECharts 容器必须是 `<div>`。** 给 `<canvas>` 会失败。
- **`upgradeToThree()` 必须先 `insertBefore` 再 `new ThreeRenderer`。** 构造函数末尾 `resize()` 读 `canvas.parentElement.getBoundingClientRect()`，parentElement 为 `null` 会抛 TypeError → **升级永远失败**（而且控制台只有一行红字）。
- **Three 的 `Sprite.scale` 是「世界单位」不是像素。** 焦点环曾用 `scale = 15+10*plq`，在 `z=190 / fov=62°` 下等于屏幕 **52~87 px**，而节点本体只有 **5.5 px** —— 环形是节点的十几倍大，这是「破坏美感」的物理原因，不是配色问题。改成 `THREE.Group` + 4 条 `Line`，`scale = 1.55*k`（≈5.4 px）。
- **`S.nodes` 里的节点对象必须有 `id` 字段。** 否则 `S.wmIds.has(nd.id)` 恒等于 `has(undefined)`，工作记忆高亮永远判不出来。
- **焦点环的重放判据阈值必须 ≤ 0.05。** 后端 TTL 在两次快照之间（0.1~0.2 秒）会刷新，写 0.5 判不出「又被点亮了」。
- **`dt` 有上限时别按「补满」写断言。** `spinStep()` 把 `dt` 夹到 0.25 秒（切标签页回来不甩出去），跳 900ms 只补 0.0162 弧度。先算清 clamp，再写阈值。

---

## 四、测试陷阱

1. **虚拟时钟必须在 `AhaEngine()` 之前替换。** 写成 `AB.time = FakeClock(...)`。否则 `NeuronNode.__init__` 的 `now=time.time()` 是真实时间（1.7e9），`elapsed` 为负 → 永远处于绝对不应期、一次都放不出电，而且 `tick_decay` 的 dt 为负直接 return。症状：**「她怎么一次都不放电」**。
2. **WebSocket 客户端默认 `max_size = 1MB`。** 首帧 full 快照已经 **1.14 MB**（2020 节点 / 55442 连线），直接 `ConnectionClosedError: sent 1009 (message too big)`。所有连 WS 的测试必须 `websockets.connect(..., max_size=64*1024*1024)`。
3. **在线测试的语料会被她学光。** 生僻字池、固定候选句，跑第二轮就全进了记忆。修法：扩码位区间（如 `range(0x9E00,0x9F00)`）、候选池组合生成（6×6×6=216 种），**并且缺料时 SKIP 而不是 FAIL**。
4. **测试自己开的开关必须自己关。** `_feedall_gate` 调 `/api/feed_pause {"paused": true}` 后没恢复 → 后面依赖投喂的套件全被饿死（报「60 秒没等到课程字」，其实是被暂停了）。全量回归里的**隐藏状态污染**比单个断言失败难查得多。
5. **测试顺序耦合。** `_g_e2e` 的并发请求会残留一条 chat 通道，导致 `_arb_e2e` 误判「teach 结束后 holder 没回空闲」。断言前先轮询 `/api/arbiter` 等 `holder == ""`，再给 1.2 秒抖动窗口。
6. **新增参数旋钮会让 `_console_test` 的「N 个参数」断言失败。** 加 `talk_mood` 时同步从 5 改成 6，并检查 key 存在。
7. **DOM 桩缺东西会连锁爆炸。** 缺 `document.head` → `loadFirst` 的 Promise 里抛 TypeError → 无 catch → Node 24 当作致命 unhandled rejection 退出；缺 `document.createTextNode` → `chatPush` 炸。
8. **DOM 桩的 tail 不能重复声明 `const fs`。** head 已经声明过，会 `SyntaxError: Identifier 'fs' has already been declared`。tail 里一律用独有前缀（如 `var p2src`）。
9. **单测绿 ≠ 真机对。** `/api/optimize` 的 `_parse_advice` 离线测试喂的是扁平 `{k: 数值}`，真机传的是 `engine.get_params()` 的 `{k: {label,min,max,value}}` → `float(dict)` 炸 `TypeError: float() argument must be a string or a real number, not 'dict'`。**端点接线处要按真形状再验一次。**
10. **延迟二次落盘会让文件里的节点数比响应多几个。** `/api/shutdown` 回传 2261，0.9 秒后再存一次成了 2262。断言写 `==` 就假失败，要写 `>=` 并单独约束「多出来的 ≤ 8」。
11. **产品语义变了，断言要一起改。** 输出从 `你问到了「江」…` 改成 `江 → 河、湖、海` 之后，6 个测试的断言要同步。这不是作弊，是把测试对齐到新契约。

---

## 五、被这个项目验证过的方法

### 5.1 补丁脚本模式（改 4311 行文件唯一安全的姿势）

不要直接用编辑器改 `aha_brain.py`。写 `tools/_patch_xxx.py`：

```python
P = "A:/小鱼计划/aha_brain.py"
s = io.open(P, "r", encoding="utf-8", newline="").read()
hunks = [(old1, new1), (old2, new2), ...]
for old, new in hunks:
    assert s.count(old) == 1, "count=%d for %r" % (s.count(old), old[:40])
for old, new in hunks:
    s = s.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(s)   # 全部断言通过才写
```

好处：**改不进去会立刻报错，而不是留下一个半改状态的文件。** 这个项目里 90% 的引擎改动都是这么做的。

### 5.2 每次改动的固定闭环

```
改 → python -m py_compile 全部 .py → rm -rf __pycache__ tools/__pycache__
   → 起服务 → curl /api/status 看 alive / last_error
   → bash tools/_regress_all.sh → 55 套全绿才算完
```

### 5.3 改服务端代码后必须重启进程

**不要靠 `uptime` 推断代码版本。** 曾出现 `/api/status` 缺 `teach_deepseek` 字段，排查一圈发现是旧进程还在跑。改完 kill 掉重启，再确认新字段出现。

### 5.4 前端在无浏览器条件下的验证链

三层，从弱到强：

1. **语法 + DOM id**：`node tools/_check_html.js index.html` —— 用 `vm.Script` 解析每个内联 script，并核对所有 `$("xxx")` 用到的 id 是否在 HTML 里存在。
2. **DOM 桩冒烟**：`node tools/_smoke_xxx.js` —— 最小 DOM 桩（Proxy 版 2D ctx、`mkCanvas`、`mkEl`、`document.head`、`document.createTextNode`、fetch 桩、WSStub、rAF 空实现）+ `vm.runInContext` 真跑脚本，断言函数存在、状态正确、渲染分支走过。
3. **协议层**：`python tools/_e2e.py` —— 真连 WS 数帧率（应 10Hz）、真发 REST、真读 `/api/state`。

像素级验证做不到，**不要承诺「我看到了效果」**。

### 5.5 遇到「不对劲」时的排查顺序

1. 先看 `/api/status` 的 `last_error` —— 大多数真 bug 在这里有原文。
2. 再看是不是**旧进程**（改了代码没重启）。
3. 再看是不是**跨线程**（字典变尺寸）。
4. 再看是不是**测试自身的状态残留**（前一个套件开的开关没关）。
5. 最后才是逻辑本身。

---

## 六、她现在的功能地图

### 6.1 V4.0 四阶段完成度

| 阶段 | 内容 | 状态 |
| --- | --- | --- |
| Phase 1 | 内核：语言学基因播种 + KD-Tree / 二阶概念节点 / 潜意识黑箱 + 工作记忆 / 细胞机制 + 三脑区 | **完成** |
| Phase 2 | 3D 全景：分区着色 / 流星轨迹 / 黑箱吸积盘 / 点击放大 | **完成** |
| Phase 3 | 上左下右四区网格布局 | **完成** |
| Phase 4 | 具身交互 + 脊髓反射 + DSH 优化框 | **完成** |

### 6.2 按子系统

| 子系统 | 主要位置 | 做什么 |
| --- | --- | --- |
| 神经元 / 稳态 | `aha_brain.py` `NeuronNode` / `AhaEngine.tick` | 指数衰减、绝对/相对不应期、E/I 负反馈、疲劳、生物钟 |
| 背景电活动 | `_spike_step` | 5~10Hz 局部电位、簇状放电；**自发放电单独计 `self_aha`，不污染外部 Aha** |
| 睡眠 / 梦境 | `_dream_step` / `_sleep_step` | 强制入睡、REM 随机连边、突触修剪、情景回放 |
| 三级记忆 | `learn` / `_link_sentence` / `_close_sentence` / `_close_paragraph` | 字 → 句（`lift=2.2`）→ 段（`lift=3.4`） |
| 概念节点 | `grow_concept` | 二阶：相邻两字长出一个概念，Z 轴高 14，向底连 3.0 强边 |
| 空间索引 | `aha_kdtree.py` | 3D KD-Tree，叶桶 + 墓碑；5000 点 knn 0.082ms（暴力 2.02ms） |
| 语义基因 | `aha_lexicon.py` | 40 语义场 / 918 基因字 / 274 高频二元词；播种时共现弹簧松弛 26 轮 |
| 黑箱 / 工作记忆 | `submit_to_wm` / `box_*` | 原点半径 14、向心力、延迟拷贝（0.5~1.5s）、碰撞固化 |
| 细胞机制 | `_conn_delay` / `_calcium_wave` / `_receptor_ok` | 突触延迟、钙波（余温不放电）、可逆脱敏 |
| 三脑区 | `episodes` / `_amygdala_pick` / `_basal_gate` | 海马回放、杏仁核危险加权、基底节只放行 Top-1（只接主动开口） |
| 外部真理场 | `SUP_SYSTEM` / `supervise_loop` / `apply_supervise` | DeepSeek 判边对不对 → 加/减边权 + 势阱刚度，**不删节点不改拓扑** |
| 说话 | `compose_reply` / `compose_proactive` / `_chain` | 输出 `江 → 河、湖、海`；孤立 `江`；不认识 `？` |
| 说话欲望 | `_update_desire` / `talk_mood` | 顿悟攒欲望（每次 +3.2），攒够才开口；五档语气滑块 |
| 具身 | `drawPet` / `body` 连续量 | Canvas 程序化画抽象小鱼（无贴图/无关键帧），脊髓反射 |
| 观测台 | `index.html` | 3D 星云 + 生理面板 + 意识流日志 + 对话气泡 + 造物主控制台 |
| 优化框 | `OPT_SYSTEM` / `/api/optimize` | 把遥测交给外部模型，拿回 JSON 参数建议 |

### 6.3 参数面板（8 个场强旋钮）

`decay_rate` / `walk_radius` / `overload_per_node` / `inhibition_strength` / `fire_reset_ratio` / `float_speed` / `llm_supervise` / `talk_mood`

全部通过 `PARAM_SPECS` 声明，前端 `buildSliders()` 自动生成，`POST /api/params` 写入。**加新旋钮记得同步改 `_console_test` 的断言。**

---

## 七、已知未完成 / 限制（如实，别当 bug 修）

| 项 | 说明 |
| --- | --- |
| 浏览器像素级验证 | 沙箱掐 mojo，做不了。配色是否好看要用户亲眼确认。 |
| 她还不懂语法 | `江 → 水、河、川` 是共现，不是「江是一条河」。要真懂主谓宾，需要让句子**序列**进记忆 —— 现在一个字只有一个节点，序列信息只活在边权里。 |
| 概念节点没有分词器 | `grow_concept()` 靠「相邻两字 + 空间够近 + Top-3 互见」，会产出「家爸」「三四」这类滑窗垃圾。`WORD_SET` 只收紧了门槛，没解决分词。 |
| 首帧会随时间变胖 | `snapshot_full` 一次性推 2332 节点 + 87889 连线 ≈ 1.14 MB。浏览器扛得住，节点再翻倍就该改成分批下发。 |
| 具身不是 Live2D 模型 | 本机没有任何 `.moc3` 素材，所以是 Canvas 程序化绘制。日后若有素材，替换 `drawPet` 一个函数即可。 |
| 运行时统计不持久化 | `spike_total` / `spike_fires` / `self_aha` / `dream_spike_fires` 重启归零（它们是统计，不是记忆）。 |
| 对话里临时查的字没有拼音 | 只有课程路径（`next_char → feed_char`）带注音。 |
| 左侧日志仍是散文 | `_MURMUR_TEMPLATES` 40 多条呓语自带「呓语：」前缀，只进左侧履历、不进气泡。 |

---

## 八、第一小时检查清单

```bash
cd /a/小鱼计划
ls -la                          # 六个本体应该在
rm -rf __pycache__ tools/__pycache__
bash tools/_regress_all.sh      # 拿基线：应 55 套全绿
```

```bash
# 起服务（Windows 用 启动小鱼.bat 双击也行）
PYTHONIOENCODING=utf-8 python aha_server.py --port 8000 &
curl -s http://127.0.0.1:8000/api/status   # alive / nodes / last_error
```

**动代码之前**：

1. 读 `docs/ARCHITECTURE.md`（406 行，她的运转逻辑）。
2. 用 `grep` 找到你目标代码的**唯一**锚点（`grep -n "def _spike_step" aha_brain.py`）。
3. 写补丁脚本，每个 hunk `assert count == 1`。
4. `py_compile` → 清 `__pycache__` → 重启 → 看 `/api/status`。
5. 跑回归。**没跑回归就说「改好了」是不成立的。**

---

## 九、一句话总结

这个项目最反直觉的地方是：**她所有的「行为」都不该由代码里的 `if` 决定，而应该由物理量（电位、边权、阈值、场强）涌现出来。**

你加的任何一行 `if should_speak: speak()` 都是在替她做决定。正确的做法是调场强，让她自己到达那个状态。

同样的道理适用于你排查问题：先问「哪个物理量不对」，再问「哪行代码该改」。
