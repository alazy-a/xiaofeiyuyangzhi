# Project Aha（小鱼）任务进度

> 最后更新：2026-10-30 23:20 · 本轮任务：关闭小鱼 —— 先落盘，再让她睡过去（m06140）
> 状态：\*\*服务在跑\*\*（job `pwsh-4c5ac3b53b454fb8`）· 2264 节点 · \*\*55 套测试全绿\*\*（前端 17）

## 一、当前状态

|项|值|
|-|-|
|服务|**在跑**（job `pwsh-4c5ac3b53b454fb8`）· http://127.0.0.1:8000|
|启动方式|**双击 `A:\\小鱼计划\\启动小鱼.bat`**（自动开浏览器）；`停止小鱼.bat` 用来关|
|记忆体|`Memory\_Core/brain\_state.json`（重启自动加载）+ `observations.json`|
|大脑|`aha\_brain.py` 214147 B / 4311 行（Phase 1 + 真理场 + Phase 2 + Phase 4 的脊髓反射 / 躯体连续量）|
|输入层|`aha\_input.py` 44125 B（+ 拼音剥离 / 句子号 / 一课一停）|
|后端|`aha\_server.py` 102709 B / 2547 行（+ `/api/optimize` DSH 优化框、`/api/supervise`、`/api/shutdown`）|
|前端|`index.html` 174003 B / 4182 行（+ Phase 3 四区网格、Phase 4 具身卡 `#petCard` / 优化框 `#optCard`、巡览按钮 `#btnSpin`、关闭按钮 `#btnPower`）|
|节点 / 连线|2264 / 6 万+（含 918 个基因播种字、概念节点、句段节点）|
|DeepSeek|已接通，`teach\_deepseek` 实时增长|
|课程|`Input\_Files/` 24 课 / 859 汉字（逐字注音）|
|投喂|由 `hold` 闸门控制，读完一课即停|
|回归|**55 套全绿**（前端 17 / 离线 21 / 在线 17）|

## 二、本轮（m06140）：关闭小鱼 —— 先落盘，再让她睡过去

用户要一个按钮：「点击后保存此次训练进度然后关闭小鱼」。

|项|内容|
|-|-|
|位置|顶栏最右 `#btnPower`「⏻ 关闭」，暗红常驻（危险动作不抢眼，但找得到）|
|两道确认|第一下只上膛（按钮变红写「确认关闭？」），**4 秒内再点一次**才真发请求；超时自动复位|
|后端|`POST /api/shutdown`：锁内 `engine.save\_state()` + `save\_observations()` → 返回 → 后台线程 0.9 秒后再存一次 → `os.\_exit(0)`|
|为什么延迟|响应必须先回到浏览器，用户要看到「已保存」才断线；退出不能跟响应抢|
|为什么存两次|那 0.9 秒里她还在长（实测每次多 1\~2 个节点），第二次才是最终态|
|退出方式|`os.\_exit(0)`：已经显式落盘，不必等 uvicorn 收尾（`uvicorn.run` 一把梭，拿不到 server 实例）|
|前端收尾|`PWR.off = true` → `ws.onclose` 与 `scheduleReconnect` 都短路，**不再对着已退出的进程刷重连**|
|遮罩|`#offMask` 全屏「小鱼已休眠」+ 节点数 + 存档路径 + 「双击启动小鱼.bat 叫醒她」|

**为什么要点两次**：这是全场唯一不可撤销的按钮 —— 她一关机，只有人能再把她叫醒。
一次误触就损失一段训练进程，所以用「上膛—击发」而不是原生 `confirm()`（原生框会打断星云渲染，也不好看出在她的页面上）。

### 验证

|项|结果|
|-|-|
|`node tools/\_check\_html.js index.html`|`script#1 OK (3276 lines)` / errors 0 / missing dom ids (none)|
|新增 `tools/\_smoke\_power.js`（44 项）|**POWER SMOKE OK**：按钮位置与样式 / 一次点击只上膛 / 超时复位 / 两下之内真发请求 / 遮罩亮起且写节点数与路径 / 顶栏「已关闭」/ 关机后 `scheduleReconnect` 与 `ws.onclose` 都不重连 / 失败后按钮复原并 toast|
|`python -X utf8 tools/\_power\_live.py`（真机，**破坏性**）|**POWER LIVE OK (13 项)**：`resp {"ok":true,"nodes":2262,"closing":true}` → 端口 3 秒内不再应答 → 存档 `saved\_at` 是 1.2 秒前 → 文件节点数 ≥ 回传值|
|前端回归|**17 套全绿**（`\_regress\_all.sh` 前端 16 → 17）|
|重启后|job `pwsh-4c5ac3b53b454fb8`，`alive True` / 2264 节点 / `last\_error` 干净；首页含 `btnPower`|

**真实验收（23:32，用户亲手点的）**：服务端日志最后一行就是
`23:32:30 \[INFO] 小鱼已休眠 · 记忆保存在 A:\\小鱼计划\\Memory\_Core\\brain\_state.json（2332 节点）`，
端口 8000 随即不再监听。随后用 `tools/\_state\_check.py` 体检存档：
`saved\_at 23:32:30`（21.6 秒前）· **2332 节点 / 87878 连线** · 坏坐标 0 · 边权 0.40\~4.00（均值 2.05）·
`observations.json` 363 个节点有履历（`deepseek 2345 · local 16 · cached 57555`）· speech 300 条。
关机前 11 分钟里她长了 67 个节点（2265 → 2332）。

**`\_power\_live.py` 故意不进 `\_regress\_all.sh`** —— 它跑完服务就没了，会把后续套件全带崩。手工验收用。

## 二·历史（m06061）：巡览按钮 —— 让星云自己慢慢转

用户要一个开关：「是否视角选择」——关掉就是现在的状态，打开后星云缓慢围绕大概的中心转动。

**实现思路：转的不是星云，是镜头。** 节点坐标就是记忆本身（位置 = 记忆），真去旋转坐标等于篡改认知。
所以只让 `CAM.yaw` 匀速增加 —— Canvas 投影与 Three 相机都读同一个 yaw，视觉上就是星云在公转。

|项|内容|
|-|-|
|按钮|顶栏 `#btnSpin`「⟳ 巡览」，在「⇄ 翻转」左边；开启态走 `#topbar button.on` 青色高亮|
|默认|`spin: false` —— **关着的时候视角和以前一模一样**，完全由鼠标决定|
|速度|`spinSpeed: 0.065` rad/s ≈ **97 秒一圈**（缓慢但看得见）|
|推进方式|`spinStep()` 按真实流逝时间算 dt，不按帧数 —— 掉帧时速度不变|
|上限|`dt` 夹到 0.25s：切标签页回来只补 0.25 秒，不会一下甩过去一大截|
|拖拽|`CAM.dragging` 时停转；松手后 `spinHold = now + 1200` 缓 1.2 秒再继续，别抢手里的画面|
|聚焦|`CAM.focus != null` 时不转 —— 点开某颗星看它，它不该自己转走|
|不动的参数|`pitch` / `dist` / `panX` / `panY` / `fov` 一个都没碰，只加 `yaw`|

**顺手修掉的老问题**：`bindMetricTips()` 原来只绑在 `#panel` 上 —— Phase 3 把「翻转」按钮搬进顶栏之后，
它的说明气泡其实一直弹不出来。这次把 `mouseover` / `mouseout` 抽成 `tipOver` / `tipOut`，面板与 `#topbar` 共用，
两个顶栏按钮的 tip 现在都生效。

`node tools/\_check\_html.js index.html` → `script#1 OK (3211 lines)` / errors 0 / missing dom ids (none)。
新增 `tools/\_smoke\_spin.js`（`head -n 261 tools/\_smoke\_feed\_head.js` + `tools/\_smoke\_spin\_tail.js`，虚拟时钟 `sandbox.\_\_now`）
→ **SPIN SMOKE OK（32 项）**：默认不转 / 首帧只记时间 / 关闭时 10 帧纹丝不动 / 开启 100ms 转 0.0065 弧度 /
跳帧只补 0.25s / 拖拽暂停 / 松手缓 1.2s / 聚焦暂停 / 按钮开关与高亮 / 只动 yaw 不动其他参数。前端 **16 套全绿**。

## 二·历史（m05346）：V4.0 Phase 4 —— 具身 + 脊髓反射 + DSH 优化框

蓝图对 Phase 4 的原话只有「Live2D 具身 / 脊髓反射 / DSH 优化框」三项。本机没有任何 `.moc3` / `.model3.json` 素材，
而「禁止预制动作」是这条项目的红线，所以具身改成**纯 Canvas 程序化绘制**：不加载贴图、不播关键帧、
所有姿态都由引擎每帧吐出的**连续量**算出来。

### 引擎侧（`aha\_brain.py`，上一轮已落盘）

|项|内容|
|-|-|
|脊髓反射|`\_spinal\_step()`：伤害感受器 `noci` 由威胁水平 + 高频放电推出，越阈值就触发 `屈肌 / 伸肌` 反射，记进 `reflex\[]`（deque）|
|躯体连续量|`body` 字典每帧算：`flex`（屈肌张力 ≤1.6）/ `lean`（身体倾斜，保号）/ `tail`（摆尾）/ `fin`（胸鳍张开）/ `eye`（眼睑 0\~1）/ `breath`（呼吸相位）/ `noci` + `spinal\_total` / `spinal\_kind` / `spinal\_ago` / `reflex`|
|服务端|`POST /api/optimize`：把遥测 + 参数清单丢给 DeepSeek，换回 0\~3 条「该调哪个旋钮」的建议；**只读，绝不自动 `set\_params()`**|
|遥测白名单|`\_optimize\_context()` 只捞 33 个标量 + `box` + `body` + `params`，实测 2330 B，不把 2000 个节点全发过去|

### 前端侧（`index.html`，本轮）

**① 具身卡 `#petCard`（面板第一张，可折叠）**

|部分|实现|
|-|-|
|`#petCanvas`|132px 高，按 `devicePixelRatio`（≤2）设 backing store，之后全按 CSS 像素画|
|`drawPet()`|呼吸底光椭圆 + 34 段采样点列的鱼身 + 两片尾鳍 + 两片胸鳍 + 眼睛。**没有任何贴图 / 关键帧**|
|配色|`k = clamp(noci/1.2)`，`hue = 194 + 158k`（青蓝 → 洋红 → 血红），`lit = 62 - 10k` —— 受伤就变红|
|姿态|`curl = clamp(flex/1.6)\*16` 度屈曲；`rot = clamp(lean,-1.2,1.2)\*0.20` 倾斜；尾摆 `sin(ph\*(2.6+tail\*5.2))\*(0.05+0.55\*tail)`；鳍张 `0.28+0.72\*fin`；眼 `g.scale(1, eye)` 压扁眼球 = 闭眼|
|读数|6 条 `.pbar`（屈肌 / 倾斜 / 摆尾 / 胸鳍 / 眼睑 / 呼吸，>72% 转红、>45% 转橙）+ 痛觉输入 + 脊髓反射次数|

**② DSH 优化框 `#optCard`（可折叠）**

* 点「让她看看自己」→ `POST /api/optimize` → 渲染 `summary` + 当刻遥测（节点 / E / I / mean / fatigue / sleeping）+ 至多 3 条建议。
* 每条建议：参数名 + `from → to` + 单位 + 一句理由 + **「应用」按钮**。
* **红线守住**：`optRun` / `renderOpt` 里都没有 `queueParam` 或 `api/params`；点「应用」才走 `queueParam(s.param, s.to)`，和手动拖滑块同一条防抖通道。

**③ 接线三处**

```js
// frameLoop()：updateHUD() 之后
var nowP = Date.now();
if (nowP - PET.lastDraw >= 42) { PET.lastDraw = nowP; try { drawPet(); } catch (e) {} }   // 24fps 限帧
// updateHUD() 开头
try { petHUD(p.body); } catch (e) {}
// boot()：bindSup() 之后
bindPet(); bindOpt();
```

### 测试

|套|结果|
|-|-|
|`node tools/\_check\_html.js index.html`|`script#1 OK (3171 lines)` / errors 0 / missing dom ids (none)|
|`node tools/\_smoke\_p4.js`|**P4 SMOKE OK**，8 组约 60 断言：两张卡就位 / **无贴图红线**（`drawPet` 段内无 `new Image`、`drawImage`、`THREE.`、`.moc3`）/ 优化框不许自动应用 / 躯体读数（`1.2/1.6 → 75.0%`、`hot` 配色、`-0.40` 保号、`noci` 变色）/ `petResize()+drawPet()` 不炸 / 点「应用」才下发 / 空建议与 `source:local` 文案 / 按钮只发一次 POST|
|`python -X utf8 tools/\_p4\_live.py`|**P4 LIVE OK (20 checks)**：`body` 10 字段齐 / 反射计数不倒退 / `E-105=15.8 tail=0.53`（兴奋高尾巴不缩）/ `noci=2.21 eye=0.26`（痛觉压眼睑）/ **`/api/optimize` 真调 DeepSeek，1.8 秒回 3 条建议**|

`/api/optimize` 真机返回原文（摘要）：

> 系统整体平稳，但工作记忆长期为 0、固化与回放均未发生，记忆难以沉淀，需降低衰减并扩大游走半径以促成顿悟与固化。

### 修掉的真 bug

`\_parse\_advice()` 里 `float(current.get(key, ...))` —— `current` 实际是 `engine.get\_params()` 的 `{k: {label,min,max,value}}`，
拿到 dict 直接 `TypeError`，端点整个 500。**离线测试喂的是扁平 `{k: 数值}` 所以一点没暴露**。
修法：调用点先摊平 `flat = {k: v\["value"]}`，`\_parse\_advice` 内部再 `isinstance(cur, dict)` 兜一层。

### 回归

`bash tools/\_regress\_all.sh` → **TOTAL pass=54 fail=0**（前端 16 / 离线 21 / 在线 17）。
中途两次各挂了一个 flaky（第一次 `region\_live` 的候选句被学光、第二次 `arb\_e2e` 通道残留），
都单跑全绿；两个 flaky 的根因与修法记在坑 33。

### V4.0 蓝图逐项验收（`tools/\_v4\_accept.py` → **V4 ACCEPT OK (25 items)**）

新写的一次性验收脚本，把 objective 原文的四阶段拆成 25 条，每条同时看**代码符号 / 真机读数 / 前端实现**，
再跑一遍就能确认蓝图没有退化。已加进 `\_regress\_all.sh` 的在线组末尾。

|阶段|项|真机读数（验收当时）|
|-|-|-|
|P1|共现词表播种 / KD-Tree / 二阶概念|概念节点 651 个（char 1301 / sentence 219 / paragraph 36）|
|P1|黑箱向心力 / 延迟拷贝 / 工作记忆|`pulled=63976` / `copied=757` / `wm\_cap=16`|
|P1|突触延迟 / 钙波 / 可逆脱敏|`syn\_sent=82637` `syn\_fired=13736` / `calcium\_total=81900` / `desens\_hold=15.0`|
|P1|海马体 / 杏仁核 / 基底节|`episodes=20` `replay=25` / `amygdala\_hits=9` / `pass/gate=21/168`|
|P2|分区着色 / 流星 / 吸积盘 / 点击放大|`zoneOf`+`zoneTint` / `flyPts`（在途 18）/ `accPts`（`box\_radius=14`）/ `focusOnNode`|
|P3|四区网格 / 顶栏 / 底部横带|`grid-template-areas` + `#topbar` + `#dock`|
|P4|具身 / 脊髓反射 / 优化框|`drawPet` 4725 字符无贴图 / `spinal\_total=1085` / `set\_params(` 不在 `api\_optimize`|

写验收脚本时自己也踩了两条**断言过宽**的坑（不是产品缺陷，记下来免得下次误判）：

1. 拿 `physiology()` 找 `amygdala\_danger` —— 它根本没暴露（只暴露 `amygdala\_hits`）。证据要改成「源码常量 `self.amygdala\_danger = 2.0` + 真机命中次数」。
2. 断言全文件 `"drawImage" not in html` —— `index.html:1546` 的 `ctx.drawImage(sp, ...)` 是 CanvasRenderer 的 **sprite 离屏预渲染**，跟具身无关。必须按 `drawPet` 到 `petHUD` 之间截段再查。

## 二·历史（m05346）：V4.0 Phase 3 —— 上左下右四区

蓝图对 Phase 3 只有「上左下右布局重排」一句，区域内容自行设计。

### 布局：`#app` 从 flex 改成 CSS Grid 四区

```
grid-template-columns: minmax(0, 1fr) 420px;
grid-template-rows:    auto minmax(0, 1fr) clamp(200px, 26vh, 300px);
grid-template-areas:   "top   top"
                       "stage panel"
                       "dock  dock";
```

|区|元素|内容|
|-|-|-|
|上|新增 `#topbar`|品牌 + 连接状态 + 六项指标（节点 / 突触 / 兴奋 / 抑制 / Aha / 输入）+ 引擎标识 + `⇄ 翻转`|
|左|`#stage`（原）|3D 星云，只留操作提示|
|右|`#panel`（原）|投喂 / 仲裁 / 生理 / 认知 / 调参 / 真理场 / 存档 / 硬件 / 教导|
|下|新增 `#dock`|左：意识流日志 `#logCard`（从 panel 搬出）；右：与小鱼对话 `#chatDock`（420px）|

* **`#logList` id 不变**：JS 里 `el("logList")` 一行没改。
* `.flip` 交换 `stage` / `panel` 两列（`grid-template-areas` 换成 `"panel stage"`），底部横带不动。
* 窄屏断点从 900px 提到 **1180px**：四区退回单列（上 → 星云 → 面板 → 底部横带），该断点下 `#app` 回到 `display: flex`。
* `#toast` 从 `position: absolute`（相对 stage）改成 `position: fixed` —— 否则它只在左半边居中。

### 顺手清掉的重复

* `#stage` 里原来的标题 / stats 块整块删掉（指标搬到顶栏，id 全部保留、无重复）。
* `#engineTag` 移到顶栏，`#btnLayout` 从 `.aux` 移到顶栏（id 不变，事件绑定没动）。
* `#chatDock` 的 `border-left` 删掉 —— 与 `#logCard` 的 `border-right` 叠成 2px 双线。

### 测试

新增 `tools/\_smoke\_p3.js`（`head -n 261 tools/\_smoke\_feed\_head.js` + `tools/\_smoke\_p3\_tail.js`）→ **P3 SMOKE OK**，40 项：网格三行 / 翻转后的 areas / 四块 `grid-area` / DOM 顺序 / 日志卡搬家 / `logList` 唯一 / 顶栏 10 个 id 都在且不重复 / stage 旧标题与 stats 已删 / `#toast` fixed / 翻转按钮两次点击 / `updateHUD` 与 `pushSpeech` 仍接通。
踩坑：DOM 桩没有 `document.createTextNode`（`chatPush` 靠它插正文），tail 里补桩。

### 结果

`bash tools/\_regress\_all.sh` → **TOTAL pass=48 fail=0**（前端 14 / 离线 19 / 在线 15）。
真机 `http://127.0.0.1:8000` 返回的 HTML 已带 `<header id="topbar">` / `<div id="dock">`，2084 节点、E 113.77 / I 102.95、清醒。

## 二·历史（m05346）：V4.0 Phase 2 —— 3D 全景

用户蓝图四点：分区着色 / 流星轨迹 / 黑箱吸积盘 / 点击放大。

### 后端（`aha\_brain.py`）

|改动|说明|
|-|-|
|`syn\_pending` 3 元组 → **5 元组** `(due, src, dst, amp, dur)`|记下总延迟才能算流星拖尾；`\_conduct` / `\_conduct\_step` / `\_drop\_node` 同步|
|`frame()\["flight"]`|在途信号 `\[src, dst, 剩余秒, 总延迟]`，最多 80 条|
|`snapshot\_full()\["flight"]`|建连第一帧就能画流星，不必等 100ms|
|`box\_snapshot()\["wm\_ids"]`|工作记忆节点 id 列表，前端据此判「临时区」|

`tools/\_flight\_test.py` → **22 ok**（五元组 / 四列 / 剩余<=总延迟 / 到站清空 / 无信号为空 / `\_drop\_node` 清 pending）。

### 前端（`index.html`，3537 行）

|块|实现|
|-|-|
|分区着色|`ZONE = {core 38°, work 54°, concept 276°, long 沿用 potColor}`；`zoneOf(nd)` 判定顺序 concept > `S.wmIds` > 半径 <= `boxR\*1.7` > 长期；`zoneTint` 只换色相/饱和，亮度仍由电位与放电驱动|
|吸积盘|Canvas：三层反向旋转椭圆环 + 中心径向渐变核，`squash = 0.16 + 0.40\*|
|流星|`ingestFrame` 存 `S.flight` + `S.flightAt`（10Hz 快照 + 本地外推，60fps 不跳）；Canvas 画头 + 3 段拖尾（`sin(pi\*prog)` 包络）；Three 用独立 `flyPts`（220 点，`setDrawRange`）|
|点击放大|`CAM.focus`；`focusOnNode(nid)` 直接算 yaw/pitch/dist（**不引入 lookAt** —— `project()` 本来就绕原点看原点，转 yaw 之后节点自然落在屏幕中心）；命中判据 `moved < 5px \&\& 按下 < 650ms`，拖动转视角不误触；空白处 `focusReset()`|
|面板|`#kZones`「核/临/概/云」四区实时计数（1 秒缓存）|

### 抓到的真 bug

`S.nodes` 里的节点对象**没有 `id` 字段**（`ingestFull`/`ingestFrame` 只存坐标与电位），`zoneOf` 里 `S.wmIds.has(nd.id)` 恒等于 `has(undefined)` → 工作记忆永远判不出来、`zoneStats` 恒 `2 / 0 / 1 / 1`。修法：两处 `S.nodes.set(id, { id: id, ... })`。

### 真机实测

|项|值|
|-|-|
|首帧（full 快照）|**1,168,026 B ≈ 1.14 MB**（2020 节点 / 55442 连线 / 11 列）|
|增量帧|33.6 KB，10Hz → **328 KB/s**（本地环回）|
|flight|39/39 帧带字段且全部非空；样例 `\[\[1564, 1254, 0.046, 0.45], ...]`|
|wm\_ids|每帧都在；投词「测试」→ node 1952 立刻出现在 `wm\_ids`|
|测试|`\_smoke\_p2.js` P2 SMOKE OK · `\_p2\_live.py` P2 LIVE OK · **47 套全绿**|

## 二·历史（m04766）：外部真理场 —— DeepSeek 只调势能，不提供动作

> 用户 m04766 的硬约束：\*\*严禁控制性代码\*\*。监督必须是一个\*\*场强\*\*，不是 if 分支 —— 场强为 0 时所有物理量自然归零，行为链不断。

### 落地的五块

|块|内容|
|-|-|
|星点浮动 `\_float\_step`|每个节点有 `home`；`pos += (home-pos)\*k + 正弦摆动\*amp\*dt`，`k = float\_home\_k\*(0.35+min(cap,stiff))`。速度 0 时乘法归零（不是跳过），实测位移 0.00e+00|
|势阱固化 `\_stiffen`|`stiff = min(cap, before + gain\*(1-before/cap))` 饱和增长；检索加分 `sim + 0.05\*min(3.0, stiff)`|
|外部真理场|`supervise\_loop` 每 1.2s 从 `drain\_supervise(2)` 取黑箱涌现的关联，问 DeepSeek「「A」和「B」有关系吗」→ `\[+安全]`/`\[-危机]` → `apply\_supervise`|
|自指环 `\_check\_self\_reflex`|被承认的 insight 边（weight≈1.4）若构成长度 3 的环 → `kind="reflex"` 开口 + 多巴胺|
|前端折叠卡片|`#supCard` 6 个读数 + 开关（`spec.kind === "switch"` 让滑块长成按钮）+ `/api/params` 到 8 个|

### 黑箱涌现（insight）恒为 0 的根因与修复

* **根因**：`submit\_to\_wm()` 全文件没有调用点 → `wm\_made=0` → 临时词永远不进黑箱 → 撞不出 insight → `sup\_queue` 恒空。
* **修法**：在固化之前插「④-b 黑箱里很挤」—— 到站记忆与 `kd\_nearest(a.pos, k=6)` 现查的邻居互撞，双判据 `\_sim < box\_collide and dist > box\_radius\*2.4`，连 `weight=1.4` 的边并 `speak(kind="insight")`。
* **必须限流**：不限时 45 秒产生 **1181 条** insight、连线 15575→19598、队列卡满 24。加 `insight\_gap=3.0` + 一次到站只撞一条（撞完把该节点移出 `box\_copies`）→ 60 秒 16 条。
* 碰撞参与者限 `kind in ("char", "concept")` —— 否则裁决问句会变成「「雨」和「课04\_金木水火土」有关系吗？」。

### 本轮修的真 bug：`\_desens` 被 float 污染

* `apply\_supervise` 的 crisis 分支把 `self.\_desens\["e:a:b"] = time.time() + hold`（**float**）塞进值为 `{n,t,block}` 的字典，而 `e:` 键从来没有任何读取方。
* 后果：`\_receptor\_ok` 的清理循环 `rr\["block"]` → `TypeError: 'float' object is not subscriptable` → `char\_loop` 连挂 **108 次**，`chars.fed` 停在 463 而 `cached` 照涨（缓存命中、字进不了大脑）→ `pinyin\_live` / `region\_live` / `supervise\_live` 三套假失败。
* 修法：边级脱敏独立成 `self.\_desens\_edges`（带 240 条上限清理），`\_receptor\_ok` 清理循环加 `isinstance(rr, dict)` 防御。

### 实测（真机，job `pwsh-fc91e2a7f8cc4ca6`）

|项|值|
|-|-|
|`sup`|asked 51 / safe 19 / crisis 32 / errors 0|
|`engine`|done 50 / safe 18 / crisis 32 / reflex 16 / stiff\_max 1.6 / stiff\_mean 0.033|
|`box`|insight 51 / pulled 29695 / copied 342 / wm\_made 2 / 固化 2|
|最近裁决|`了 ↔ 青 -> crisis（"没关系 \[-危机]"）`|
|节点 / 连线|1828 / 39754|
|参数|8 个（`decay\_rate` / `fire\_reset\_ratio` / `float\_speed` / `inhibition\_strength` / `llm\_supervise` / `overload\_per\_node` / `talk\_mood` / `walk\_radius`）|

### 边界（如实说明）

* **监督不是让她「懂」**：DeepSeek 只回答「这两个字有没有关系」，权重上下浮动是势能，不是知识。
* `wm\_made` 只有 2 —— 工作记忆的入口仍没有生产调用点，黑箱主要靠「④-b 到站互撞」产生 insight。
* **浏览器像素级验证仍做不了**（headless Edge 被沙箱掐 mojo），前端只做 JS 语法 + DOM 桩冒烟。
* 连线涨到 39754 是 `consolidate()` 每 2 秒给 120 个随机节点各连 3 个 KD 近邻的既有行为（Phase 1-B 起就有），不是本轮引入。

## 二·历史（m04082）：Project Aha V4.0 — Phase 1 内核

> 用户给出了《Project Aha V4.0：具身认知生命体完全体开发纲领》。本轮做完 \*\*Phase 1 的全部四小节\*\*（1-A 骨架 / 1-B 概念 / 1-C 黑箱 / 1-D 细胞与脑区）。Phase 2（前端 3D 全景）/ Phase 3（布局重排）/ Phase 4（Live2D 具身）尚未开始。

### 三条红线（写代码前先立下的规矩）

1. **禁止大模型代打**：DeepSeek 只做字典标定与图表锚点，绝不生成对话（m02206 已落实）。
2. **禁止预制动作**：Live2D 全靠数学参数与激素驱动。
3. **禁用死板 if-else**：行为必须源于物理引力、突触延迟、受体脱敏与内稳态涌现。

### 1-A 语言学基因播种 + KD-Tree

|文件|内容|
|-|-|
|`aha\_lexicon.py` 12139 B|40 个语义场 × 20\~40 字 = **918 个基因字**；274 条高频词对；`seed\_layout()` 用 Fibonacci 球铺 40 个场心（半径 68）+ 黄金角螺旋 + 26 轮弹簧松弛|
|`aha\_kdtree.py` 10333 B|三维 KD-Tree：叶桶 `leaf\_size=8`、墓碑按 `(pid, 点)` 去重、显式栈遍历、`rebuild\_min=48` / `rebuild\_slack=0.05`|

* **性能**：5000 点 `knn` **0.082 ms vs 暴力 2.022 ms = 24.7x**；星云实图（1518 点）**4.3x**；`radius` 只要求「不比暴力慢」（实测 2.1\~2.3x，半径内命中几十个点时常数开销吃掉收益）。
* **`seed\_lexicon()` 的规矩**：已存在的同字节点**一律不动**（记忆不该被基因改写）；新字若其共现伙伴已在图里就长在伙伴旁边（熟人带路），否则用基因坐标；场内相邻 `weight=1.6`、共现对 `weight=2.0`；基因边不计入 `stats\["new\_links"]`。
* **启动实测**：918 字 / **1101 条先天边 / 0.01 秒**。距离：江-水 5.48 · 江-河 6.56 · 火-烧 8.00 · 猫-狗 9.06 · **江-火 22.45**。
* `aha\_brain.py` 接入 9 处：`\_get\_spatial\_neighbors` 走 `kd.radius` + 不足 5 个时兜底 `knn`；`add\_new\_experience` / `\_close\_sentence` / `\_close\_paragraph` 插索引；`\_prune` 删索引；`load\_state` 末尾 `kd\_rebuild()`。

### 1-B 二阶概念节点 `grow\_concept()`

* 长度 2\~4；含虚词直接拒绝（不长「我是」「是小」「的了」）。
* **只算局部 Top-3，不做组合**：相邻两字距离 <= `concept\_close`(10.0) 算近；否则 `d > limit\*2.2` 直接跳过，再查 `kd\_nearest(a.pos, k=concept\_topk+1)` 里有没有它。
* 非 `WORD\_SET` 里的词（滑窗粘连）门槛收紧到 7.0；坐标 `cz = max(成分字 z) + concept\_z\_rise(14.0)`，双向强边 `concept\_weight=3.0`。
* 实测：824 个二元候选 → 长成 **34 个概念**（两次运行一致）。真词：江水、大海、月亮、吃饭、喝水、回家、上学、今天、春天、白云、石头；粘连垃圾仍在：家爸、小间、间小、三四、色红 —— 滑窗不分词的必然粗糙度。
* `\_glyph\_index()` 只收 `kind in ("char","temp")`：句 / 段 / 概念节点不进字索引，但工作记忆的 temp 要能查到。

### 1-C 潜意识黑箱（原点）+ 工作记忆

* **向心力**：判据是「`fire\_count` 前 6% 且 >= 12 次」，不是绝对阈值 —— 实测 1168 节点半径 min 15.1 / 中位 60.7，按 `radius<=14` 吸会把整片星云拽成一坨。每 5 秒重算一次热节点集。
* **必须单独拉临时词**：`self.nodes` 是 dict，temp 最后插入排末尾，「每帧最多拉 40 个」时被 hot 节点耗尽配额 → 实测 24 次采样半径恒 81.9。抽出 `\_pull\_one()` 先拉 `self.\_wm`（速度 ×2.2）再拉 hot。修后轨迹 **31.1 → 15.4 → 10.3 → 8.6 → 7.9 → 7.7**。
* **延迟拷贝**：`box\_copy\_lo/hi = 0.5/1.5`，`delay = lo + span \* clamp(dist/260, 0, 1)`（远的 1.38 s、近的 0.50 s）。
* **`box\_stay = 2.0` 不能省**：到站后必须在箱里停 2 秒。第一版 ready 只活一帧，temp 沉底要好几秒，两边永远撞不上（`insight` 跑 22 秒恒为 0）。
* **碰撞双条件**：`\_feature\_sim` 相似 **且** 双方都在箱内（距离 < `box\_radius\*2`）—— 热节点停在半径 14 球面、temp 停在 7.7，两侧距离 21，余弦掉到 0.46，只看相似度永远撞不上。
* **固化判据**：`tonic\_dopamine >= 4.0 and age >= 5.0 and 入箱距离 <= box\_radius\*1.3` 才转正，否则 20 秒 `wm\_ttl` 到期 `\_drop\_node`。第一版「多巴胺高 + 过 1.5 秒」就转正，真机上词还挂在半径 88 时就被固化了，黑箱等于没参与。
* `box\_hits\_max = 3`：一个词最多撞出 3 条联动线。`load\_state` 末尾残留 temp 一律转正成 char，`\_wm` / `box\_copies` 清空。

### 1-D 细胞机制与脑区

* **局部钙波**：放电后给 `kd\_nearest(k=6)` 的 5 个邻居 `activation = min(threshold\*0.9, +calcium\_gain 4.0)` —— **只加热不放电**，封顶 90% 阈值。清醒态才触发，且一帧放电数 <= 8 才扩散（防雪崩）。
* **可逆受体脱敏**：同一 glyph 在 12 秒窗口内第 10 次 → `learn()` 最前面返回 `{"event":"desensitized","node\_id":None}`，15 秒后自动恢复。脱敏状态**不落盘**。`teach` 走 `feed\_text` 整段只 learn 一次、没有 glyph，所以**不会**触发逐字脱敏 —— 验证必须走 `feed\_file`。
* **脑区**：基底节 Top-1 门控（`basal\_pass`）、海马体情景回放（`replay`）、杏仁核 danger-safe 加权、脊髓反射弧（屈肌 / 牵张 / 姿势）。`\_region\_test.py` 45 checks、`\_region\_live.py` 17 checks。

### 本轮修掉的两个真 bug（都不在 V4.0 计划里，是回归抓出来的）

1. **宾语加权被度数反超 → 改成硬优先级**。`compose\_reply` 选主角原本是 `sc += 500.0`，实测「你认识鹑吗」里「你」deg=47 → `47\*12-30 = 534`，刚学会的「鹑」deg=3 → `3\*12+6-2.4+500 = 539.6`，只差 0.4 分；度数再高一点直接反超，答成「你 → 低、风、写」。改成先只在宾语命中里挑（`in\_target or hits`），没有命中才退全量。
2. **`\_learn\_unknown\_in\_text` 的 `learned` 会撒谎**：`learned.append(glyph)` 原来无条件执行，`feed\_char` 返回 `desensitized`（`node\_id=None`）时节点没建、`learned` 却声称学会了 → 同一句的 `compose\_reply` 索引里没有它，必然答非所问。改成 `if node\_id and \_ev in ("new\_node","recall")` 才记账，否则打 `warning`。

### 说话欲望的每秒限速（V4.0 的副作用修复）

V4.0 之后自发 Aha 次数与节点数成正比（1300 节点时 `lam ≈ 17.7 次/帧`），`speech\_desire += min(30, d\_aha \* 3.2 \* gain)` 一帧顶格、清零后 1.4 秒又满。新增 `self.desire\_rate\_cap = 4.0`，两条涨欲望的路都改成 `min(cap, ...)`，`cap = desire\_rate\_cap \* gain \* dt` —— **性格（档位）决定每秒涨多少，星云规模不再决定她有多话痨**。

### 本轮实测（真机，job `pwsh-af3732d7221d4b47`）

|项|值|
|-|-|
|节点 / 连线|\~1503 / \~7703|
|基因播种|918 字 / 1101 条先天边|
|概念节点|34 个（824 候选）|
|黑箱|`copied` / `pulled` / `insight` 实测有值，`wm\_made` 与固化数见 `box\_snapshot()`|
|自发放电|\~1/s（`stats\["self\_aha"]`，不算顿悟）|
|回归|**40 套全绿**（前端 11 / 离线 16 / 在线 13）|

### 边界（如实说明）

* **这不是语义理解**：概念节点只代表「这两个字在空间上与局部邻域里靠得够近」，引擎不知道「江水」是什么。
* 概念里有「家爸」「三四」这种滑窗垃圾 —— 没有分词器，靠 `WORD\_SET` 门槛收紧只能缓解。
* **浏览器像素级验证仍做不了**（headless Edge 被沙箱掐 mojo），前端只做 JS 语法 + DOM 桩冒烟。
* Phase 2/3/4 全未开始；`\~/.dsh/dsh-pet` 里没有任何 `.moc3` / `.model3.json`，Phase 4 的 Live2D 要么靠远端模型，要么改成纯 Canvas 程序化绘制。

## 二·历史（m03927）：字 / 句 / 段 —— 三层认知结构

> 用户原话：「架构上确实应该修改，但是也需要让他学习到，之前学的那些是字，组合起来是句，再组合就是段。」

### 一、三层是什么

全部是 `NeuronNode`，用新字段 `kind` 区分：`char` / `sentence` / `paragraph`，句与段原文存 `text`。

|层|什么时候长出来|位置|上连|边权|样子|
|-|-|-|-|-|-|
|字 char|读到没学过的字|随机 / 最近邻旁边|——|——|蓝色小点|
|句 sentence|一句话读完（sent\_id 变或 flush）|句中字重心上方 2.2|连向句中**每一个字**|2.5|金色 ×1.75|
|段 paragraph|一篇课文读完|句节点重心上方 3.4|连向**每一颗句**|2.5|紫色 ×2.55|

**这不是语法分析** —— 引擎不知道主谓宾，只知道「这几个字在同一句话里出现过」。

### 二、引擎侧（`aha\_brain.py`）

* 新字段 `NeuronNode.kind` / `NeuronNode.text`，`to\_dict` / `from\_dict` 往返。
* `\_find\_closest\_node(..., kinds=None)` 加层过滤：建字节点只往字里找父节点。**理由**：句特征 = 句内字平均，余弦天然很高，不过滤会让整棵字枝挂到花心上。
* `\_link\_sentence` 重写：换篇先收上一段 → 换句先收上一句 → 累加本句的字。
* 新增 `\_mix\_features` / `\_mix\_position` / `\_close\_sentence` / `\_close\_paragraph` / `flush\_structure`（幂等）。
* `\_neighbors\_of(..., kinds=None)`：回答问题和主动开口都只看字层，句号段号不会跑进她嘴里。
* `\_sentence\_hits`：问句里出现整句原文 → 走句层回答 `原文 → 字、字`。
* `\_target\_spans` 先把 `\_QWORDS`（什么样 / 什么 / 怎么 / 哪里 …）换成分隔符 —— 修掉了「我是什么」被当成在问「什么」。
* `snapshot\_full` 节点行 9 → 11 列，`frame` 的 new\_nodes 7 → 9 列（末尾两层：kind / text）。

### 三、服务端（`aha\_server.py`）

* `char\_loop` / `api\_feed` 在 `not unit` 分支调 `engine.flush\_structure()`，把最后一句话和最后一段收掉。
* `api\_node` 返回 `kind` / `text`，悬停标题对句段直接用原文。

### 四、前端（`index.html`）

* `kindStyle(kind)` 纯函数：段 `{mul:2.55, hue:282}`、句 `{mul:1.75, hue:44}`、字返回 null（仍走 potColor 的电位色）。亮度仍随膜电位与放电走，所以她放电时句和段一起亮。
* `ingestFull` 读 `n\[9]/n\[10]`，`ingestFrame` 读 `n\[7]/n\[8]`。
* `renderTip` 对句段显示「句 / 段」徽标 + 原文（超 120 字截断），不再显示不存在的字形。
* 面板新增「· 句子」「· 段落」两行；**星云上依然一个字都不写**。

### 五、实测（`tools/\_hier\_demo.py`，空引擎喂 24 课 859 字）

`字 253 · 句 123 · 段 24 · 连线 2000`。句节点样例 `\[8] 第一课认识我们` / `\[21] 我是小鱼你是人`。

|问|修前|修后|
|-|-|-|
|你认识江吗|江 → 里、河、水|**江 → 水、河、川**|
|我是什么|？|**我 → 爱、们、是**|
|我爱我家是什么意思|？|**家 → 里、回、我**|
|爸爸妈妈爱我|——|**爸爸妈妈爱我我心里有你们 → 爸、妈、爱、我**|

### 六、验证与遗留

* `tools/\_hier\_test.py` → **HIER TEST OK (26 checks)**。
* 前端冒烟 `\_check\_html`（2419 行 / errors 0 / missing none）、`\_smoke\_fire` 全过。
* 离线 `\_compose\_test` / `\_desire\_test`（38）/ `\_truth\_test`（20）全过。
* **在线 11 套未跑** —— 用户要求关闭服务，留待下次启动后补。
* 存档里 330 颗星全是 `char`：句和段要等她下次读课文才长出来。

### 七、启停脚本（本轮新增）

`A:\\小鱼计划\\启动小鱼.bat`：chcp 65001 → cd → `PYTHONIOENCODING=utf-8` → 5 秒后自动开浏览器 → `python aha\_server.py --port 8000`。
`A:\\小鱼计划\\停止小鱼.bat`：按 8000 端口的 LISTENING PID taskkill。

\---

## 三、历史（m03809）：给她句子 —— 组词从「共现」变成「同句相邻」

> 用户原话：「那你再准备一些，让她先学如何用字组词！也就是先学组句子吧」

### 一、教材：12 课扩到 24 课（合计 859 汉字）

第一批 12 课（477 字）只教单词和短句。这一批补 12 课，按「句子长度 → 生活场景 → 小故事」递进（总字数不是严格递增，递进的是句子结构和篇幅）：

|课|字数|大意|
|-|-|-|
|课13 短句(一)|29|我认识你 / 水里有鱼 / 花开 / 把门打开|
|课14 短句(二)|27|天上有云 / 小鸟会飞 / 我们一起玩|
|课15 早上|21|我起床 / 洗脸刷牙 / 吃饭 / 去上学|
|课16 在做什么|31|妈妈做饭 / 爸爸看报 / 我写字|
|课17 天气变了|32|今天好热 / 风把树吹得摇晃|
|课18 小猫|29|小猫在睡觉 / 它的毛是白的|
|课19 小狗|27|小狗跑得快 / 它喜欢吃骨头|
|课20 种小树|26|我们种了一棵小树 / 我给它浇水|
|课21 儿歌|20|小星星 / 一闪一闪亮晶晶|
|课22 乌鸦喝水|50|乌鸦口渴 / 放石子 / 水升高|
|课23 三只小猪|42|三只小猪盖房子 / 狮子吹倒了草房子|
|课24 小马过河|38|小马要过河 / 松鼠说深 / 老牛说浅|

全部逐字注音（`江(jiāng)`），`strip\_pinyin` 在读文件时剥掉，只走节点的 `pinyin` 字段。顺带给课03 补了「江」—— 用户之前问「你认识江吗」，她答「？」，因为 24 课里真的没有这个字（「江」原来只在被归档的 `\_旧版/01\_自然.txt` 里）。

### 二、引擎：同一句里相邻的两个字连一条边

原来的「组词」是**空间巧合** —— 同一批投喂的字在三维空间里靠近，靠 `consolidate()` 随机连。所以「小」的邻居是「妈、大、就」，纯粹因为它们挨得近。

现在输入层给每个字带上「第几篇课的第几句」（`sent\_id`），引擎在 `learn()` 里把**同一句里相邻的两个字**连一条 `weight=1.2` 的边：

```python
def \_link\_sentence(self, meta, node\_id):
    sid = meta.get("sent\_id") or None
    if not sid or not node\_id:
        return None
    prev = self.\_sent\_ctx.get(sid)
    if prev is not None and prev != node\_id and prev in self.nodes:
        self.\_connect(prev, node\_id, weight=1.2)
    self.\_sent\_ctx\[sid] = node\_id
    if len(self.\_sent\_ctx) > 8:
        for k in list(self.\_sent\_ctx.keys())\[:-8]:
            self.\_sent\_ctx.pop(k, None)
```

* 边权 1.2 > `prune\_weight`（1.05）→ **属于主干，睡眠修剪不会动它**。
* 只记最近 8 句 —— 一本书读完上下文就该忘，不能拿第 1 句去连第 900 句。
* 句界是 `。！？!?；;` + 换行；**逗号不算**（逗号两边还是同一句话）。
* `sent\_id` 用「篇号:句号」而不是裸句号 —— 否则两篇课文的第 0 句会被当成同一句连起来。

### 三、改动清单

|位置|改动|
|-|-|
|`aha\_input.py` `\_SENT\_BREAK` / `\_sent\_map()`|新增。句末标点表 + 给每个字符标句子号|
|`aha\_input.py` `\_\_init\_\_`|`self.\_sent\_ids = \[]` / `self.\_doc\_no = 0`|
|`aha\_input.py` `\_load\_next\_text\_file`|两处读完课文后 `\_sent\_ids = \_sent\_map(text)` + `\_doc\_no += 1`|
|`aha\_input.py` `next\_char`|char / word 两种 unit 都带 `sent` / `doc`|
|`aha\_input.py` `feed\_char`|meta 加 `"sent\_id": "%d:%d"`|
|`aha\_brain.py` `\_sent\_ctx`|新增字段（`\_\_init\_\_`）|
|`aha\_brain.py` `\_link\_sentence()`|新增方法（插在 `learn` 之前）|
|`aha\_brain.py` `learn()`|`new\_node` 与 `recall` 两个 return 前各调一次 `\_link\_sentence`|

补丁脚本：`tools/\_patch\_sent1.py`（8 hunks）+ `tools/\_patch\_sent2.py`（4 hunks），每个锚点都 `assert s.count(old)==1`。

### 四、实测对比（空引擎各喂 859 字，`tools/\_sentence\_demo.py`）

|问|没有句子边|有句子边|
|-|-|-|
|你认识江吗|江 → 里、河、水|**江 → 水、河、川**|
|我是什么|我 → 是、爸、他|**我 → 爱、是、们**|
|小是什么|小 → 妈、大、就|**小 → 只、是、鱼**|
|你认识早吗|早 → 有、日、晚|**早 → 晚、上、穿**|
|鸟是什么|鸟 → 草、鱼|**鸟 → 只、三、飞**|
|你认识水吗|水 → 里、游、洗|**水 → 河、往、喝**|

「江」的前 5 个邻居：无句子边 `里(1.0)、河(0.8)、水(0.8)、步(0.8)`；有句子边 **`水(1.4)、河(1.3)、川(1.2)、田(1.2)`**。

连线数 **463 → 1006**（句子边占一半），节点都是 253。「小 → 只、是、鱼」里的「鱼」就是「小鱼」。

### 五、边界（如实说）

* **这不是语法**。引擎不知道主谓宾，只知道「这两个字在一句话里挨着出现过」。「水 → 河、往、喝」是共现，不是「水是一种液体」。
* 真实大脑里已有 1574 条边，新课文喂进去会再加约 550 条句子边，总量到 \~2100。253 个新字算下来平均度 8，离稠密还远。
* 课文改完就要重启服务（`.py` 改了），重启后 `hold` 与 `feed\_pause` 都不持久化 —— 已重新 pause，停在课02。要开新课，在 Web 课程下拉里选课13，点「▶ 上这一课」。

## 二·历史（m03667）：只要她的原始输出

> 用户原话：「输出的内容我感觉你还是加入了自己语句格式。我如果不想要这种格式，只想知道小鱼输出的原始内容。」

### 澄清：壳到底在哪

给他四个选项（只去前缀 / 换句式 / 都给结构 / 都保留），他选 **「壳和句式都换：只给原始节点链」**。

查出来一共有四层「格式」：

1. 硬前缀 `self.speak(text="小鱼：" + reply, kind="say", ids=fired\_ids)`（`aha\_brain.py` 的 `compose\_reply` 命中分支）
2. 我写的句式模板 `你问到了「%s」，我记得它连着「%s」，还连着「%s」。`
3. 迷茫句 `我不认识这个词，我的星云里没有它的光。` / 孤岛句 `我看到了「%s」，但它孤零零的……`
4. 主动开口还会随机抽四条人话模板（「我刚刚想起「A」。它旁边站着「B」，我就想跟你说一声。」等）

### 现在她「说」出来的只有三种形态

|形态|含义|
|-|-|
|`江 → 河、湖、海`|认得，且有连线|
|`江`|认得，但孤零零|
|`？`|星云里没有|

新增 `\_chain(self, topic, nbrs)`：`tname + " → " + "、".join(names)`，没有邻居就只给 `tname`。人称、动词、引号、句号、方括号全部删掉。

### 改动清单

|位置|改动|
|-|-|
|`aha\_brain.py` `\_chain`|新增（插在 `\_glyph\_index` 之前）|
|`aha\_brain.py` `compose\_reply`|三处出口全换成 `\_chain`：迷茫两处 → `？`，命中 → 链；`speak` 不再加任何前缀|
|`aha\_brain.py` `compose\_proactive`|四条人话模板 + 「颗星 / 教教我」分支整块删除，只留 `\_chain`；空图 → `？`|
|`aha\_brain.py` `\_topic\_score` 加权|多 span 全部加权（见下「主角 bug」）|
|`index.html` `chatPush`|删掉 `<i>小鱼</i>` / `<i>你</i>` 署名，节点里只剩一个正文文本节点；谁说的靠左右位置区分|
|`index.html` `chatSend`|断线不再替她说话 —— 那句「我这边断了一下，你再叫我一声。」是我写的，已删；错误只进左侧日志 + 输入框下方状态行|

补丁脚本：`tools/\_patch\_chain1.py`（6 hunks，带 `assert s.count(old)==1`）+ `ops\_edit\_file` 两处前端。

### 实测（新 job `pwsh-e1c78ce2e9e547ad`）

```
问 你认识江吗  -> 江 → 河、湖、海
问 海是什么    -> 海 → 河、江、湖
问 鱼在水里吗  -> 鱼 → 路、足、口
问 吗呢吧      -> ？          tone=焦虑
主动开口（话痨档）-> 晚 → 早、果
```

`/api/speech` 里 `kind=say` / `kind=proactive` 的 text 与返回的 `reply` 逐字相同，没有任何前缀。

### 顺带修掉的主角 bug

`\_target\_spans("鱼在水里吗")` = `\["鱼", "水里"]` —— 「水」「里」相邻且都不是虚词，被连成一个 span。旧代码 `target\_word = sorted(spans, key=lambda t: -len(t\[1]))\[0]\[1]` 取最长 = 「水里」，于是只有出现在「水里」里的字 +500，「鱼」反而没有 → 主角变成「里」，答出 `里 → 雨、鲸、门`。
改成 `if g and any(g in sp for \_p, sp in spans):`，所有实词片段里的字都加权，谁更该被说起交给度数决定。修后答 `鱼`。

### 回归

前端 11 / 离线 10 / 在线 11 = **32 套全绿**（`bash tools/\_regress\_all.sh` → `TOTAL pass=32 fail=0`）。
改了 5 套断言：`\_compose\_test.py`（B/D 组）、`\_io\_rebuild\_test.py`（B1/C1）、`\_desire\_test.py`（主动开口不带引号壳）、`\_desire\_live.py`（同上）、`\_chat\_e2e.py`（「日志里就是她说的原文」改成 `text == reply`）。

### 边界

**左侧意识流日志没动**：`\_MURMUR\_TEMPLATES` 40 多条内部呓语仍是散文（`呓语：……`）。它们不进对话气泡，只进左边那份履历。要一起换成链，也是一句话的改动。

## 二·历史（m03487）：课程拼音 —— 每个字都有读音

> 用户原话：「在小鱼的课程加上对应的拼音。」

### 为什么不能直接把拼音写进 txt

`aha\_input.py` 的 `next\_char()` 把**连续 ASCII 字母当成一个「词」**，走 `extract\_word\_feature()` 喂进大脑。若课文原样写 `江 jiang`，拼音会变成一堆新节点把词表塞满（`\_is\_cjk` 判否 → 走 word 分支）。所以注音必须在**读文件时剥掉**，只走节点的 `pinyin` 字段。

### 格式

`江(jiāng)` —— 半角/全角括号都认，括号内允许空格，声调落在 U+0100\~U+024F。

12 课全部重写带注音（`Input\_Files/`，标题行 + 生字行 + 例句逐字标注）：
课01 437B · 课02 432B · 课03 392B · 课04 350B · 课05 394B · 课06 434B · 课07 400B · 课08 350B · 课09 361B · 课10 427B · 课11 367B · 课12 358B。

### 四条链路的改动

|文件|改动|
|-|-|
|`aha\_input.py`|新增 `\_PYIN\_RE` + `strip\_pinyin(text)` → `(纯正文, {正文索引: 拼音})`；`\_load\_next\_text\_file` 两处读入后剥离；`next\_char()` 的 unit 带 `pinyin`；`feed\_char()` 递进 meta|
|`aha\_brain.py`|`NeuronNode` 加 `pinyin` 字段 + `to\_dict`/`from\_dict` 往返；`add\_new\_experience(..., pinyin=None)`；`learn()` 新建时带上，recall 时给老节点补读音|
|`aha\_server.py`|`/api/node/{id}` 返回 `pinyin`；`char\_loop` 的 `\_last\_char` 带 `pinyin`|
|`index.html`|悬停卡片字形右侧 `<span class="py">jiāng</span>`；面板「正在学」一行显示 `江 jiāng · 河流`|

**关键**：`strip\_pinyin` 返回的键是**剥离后正文的下标**，正好等于 `next\_char()` 里的 `idx = self.\_pos`，取用不用再算偏移。

`snapshot\_full()` / `frame()` 的列数**没动**（不加第 10 列），`\_spike\_wire.py` 的「9 列」断言不受影响；悬停时走 `/api/node` 拿拼音。

### 实测

* `/api/status` → `last\_char = {"glyph":"妈","pinyin":"mā","label":"亲属称谓","source":"deepseek"}`
* `/api/node/110` → `妈 mā`；`/api/node/54` → `鱼 yú`（**老节点，recall 时补上的**，证明补丁生效）
* 课01 整课验证：`我 wǒ` / `们 men` / `你 nǐ` / `她 tā` / `爸 bà` / `爱 ài`
* `\_pinyin\_test.py` → **27 checks**：剥离形态 / 索引对齐 / 无注音不动 / 60 次 `next\_char` **不出一个 `kind=="word"`** / 每字带拼音 / 新建带拼音 / recall 补 / 存档往返 / `feed\_char` 递进

### 边界（如实说明）

* **对话里临时查的字没有拼音**：`\_learn\_unknown\_in\_text` / `\_lookup\_in\_background` 走 `\_unit\_for\_glyph()`，那条路拿不到注音（只有课文里才标了音）。悬停这些星拼音为空。

## 二·历史（m03372）：气泡零修饰 —— 她说的一个字都不改

> 用户原话：「关键修正一下，小鱼对话中，只能出现小鱼给出的原始文本，禁止使用任何修饰」

### 删掉的东西（`index.html`）

|位置|原来|现在|
|-|-|-|
|`stripSay()`|正则剥掉 `小鱼：` / `呓语：` / `\[主动]` / `\[回应]` 前缀|**整个函数删除**|
|`chatPush(who, text, opt)`|渲染 `<em>\[主动]</em>` / `<em>\[回应]</em>` 徽章|徽章 DOM 与 `opt.tag` 一起删|
|`syncProactive` / `pushSpeech`|`stripSay(it.text)` + `{tag:"主动"}`|`chatPush("fish", it.text)` 原样传|
|`chatSend` 成功分支|`stripSay(r.reply)` + `{tag:"回应"}`|`chatPush("fish", r.reply)` 原样传|
|CSS|`.bub i .tag` / `.tag.pro` / `.tag.rep`|三条全删|
|等待态|`<i>小鱼</i>……`|不挂署名（`if (!opt.think)`），只留三个点|
|`opt.note` 分支|可往气泡追加 `<span class="note">`|删（没人调用，留着就是零修饰的口子）|

**保留的**：气泡左侧的 `<i>小鱼</i>` / `<i>你</i>` 署名 —— 它是气泡归属的 UI 元信息，不属于她的文本。

### 后果（如实说明）

* 主动开口与被动回应在气泡里**看不出区别**，只能靠上下文。这是 m03124 第三条「标 \[主动]」的让步。
* 前端不再做任何字符串清洗：引擎给 `呓语：……`，屏幕就显示 `呓语：……`。清洗责任交给引擎。

### 验证（`tools/\_smoke\_desire\_tail.js`，逐字相等断言）

新增 `bubSay(n)` 只取气泡里的**正文文本节点**（跳过 `<i>` 署名），然后：

* `chatPush("fish", "小鱼：你问到了「江」。")` → `bubSay === 原文`（连名字前缀都不许删）
* 传 `{tag:"主动"}` → `bubTag === ""`（调用方塞也不渲染）
* `pushSpeech(\[{kind:"proactive", text:"呓语：我刚刚想起「江」。…"}])` → `bubSay === 原文`（连「呓语：」都保留）
* `resetSpeech(hist)` 首帧回填 3 条 → `bubSay === "第3句"` / `"第5句"`
* `chatSend` 回复 → `bubSay === "你问到了「江」，我记得它连着「河」。"`，且正文不含 `\[`
* 等待态 → 没有 `<i>` 子节点、正文 `……`
* 反向断言：`!/function stripSay/`、`page.indexOf(".bub i .tag") < 0`、`page.indexOf("opt.tag") < 0`

### 顺带修掉的 flaky：`tools/\_prune\_real.py` 的主干判据

全量回归时它 FAIL：`误删了主干边 2 \[(82,146),(82,103)] / 删了候选池以外的边 2`。

**不是引擎 bug**：那两条边权重都是 `1.0`（弱边），入睡前 `82` 在核心集里（度数 14）所以被测试当成「主干」；但 `\_prune\_synapses` **每批重算核心集**，睡眠里 REM 连出新边会改变度数排名，`82` 掉出核心 → 它们在后面某一批里成了合法候选。

修法（测试侧）：主干拆成两类 ——

* `hard\_keep`：权重 > `prune\_weight` 的边。权重只增不减、判据只读权重 → **跨帧严格不变量**，做断言。
* `soft\_keep`：弱边但连着核心。核心集漂移后会失去豁免 → 只统计不报错。

断言从「不在候选池快照里」改成「权重 > prune\_weight 的边一条都不许少」。实测三次稳定：硬主干 1082 全部保住、软豁免 160、删 55\~56 条全是弱边、`\_conn\_index` 三数组一致。

## 二·历史（m03124）：说话的欲望 —— 她开口不是因为被点名

> 用户原话：「小鱼必须有『说话的欲望』。她说话不是因为被代码强制，而是因为她『想』说。」

### 1\. 欲望怎么涨、怎么落（`aha\_brain.py`）

全局量 `speech\_desire`（0\~100）。三个进水口，一个出水口：

|事件|增量|说明|
|-|-|-|
|自发放电（背景电活动的 Aha）|`desire\_per\_aha = 3.2` × `mood.gain`|`\_update\_desire` 读 `stats\["self\_aha"]` 增量|
|梦里连出新线|`desire\_per\_dream\_link = 7.0` × `gain`|读 `dream\_links` 增量|
|星云信息熵跳变（形状变了）|`min(20, 熵变 × 26)` × `gain`，熵变 ≥ 0.05 才算|`\_entropy\_now()` 每 1 秒算 6×6×6 体素香农熵|
|说出口|**归零**|`speak()` 里 `kind in ("say","proactive")` 才清|
|久不说|`-= 0.9 × mood.decay × dt`|同上|

关键设计：**只有 `say` / `proactive` 清零**。`glyph\_birth`、`birth` 这些内部呓语不清 —— 否则每学一个字就爽一次，欲望永远涨不起来。

### 2\. 长效多巴胺（`tonic\_dopamine`）

说出口那一刻注入 `dopamine\_gain(6.0) × mood.dopa`，上限 `dopamine\_cap = 14.0`，按 `tau = 15.0s` 指数回落。它直接叠进 E 的稳态目标：

```python
self.tone\_excitation += ((self.target\_safety + drive + self.bg\_drift + self.tonic\_dopamine)
                         - self.tone\_excitation) \* k\_e
```

实测把 E 基线从 122.79 抬到 127.09 —— 「倾诉完很爽」的物理表现。

### 3\. 五档「对话兴奋回馈」滑块

`PARAM\_SPECS` 第 6 个旋钮 `talk\_mood`，`TALK\_MOODS` 五档：

|档|gain|decay|开口阈值|dopa|最短间隔|
|-|-|-|-|-|-|
|高冷|0.35|1.40|96|0.35|40s|
|安静|0.70|1.15|88|0.65|26s|
|正常|1.00|1.00|80|1.00|18s|
|激动|1.60|0.75|68|1.50|11s|
|话痨|2.40|0.50|55|2.00|6s|

前端 `fmtVal` 认出 `spec.options` 后显示中文档名而不是数字。

### 4\. 主动开口说什么（`compose\_proactive`）

**零网络请求**。从有 `glyph` 的节点里挑主角（65% 偏向 90 秒内刚亮过的），`\_neighbors\_of(id, 2)` 取邻居，四选一句型：

* 「我刚刚想起「A」。它旁边站着「B」，我就想跟你说一声。」
* 「「A」亮了一下。我顺着一根线摸过去，是「B」。」
* 「「A」和「B」是一伙的。这件事我好像一直没告诉过你。」
* 22% 概率走报数款：「我这里现在有 N 颗星了。我数到「A」的时候，它亮了一下。」

### 5\. 统一出口：全部进右侧气泡

`pushSpeech` 看到 `kind === "proactive"` 就同时 `chatPush("fish", stripSay(text), {tag:"主动"})`；`chatSend` 的回话标 `\[回应]`。左栏「意识流日志」照留（用户要的是同步，不是搬家）。首帧 `resetSpeech` 只补最近 3 条主动气泡，避免重连刷屏。

### 6\. 一个真 bug：读档后三个增量游标没对齐

`\_last\_aha\_seen` / `\_last\_self\_aha\_seen` / `\_last\_dream\_link\_seen` 初始化都是 0，而 `load\_state` 会把 `stats\["aha"]`（3227）与 `stats\["self\_aha"]`（2005）恢复进来。后果：

* 第一帧增量 3227 → 亢奋窗口瞬间塞满 → **一启动就深度睡眠并白剪线**（`sleep\_reason`「顿悟频率 50.1 次/秒（10 秒 501 次）」）；
* `\_update\_desire` 第一帧白送 30 点欲望。

修法（`tools/\_patch\_seen\_align.py`，插在 `load\_state` 的 `self.pressure = 0.0` 之后）：

```python
self.\_last\_aha\_seen = int(self.stats.get("aha", 0))
self.\_last\_self\_aha\_seen = int(self.stats.get("self\_aha", 0))
self.\_last\_dream\_link\_seen = int(self.dream\_links)
```

注意 `aha\_brain.py` 是 **CRLF**：`io.open(P, "r", encoding="utf-8", newline="")` 读，锚点里带 `\\r\\n`。

### 7\. 实测

|项|值|
|-|-|
|起服 uptime 0.0s 时欲望|**0.0**（修前 30）|
|起服 8 秒欲望|23.0，单次最大跳变 6.0|
|话痨档开口耗时|8\~37 秒|
|主动开口样本|「「前」和「动」是一伙的。这件事我好像一直没告诉过你。」/「我刚刚想起「四」。它旁边站着「爸」，我就想跟你说一声。」|
|说完欲望|60.2 → 7.5|
|多巴胺|11.0 \~ 13.63|
|E|122.79 → 127.09|
|回应样本|「你问到了「江」，我记得它连着「河」「湖」，还连着「海」。」|

**已知物理（不是 bug）**：正常档从 0 涨到 80 约 35\~40 秒；高冷档 gain 0.35 → 1.12/s 涨 < 1.26/s 衰减，**净负，几乎不会主动开口**（除非熵跳变）。

## 三、m03006：焦点环美化 —— 赛博青雷达锁定框

用户原话开头：「前端 3D 星云的'焦点环（Focus Ring）'视觉效果太粗糙，极大地破坏了星云的美感。」五条：① 半径缩到节点的 20%\~30%；② 废弃实心贴图，改细线 + 辉光 + 两三个同心环反向旋转；③ 纯黄改赛博青或 #FFD700，半透明全息感；④ 不要心脏起搏器式一直闪，而是快速收缩锁定 -> 闪 2\~3 次 -> 1 秒内淡出；⑤ 别抢星点连线的戏，它是定位符不是聚光灯。

### 真根因：Three 的 Sprite scale 是**世界单位**，不是屏幕像素

旧版 `ringSprite.scale.setScalar(15 + 10 \* plq)`。看起来「15」很小，但在 z=190、fov=62° 的相机下，屏幕半径 = `R \* (h/2) / tan(fov/2) / z` ≈ `R \* 3.5px` —— 15\~25 世界单位就是 **52\~87px**。

同一颗星的节点本体：`gl\_PointSize = aSize \* uPR \* (420.0 / max(-mv.z, 1.0))`，`siz ≈ 2.5`、`z≈190` → 屏幕直径只有 **5.5px**。

**环比它标注的东西大了近十倍**，还带一块 1.9 倍半径的实心光晕 —— 这才是「极大破坏美感」的物理原因，不是颜色问题。

### 1\. 生命周期状态机（`index.html` 的 `focusRingPhase(age)`）

```js
var RING\_LIFE = 2.4;              // 整条命 2.4 秒
var RING\_FLASH = 3;
var RING\_RGB = "120,245,255";     // 赛博青

lock = clamp(age / 0.32, 0, 1);                              // ① 收缩锁定 0.32s
k = 1.85 - 0.85 \* (1 - Math.pow(1 - lock, 3));               //    1.85 -> 1.0 缓出
fl = 0.5 + 0.5 \* Math.cos((age - 0.32) \* 2π / 0.30);         // ② 闪 3 下（0.30s 一个来回）
fade = clamp((RING\_LIFE - age) / 1.0, 0, 1);                 // ③ 最后 1 秒线性淡出
a = (0.42 + 0.30 \* fl) \* fade;
```

超过 2.4 秒直接返回 `null`，环不再绘制 —— **彻底不是「一直呼吸」了**。峰值 alpha 只有 0.72，是半透明的。

### 2\. 三层同心细环 + 两段反向扫掠弧

|层|半径|线宽|alpha|备注|
|-|-|-|-|-|
|外环|1.85 r0|3.2 + 0.8|0.10 / 0.30|两遍描边：粗而淡 + 细而亮，假辉光|
|中弧 A|1.38 r0|1.1|0.55|顺时针扫，`rotation.z = age \* 2.1`|
|中弧 B|1.38 r0|1.1|0.38|逆时针扫，`age \* -1.7`|
|内环|1.00 r0|2.6 + 0.9|0.20 / 0.80|贴住节点|

`r0 = max(4.5, 5.0 \* scale) \* k` —— 典型 **11px**，旧版是 22\~42px，缩到 **26%**，正好落在用户要的 20%\~30% 区间。

锁定期额外甩一圈从 2.4 倍向内收的冲击波（`1 + 1.4 \* wv`，alpha `0.45 \* wv`）。

**辉光没用 `ctx.shadowBlur`** —— 那个每帧要给整条路径做一次高斯，画 4 条环就是 4 次。改成「粗而淡 + 细而亮」两遍描边，视觉上几乎一样，成本是两次 `arc()`。

### 3\. Three 版：Sprite 贴图 → Group + 4 条 `THREE.Line`

```js
mkRingLine(1.00, 0, 6.28318, 64, 0);       // 内环
mkRingLine(1.85, 0, 6.28318, 72, 0);       // 外环
mkRingLine(1.38, 0.15, 1.90, 20, 2.1);     // 中弧 A
mkRingLine(1.38, 3.30, 5.05, 20, -1.7);    // 中弧 B
```

材料 `LineBasicMaterial({color: 0x78f5ff, transparent, depthWrite: false, blending: AdditiveBlending})`；每帧 `ringGrp.quaternion.copy(camera.quaternion)` 做 billboard，永远正对相机。

`scale.setScalar(1.55 \* k)` —— 屏幕半径 `1.55 \* 3.5 ≈ 5.4px`，节点直径 5.5px，**环正好是节点的一倍多一点**。旧版是 52\~87px。

整个构造包在 try/catch 里，`ringGrp = null` 兜底（老 CDN 的 Three 没有 `BufferGeometry.setFromPoints` 时不至于炸掉整个渲染器）。

### 4\. 「每次提问重放一遍」的触发判据（`updateArb`）

```js
var relit = (f.id !== ARB.focusId) || (fleft > ARB.focusLeft + 0.05);
if (relit) ARB.focusAt = Date.now();
```

换节点、或后端 `arb\_focus()` 把 TTL 顶回满值 —— 这两种情况才重放动画。阈值 **0.05 不是 0.5**：两次快照间隔 0.1 秒，TTL 刷新时 `left` 只跳 0.1\~0.2，用 0.5 会漏判（第一版就是这么写错的，被 `\_smoke\_ring.js` 抓出来）。

焦点 TTL 到点后 `arb\_snapshot` 返回空 focus，`focusId` 归 null，环立即隐藏。

## 三、本轮实测与验证

|项|值|
|-|-|
|Canvas 环半径|11.0px（旧 41.8px，缩到 **26.3%**）|
|Three 环半径|1.55 世界单位 ≈ 5.4px（旧 52\~87px）|
|整条命|2.4s = 锁定 0.32 + 闪烁 0.9 + 淡出 1.0+|
|峰值 alpha|0.72（旧 0.90，且常驻不灭）|
|收缩单调性|0 -> 0.32s 内 k 从 1.85 单调降到 1.0|
|闪烁次数|闪烁区 3 个低谷，之后 `fl` 归零不再心跳|

新增测试 `tools/\_smoke\_ring.js`（`head -n 261 tools/\_smoke\_feed\_head.js` + `\_smoke\_ring\_tail.js`）→ **RING SMOKE OK (38 checks)**：状态机边界（负数/LIFE/刚好 LIFE 全 null）、1.85→1.0 单调、闪 3 下、最后 1 秒 alpha 单调降到 0.008、全程 alpha ≤ 0.75、`RING\_RGB` 是青不是黄、源码里 `ringSprite` / `255,214,120` / `0xffd678` 全部绝迹、`mkRingLine` 恰好 4 次、`focusAt` 四种重放场景。

全量回归：前端 10 套 + 离线 8 套 + 在线 9 套 + `py\_compile`，**全绿**。

### 顺手修的两个测试坑

1. `tools/\_smoke\_arb.js` 里有一条旧断言 `code.indexOf("ringSprite") >= 0`（证明焦点环存在）。环换了实现，断言改成 `ringGrp >= 0 \&\& ringSprite < 0`，并补了 `focusRingPhase` / `ARB.focusAt` 两条。源文件是 `tools/\_smoke\_arb\_tail.js`，改完要重新 `head -n 261 ... > \_smoke\_arb.js \&\& cat tail >> ...`。
2. `tools/\_feedall\_gate.py` 第 4 组断言 `teach\_deepseek >= 之前 + 1` 是 flaky 的 —— 步骤 2 那次 `/teach` 偶尔走 local 降级（网络抖动），本来就不该涨。改成「计数不倒退」+「只有 `source == deepseek` 时才要求 +1」，连跑 3 次稳定 10 checks。

## 四、m02813：背景电活动 + 阈电位 + 放电配色 + 梦境涌现

用户四条：① 空闲态不要只加微弱底噪，A2 要按 5\~10 Hz 对全网施加 5\~10 点的局部电位；② 未达阈值只是微弱闪烁，累加到阈值就强制放一次电、计一次 Aha，**但不算外部输入的 Aha**；③ 前端颜色按新机制映射：深蓝 -> 浅青，越过阈值那一瞬爆亮粉紫红；④ 睡眠时不能停，梦里放大，连片无规律闪烁并随机连出几条奇妙连线。

### 1\. 后端（`aha\_brain.py`，补丁 `tools/\_patch\_spike1.py` / `\_spike2.py` / `\_spike3.py`）

新增模块级 `\_poisson(lam)`：10Hz 主循环下每帧 lam 常常小于 1，用 `int(lam)` 会永远取 0，画面上一颗星都不闪。

`AhaEngine.\_\_init\_\_` 新字段：

```python
self.spike\_hz = 8.0              # 背景电活动频率（用户要的 5\~10Hz）
self.spike\_cover = 0.017         # 每个脉冲命中全网节点的比例（与节点数无关）
self.spike\_amp\_min = 5.0
self.spike\_amp\_max = 10.0
self.spike\_gain = 1.0            # 造物主倍率，0 = 彻底静默
self.spike\_bunch = 0.55          # 簇状：55% 继续打同一颗星
self.spike\_total = 0
self.spike\_fires = 0
self.dream\_spike\_rate = 14.0     # 梦里每秒 14 个脉冲
self.dream\_spike\_amp\_min = 36.0
self.dream\_spike\_amp\_max = 62.0
self.dream\_spike\_fires = 0
```

`self.stats` 新增 `"self\_aha": 0`。**绝对不能并进 `stats\["aha"]`** —— `\_update\_biorhythm` 是靠 `stats\["aha"]` 的增量喂 `aha\_times` 的，自发放电混进去她会把自己判成亢奋然后永远睡回去醒不来。

新增 `\_spike\_step(self, dt, now, dream=False)`：

* 清醒：`lam = spike\_hz \* spike\_gain \* dt \* spike\_cover \* n\_nodes`，幅度 5\~10
* 梦境：`lam = dream\_spike\_rate \* dt`，幅度 36\~62（单次直接跨 threshold=50）
* `k = \_poisson(lam)`，上限 400（一帧补 400 个脉冲 = 瞬间癫痫）
* 簇状：`focus\_id` 有 55% 概率继续命中同一颗星。**没有它，单次 +7.5 在"衰减 5%/秒 + 稳态 20"的网上永远够不到 50**，自发放电只是理论值。成簇不改变期望（不推过载），但拉出长尾，偶尔一颗星连挨 5 下就跨阈值。
* 梦里同帧有 2 个以上节点放电时 `\_connect(a, b, weight=0.4)` —— 用户要的「随机连出几条奇妙的连线」。**清醒态不连**，白天的连线必须由 consolidate / awake\_think 决定，否则底噪替她做决定，树会长歪。

`tick()` 接线（**位置是关键**）：

```python
self.update\_homeostasis(dt)
self.\_update\_biorhythm(dt, now)
self.\_spike\_step(dt, now, dream=bool(self.sleeping))
if self.sleeping: self.\_dream\_step(dt, now)
```

放在 `\_update\_biorhythm` 之后，是为了让睡眠态的 drain（每帧 x0.80）先跑、再注入，注入的电位不会被同帧削掉八成。

观测接口：`physiology()` 增 `spike\_hz / spike\_cover / spike\_total / spike\_fires / self\_aha / dream\_spike\_rate / dream\_spike\_fires`；`snapshot\_full()` 节点行加第 9 列阈电位；`frame()` 的 `new\_nodes` 加第 7 列阈电位，并新增 `"fired": \[\[id, age秒], ...]`（只推最近 1.2 秒内放过电的）。

### 2\. 前端（`index.html`，补丁 `tools/\_patch\_fx1.py` / `\_fx2.py` / `\_fx3.py`）

新增纯函数 `potColor(act, th, fireAge)`：

```js
var norm = clamp(act / th, 0, 1);
var t = Math.pow(norm, 0.7);        // 节点常驻 20%\~40%，线性会把它们全压在最暗一档
var hue = 222 - 37 \* t;             // 222 深蓝 -> 185 青
var lum = 0.14 + 0.50 \* t;
if (f > 0) { hue += (338 - hue) \* f; lum += (0.84 - lum) \* f; }   // 放电 -> 338 亮粉，途经 250 紫
```

`sprite(hue, lum)` 改成按亮度取档，并对色相（10 度一档）、亮度（3 档）量化 —— 全屏最多 36x3=108 张缓存。不量化的话每个节点电位都不同，一帧能生成上百张 canvas，直接卡死。

Canvas 与 Three 两套渲染器的节点、连线颜色都改走 `potColor`；放电时节点鼓一圈（`1 + 0.85 \* f`），并且能穿透睡眠态的压暗（`dimx = SLEEP.dim + (1-SLEEP.dim) \* min(1, f\*1.5)`）。

面板新增两行读数：「自发放电」（`self\_aha`）、「微型脉冲」（`spike\_total / spike\_fires`），都带 tooltip 说明它们不算顿悟。

## 三、实测数字

### 离线（`tools/\_spike\_test.py`，150 节点）

|阶段|mean|自发放电|说明|
|-|-|-|-|
|warm 10s|11.7|0.40/s|冷启动爬坡|
|awake 60s|16.6|0.53/s|sleeping=False，不再自己睡着|
|dream 30s|7.6|1.67/s|max 96.3，REM 连片闪烁|

`stats.aha` 全程 0 ✓（自发放电没污染顿悟计数）。

### 真机（243 节点，静息 60 秒）

|t|mean|E|I|脉冲|自发放电|sleeping|
|-|-|-|-|-|-|-|
|0s|15.60|116.11|108.46|4186|209|False|
|30s|15.31|114.95|107.20|5099|234|False|
|60s|14.76|114.06|106.40|6008|268|False|

* 脉冲 **30.3/s**（243 x 8Hz x 0.017 = 33，吻合）
* 自发放电 **1.00/s** —— 全网每秒一次，正是「偶尔一颗星越过阈值爆亮」
* `aha\_rate` 恒 0.00、`aha` 停在 3084（没有外部输入）→ **自发放电完全没污染顿悟计数**
* 60 秒没睡，mean 稳定在阈值的 30% 左右

## 五、测试矩阵（55 套全绿）

> 一键全跑：`bash tools/\_regress\_all.sh`（失败时先 grep `\[FAIL]` 再打 `tail -n 20`）。分组：前端 17 / 离线 21 / 在线 17 = \*\*55 套\*\*。下表按历史累积列出主要套件。

|套|结果|
|-|-|
|`\_check\_html.js`|script#1 OK (2503 行) / errors 0 / missing dom ids (none)|
|`\_smoke\_dom.js`|SMOKE OK|
|`\_smoke\_console.js`|CONSOLE SMOKE OK|
|`\_smoke\_g.js`|SMOKE-G OK|
|`\_smoke\_feed.js`|FEED SMOKE OK|
|`\_smoke\_arb.js`|ARB SMOKE OK|
|`\_smoke\_chat.js`|CHAT SMOKE OK|
|`\_smoke\_course.js`|COURSE SMOKE OK|
|`\_smoke\_fire.js`|**FIRE SMOKE OK (31 checks)** 配色 / 阈值 / 放电事件 / 缓存量化 / 面板|
|`\_smoke\_ring.js`|**RING SMOKE OK (38 checks)** 收缩锁定 / 闪 3 下 / 淡出 / 赛博青 / 11.0px|
|`\_smoke\_desire.js`|**DESIRE SMOKE OK** 欲望条 / **气泡逐字原样·零修饰** / 五档文字 / 首帧回填 3 条|
|`\_truth\_test.py`|TRUTH TEST OK|
|`\_teach\_verdict\_test.py`|TEACH VERDICT TEST OK|
|`\_config\_test.py`|CONFIG TEST OK|
|`\_biorhythm\_test.py`|27 checks|
|`\_compose\_test.py`|18 ok|
|`\_io\_rebuild\_test.py`|13 ok|
|`\_course\_test.py`|18 checks|
|`\_prune\_real.py`|PRUNE REAL OK|
|`\_pinyin\_test.py`|**PINYIN TEST OK (27 checks)** 剥离 / 索引对齐 / 不进特征 / 绑节点|
|`\_pinyin\_live.py`|**PINYIN LIVE OK (8 checks)** 课程字有音 / 对话字清空 / 恢复后又回来|
|`\_sentence\_test.py`|**SENTENCE TEST OK (17 checks)** 句子号切分 / unit 带 sent / 同句连边 / 跨句不连 / 无 sent\_id 不连 / 上下文只留 8 句|
|`\_spike\_test.py`|SPIKE TEST DONE（离线物理）|
|`\_spike\_wire.py`|**SPIKE WIRE OK**（9 列 / fired / 稳态）|
|`\_spike\_steady.py`|60 秒稳态观察|
|`\_e2e.py`|ALL DONE（WS 9.6 Hz）|
|`\_console\_test.py`|ALL PASSED|
|`\_g\_e2e.py`|G/E2E OK|
|`\_g\_ws.py`|WS OK|
|`\_arb\_e2e.py`|32 checks|
|`\_focus\_check.py`|8 checks|
|`\_feedall\_gate.py`|10 checks|
|`\_chat\_e2e.py`|20 ok|
|`\_io\_live\_test.py`|9 ok|
|`\_desire\_test.py`|**38 checks** 欲望涨落 / 多巴胺 / 熵 / 读档游标对齐|
|`\_desire\_boot.py`|**6 checks** 起服 12 秒内无白送（uptime 0.0s → 欲望 0.0）|
|`\_desire\_live.py`|**23 checks** 话痨档开口 / 回应 / 多巴胺抬 E|
|`\_kdtree\_test.py`|15 checks（5000 点 knn **24.7x**）|
|`\_seed\_test.py`|26 checks（918 字 / 1101 条先天边 / 江-水 5.48）|
|`\_concept\_test.py`|28 checks（二阶概念节点）|
|`\_cell\_test.py`|CELL TEST OK (21 checks) 钙波 / 可逆脱敏|
|`\_region\_test.py`|REGION TEST OK (45 checks) 海马体 / 杏仁核 / 基底节 / 脊髓|
|`\_smoke\_sup.js`|**SUP SMOKE OK** 折叠卡片 / 开关 / 读数 / POST 防抖|
|`\_supervise\_test.py`|**SUPERVISE TEST OK**（32 个 OK）场强折算 / 浮动 / 固化 / 自指环 / 无 if 分支|
|`\_box\_insight.py`|BOX INSIGHT OK（到站互撞出 insight）|
|`\_box\_live.py`|BOX LIVE OK (11 checks)|
|`\_region\_live.py`|REGION LIVE OK (17 checks)|
|`\_supervise\_live.py`|**SUPERVISE LIVE OK** 真调 DeepSeek 裁决 / 开关归零 / 闸门|
|`\_smoke\_p2.js`|**P2 SMOKE OK** 分区 / 吸积盘 / 流星 / 点击放大|
|`\_smoke\_p3.js`|**P3 SMOKE OK（40 项）** 四区网格 / 日志搬家 / 顶栏指标 / 翻转|
|`\_flight\_test.py`|FLIGHT TEST OK (22 ok) 在途信号|
|`\_box\_test.py`|BOX TEST OK (34 checks) 黑箱 + 工作记忆|
|`\_p2\_live.py`|P2 LIVE OK|
|`\_smoke\_p4.js`|**P4 SMOKE OK（约 60 断言）** 具身无贴图 / 躯体读数 / 优化框只提建议不自动应用|
|`\_smoke\_spin.js`|**SPIN SMOKE OK（32 项）** 巡览默认关 / 按时间推进 / 拖拽暂停 / 松手缓 1.2s / 聚焦暂停 / 只动 yaw|
|`\_smoke\_power.js`|**POWER SMOKE OK（44 项）** 关闭按钮两道确认 / 遮罩 / 关机后不重连 / 失败复原|
|`\_spinal\_test.py`|**SPINAL TEST OK (24 checks)** 伤害感受器 / 反射弧 / 威胁推高 noci|
|`\_optimize\_test.py`|**OPTIMIZE TEST OK (22 checks)** 建议洗白 / 越界钳制 / 源码红线|
|`\_p4\_live.py`|**P4 LIVE OK (20 checks)** 真机 body 上屏 / 真调 DeepSeek 出建议 / 一个字都没改|
|`\_v4\_accept.py`|**V4 ACCEPT OK (25 items)** 蓝图四阶段逐项验收：代码符号 + 真机读数 + 前端实现|

## 五、本轮踩到的坑

1. **虚拟时钟必须连节点创建时间一起虚拟化**。测试用 `t0=1000.0` 递增，但 `NeuronNode.\_\_init\_\_` 的 `now=time.time()` 是真实时间（1.7e9）→ `last\_fired\_time` 仍是天文数字 → `elapsed` 为负 → 永远处于绝对不应期，一次都放不出电；`tick\_decay` 的 dt 为负直接 return，节点根本不衰减。修法：在 `AhaEngine()` 之前 `AB.time = FakeClock(...)`。
2. **`\_prune\_real.py` 的断言要改**。m02813 之后睡眠里的 REM 会随机连出新边，`after >= before` 不再成立（实测 1062 -> 1062，删 4 条但净增 0）。改成看 `prune\_total > 0` 且「候选池里确实有边消失」。
**第二次翻车（m03372）**：拿入睡前的核心集快照算「主干」也不成立 —— 核心集是每批重算的，REM 连边会让节点掉出核心。只有「权重 > `prune\_weight`」是跨帧不变量。
3. **稳态必须压在过载线以下**。`overload\_per\_node = 25.0`，`hot\_raw = global\_excitation >= line \* 0.90` → 每节点均值上限 22.5。第一版 cover=0.034 稳态 41，60 秒就触发 `hot\_raw` 睡死；降到 0.017（稳态 20.4）才稳。
4. **`sprite` 缓存必须量化**。电位每个节点都不同，不量化一帧能生成上百张 canvas。
5. **`ops\_write\_file` / python `open(...,"w")` 偶发 `PermissionError`**，但 `ops\_edit\_file`（原生 CAS）能写 —— 遇到就换原生工具，别硬试。
6. **`learn\_ready()` 在全局空闲时会挡 2.6 秒恢复倒计时**。刚跑过 `/teach` 的测试紧接着调 `/api/feed\_all` 会拿到 `ok=False`，看着像坏了。测试要先轮询 `/api/arbiter` 等 `learn\_ready`（`\_feedall\_gate.py` 第 1 组已加）。
7. **从存档恢复后，任何「读累计计数算增量」的游标都必须对齐**（在 `load\_state` 里补），否则第一帧会被误判成极端事件：亢奋入睡 + 欲望白送。
8. **新增参数旋钮会让 `\_console\_test.py` 的「5 个参数」断言失败** —— 加 `talk\_mood` 时同步改成 6 个并检查 key。
9. **生字池会枯竭**。`\_io\_live\_test.py` 原来那 19 个化学元素字被前面几轮测试全学完了，重跑报 `找到一个没学过的字 None`。改成元素字 + `range(0x9E00, 0x9E80)` 生僻段，够深。`\_chat\_e2e.py` 的 16 个元素字后来也全被学完（报 `候选生僻字全被学会了`），同一个修法扩到 `range(0x9E00, 0x9F00)`。
10. **`ops\_edit\_file` 的两个 edit 不许匹配同一行**。想「插入新节 + 改原标题」必须合成一个 edit（用上下文行当锚点），否则报 `EDIT\_CONFLICT: Edits overlap in the original file`。
11. **删 CSS 块要连缩进一起匹配**。`.bub i .tag` 三条前面是两个空格，第一次漏了缩进直接 `EDIT\_CONFLICT`。
12. **注音不能留在正文里**。`next\_char()` 把连续 ASCII 当词学，拼音直接写进课文会变成几十个 `kind="word"` 的节点。必须 `strip\_pinyin` 剥掉，只走 `pinyin` 字段。
13. **`strip\_pinyin` 的键必须按剥离后的正文对齐**，否则 `\_pos` 与拼音表错位，屏幕上会显示别人字的读音。
14. **`dict.update()` 不删旧键**。`\_last\_char` 是三处共用的同一个 dict，课程路径写 `pinyin`、对话路径不写 → 面板显示上一个字的读音（实测「鋨」显示了「kè」）。拿不到值的字段必须显式写 `""`。
15. **气泡里不许替她说话**。`chatSend` 断线时原来 push 一句「我这边断了一下，你再叫我一声。」—— 那是我写的句子，屏幕上会当成她说的。改成错误只走左侧日志 + 输入框下方状态行，气泡里只剩她的原文。
16. **`\_target\_spans` 会把相邻实词连成一个 span**（「鱼在水里吗」→ `\["鱼","水里"]`），只给「最长 span」加权会让主角跑到「里」上。多 span 要全部加权，谁被说起交给度数。
17. **测试自己开的开关必须自己关**。`\_feedall\_gate.py` 调 `/api/feed\_pause {"paused": true}` 后没恢复，后面依赖投喂的套件全被饿死（`pinyin\_live` 报「60 秒没等到课程字」，但其实是 `paused: true`）。全量回归的隐藏状态污染比单个断言难查得多。
18. **`String.raw` 挡不住两层解析**。补丁脚本里写 `u"…\\n\\r"`，JS 原样落盘后**被 Python 执行时**又把 `\\n` 解析成真换行，写进目标文件就成了跨行字符串 → `SyntaxError: unterminated string literal`（`aha\_input.py` 的 `\_SENT\_BREAK` 就是这样炸的）。要构造含换行的常量，用 `chr(10)` / `chr(13)` 拼，别在补丁脚本的字符串字面量里写转义。
19. **`Input\_Files` 的课文不能直接用 python `open(...,"w")` 改**（`PermissionError: \[Errno 13] Permission denied`），哪怕同一轮里刚写过 `tools/` 下的文件成功了。一律用 `ops\_write\_file`（先 `ops\_stat` 拿 revision）。
20. **句子边不能跨句，也不能跨篇**。`\_sent\_map` 遇到 `。！？!?；;` 和换行就换句，**逗号不换**（逗号两边还是同一句话）。`sent\_id` 用「篇号:句号」而不是裸句号，否则两篇课文的第 0 句会被当成同一句连起来。
21. **KD-Tree `move()` 的墓碑必须取旧位置**。先写 `self.\_pts\[pid] = p` 再去取 old，取到的是**新位置** → 刚插进去的点被自己标记成 dead。要在赋值之前取 `old = self.\_pts\[pid]` 并作为参数传下去。
22. **KD-Tree 的叶子不能串成链表**。第一版 `nd.right = root` 单链 + `axis=0`，剪枝按 x 轴判据走会跳过真实最近邻。改成叶桶（`axis = LEAF\_AXIS = -1`，两棵子树都无条件遍历）。
23. **`seed\_lexicon` 必须用独立 `random.Random(20261030)`**。「熟人带路」的抖动用全局 random，同一份基因表两次重播会长出不同的词（实测 30 / 33 不一致，改后两次都是 34）。
24. **「每帧限额」的遍历不能依赖 dict 顺序**。工作记忆的 temp 节点最后插入 → 排末尾 → 被 hot 节点耗尽配额，永远拉不到（实测半径恒 81.9）。要单独先拉临时词。
25. **固定加分压不过度数**。`+500` 会被 `deg\*12` 反超（deg>=48 就翻盘），宾语优先必须是**硬优先级**：先在宾语命中里挑，没有再退全量。
26. **`\_desens` 的值必须是 dict**。`apply\_supervise` 曾把 `self.\_desens\["e:a:b"] = time.time()+hold`（float）塞进去，`\_receptor\_ok` 的清理循环 `rr\["block"]` 直接炸 `TypeError: 'float' object is not subscriptable` —— `char\_loop` 连挂 108 次、`chars.fed` 停在 463 而 `cached` 照涨（缓存命中、字进不了大脑）。边级脱敏必须另开 `\_desens\_edges`，清理循环再加 `isinstance(rr, dict)` 兜底。
27. **测试顺序耦合比单个断言难查**。`\_g\_e2e` 的 56 次并发请求会残留一条 chat 通道，`\_arb\_e2e` 第 4 组就误判成「teach 结束后 holder 没回空闲」。断言前先轮询 `/api/arbiter` 等 `holder == ""`（最多 15 秒），再给 1.2 秒调度抖动容忍窗口 —— 真泄漏照样抓得到。
28. **缓存比节点宽**。`teach\_char` 只要真查成功就写 `\_char\_cache`，哪怕随后 `feed\_char` 因脱敏失败没建节点。所以「`/api/state` 里没有这个字」不等于「没查过它」—— 在线测试挑生字要看 `verdict` 是不是 `offline`，不能只看图里有没有。
29. **对外「声称」的记账必须和真实副作用对齐**。`learned.append(glyph)` 原来无条件执行，`feed\_char` 脱敏返回 `node\_id=None` 时节点没建、`learned` 却说学会了 → 同一句的 `compose\_reply` 索引里没有它，必然答非所问，而且表面上一切正常（节点数还在涨，因为涨的是别的字）。
30. **按「次数」累加的进度条要改成按秒限速**。V4.0 之后自发 Aha 次数与节点数成正比（1300 节点时 17.7 次/帧），`speech\_desire` 一帧顶格、清零后 1.4 秒又满。
31. **WebSocket 客户端默认 `max\_size = 1MB`**。首帧 full 快照已到 **1.14 MB**（2020 节点 / 55442 连线），`\_e2e.py` 直接 `ConnectionClosedError: sent 1009 (message too big)`。所有连 WS 的测试必须显式 `max\_size=64\*1024\*1024`。浏览器没这个上限，但节点继续长下去，首帧迟早要改成增量下发。
32. **`\_close\_sentence` 对同文本句子去重**。「投一门课，episodes 必涨」是错的 —— 重读旧课不会建新句节点、也就不会登记新情景（`\_region\_live` 因此假失败两次）。在线测试必须自造一句星云里没有过的话（4 个候选里挑没被占用的）。
33. **DOM 桩的 head 已声明 `fs` / `html`**。`tools/\_smoke\_\*\_tail.js` 拼接时 tail 再写 `const fs` 就 `SyntaxError: Identifier 'fs' has already been declared`。tail 里一律用独有前缀（`var p2src`）。
34. **`/api/optimize` 抛 `TypeError: float() argument must be a string or a real number, not 'dict'`**：`\_parse\_advice(text, specs, current)` 收到的 `current` 其实是 `engine.get\_params()` 的 `{k: {label,min,max,value}}`，`float()` 拿到 dict 直接炸。离线测试喂的是扁平 `{k: 数值}` 所以没暴露 —— **单测绿不代表真机对，端点接线处要按真形状再验一次**。修法两处：调用点先摊平成 `{k: v\["value"]}`；`\_parse\_advice` 内部再 `isinstance(cur, dict)` 兜一层。
35. **在线测试的语料会被她学光**。`\_region\_live` 的 4 句固定候选句跑第二遍就全进了 `\_sentence\_index`（成句去重），`chk("找到一句她没说过的话")` 假失败；`\_io\_live\_test` 的生僻字池、`\_chat\_e2e` 的候选生字同理。修法：候选池改成组合生成（6×6×6 = 216 种）或扩大码位区间，**并且缺料时 SKIP 而不是 FAIL** —— 机制本身在离线套件（`\_cell\_test` / `\_region\_test`）已验过。脱敏那组还要先确认「她醒着」（睡着时 `api\_feed\_file` 直接拒，那不是脱敏失灵）。
36. **`dt` 有上限时别按「补满」写断言**。`spinStep()` 把 `dt` 夹到 0.25s（切标签页回来不甩出去），测试里跳 900ms 只补 0.25×0.065 = 0.0162 弧度，写成 `> 0.02` 就是假失败 —— **先算清 clamp，再写阈值**。
37. **延迟二次落盘会让文件里的节点数比响应多几个**。`/api/shutdown` 回传 2261，0.9 秒后再存一次成了 2262 —— 断言写 `==` 就假失败。要写 `>=`，并单独约束「多出来的 ≤ 8」。

## 六、未完成 / 限制

* **浏览器像素级验证做不了**：headless Edge 被沙箱掐掉 mojo 命名空间（`FATAL:mojo\\public\\cpp\\platform\\platform\_channel.cc:187 Check failed`），前端只能 JS 语法 + DOM 桩冒烟。配色是否好看，要用户亲眼看。
* **`spike\_total` / `spike\_fires` / `self\_aha` / `dream\_spike\_fires` 不持久化**，重启归零（它们是运行时统计，不是记忆）。
* `decay\_rate` 仍是 0.05（20 秒时间常数），没有为「迅速衰减」单独调 —— 它是造物主滑块的全局参数，改它会影响整个记忆系统的巩固速度。
* **气泡里分不出「主动开口」和「回应」**：m03372 要求零修饰，`\[主动]`/`\[回应]` 徽章已删。要区分只能看上下文或左侧意识流日志。
* **对话里临时查的字没有拼音**：只有课程路径（`next\_char` → `feed\_char`）带注音。`/api/chat` 走 `\_unit\_for\_glyph()`，那几个生僻字节点的 `pinyin` 是空的。
* **左侧意识流日志仍是散文**：`\_MURMUR\_TEMPLATES` 40 多条呓语自带「呓语：」前缀和「（节点N）」括号，只进左边履历、不进气泡。要不要也换成节点链，一句话就能改。
* **V4.0 四个 Phase 全部完成**：Phase 1 内核 / Phase 2 3D 全景 / Phase 3 四区布局 / Phase 4 具身 + 优化框。
* **Phase 2 的首帧会随时间变胖**：`snapshot\_full` 一次性推 2020 节点 + 55442 连线 = 1.14 MB。浏览器扛得住，但节点再翻一倍就该改成分批下发或只发主干连线。
* **概念节点没有分词器**。`grow\_concept()` 靠「相邻两字 + 空间够近 + Top-3 互见」，会产出「家爸」「三四」这类滑窗垃圾；`WORD\_SET` 只收紧了门槛，没解决分词。
* **Phase 4 的具身是 Canvas 程序化绘制，不是 .moc3 模型**。本机没有任何 Live2D 素材，所以按「禁止预制动作」红线改成：`drawPet()` 用 `body` 的 7 个连续量（flex / lean / tail / fin / eye / breath / noci）实时画一条抽象小鱼 —— 无贴图、无关键帧、无自转 `requestAnimationFrame`。日后若提供 Live2D 素材，替换 `drawPet` 一个函数即可，其余接线（`petHUD` / `frameLoop` 限帧）不用动。
* **她还不懂语法**：「江 → 水、河、川」是共现，不是「江是一条河」。要真懂主谓宾，得让句子的**序列**进记忆 —— 现在一个字只有一个节点，序列信息只活在边权里。

## 七、服务启停

```powershell
# 停：job\_kill
# 起：
$env:PYTHONIOENCODING="utf-8"; Set-Location "A:\\小鱼计划"; python aha\_server.py --port 8000
```

## 改 `.py` 之后必须 `rm -rf \_\_pycache\_\_ tools/\_\_pycache\_\_` 再启动 —— `ops\_write\_file` 保留 mtime，`.pyc` 不会失效。

## 八、v1.0 提纯包（2026-10-31）

本目录是 `A:\\小鱼计划` 的提纯快照，用于分发、备份、换机。

**保留**：五个 `.py` + `index.html` + `Input\_Files/`（24 课）+ `Memory\_Core/` 存档（2332 节点 / 87878 连线 / 观测履历）+ 启停脚本。

**剔除**：`tools/`（269 个测试与补丁脚本）、`tools/\_pylibs/`（107 MB 的 cv2 本地副本）、`\_\_pycache\_\_/`、根目录的视频素材（`frames\*/`、`hologram\_\*.mp4`、`h3\_\*.json`、`minimax\_h3\_src.jpg`）、`Aha\_Save\_01.json`（3.7 MB 手动存档槽）、DSH 工具的临时锁文件。

**新增**：`README.md`、`requirements.txt`、`.gitignore`、`Memory\_Core/config.example.json`。

**修正**：`启动小鱼.bat` 的 `cd /d "A:\\小鱼计划"` 改为 `cd /d "%\~dp0"` —— 原来写死绝对路径，换目录就废；现在整个文件夹可以任意搬走。

**验证**（在新目录起服务实测）：启动耗时 1.0 秒，`nodes=2332` / `conns=87889` / `kinds {char:1311, concept:762, sentence:223, paragraph:36}` / `E=120.4 I=111.0 mean=20.1` / `last\_error` 干净 / `index.html` 155473 字符送达。

**一个环境事实**：本包**不含 `cv2`**（原项目的 `tools/\_pylibs` 已剔除）。系统 Python 里也没有 —— `aha\_input.py` 会自动退化为 Pillow + numpy 手写 Sobel，逐字学习与对话路径完全不受影响（她现在的 2332 个节点全是文字节点）。要喂图片时再 `pip install opencv-python-headless`。

