# Project Aha（小鱼）完整逻辑链条

> 对照版本：`aha_brain.py` 2369 行 / `aha_input.py` 1067 行 / `aha_server.py` 2119 行 / `index.html` 2965 行
> 所有行号为本文件生成时的实测值，改代码后可能漂移，用函数名检索最稳。

## 零、一张图看懂

```
                          ┌─────────────── 外部世界 ───────────────┐
  Input_Files/*.txt ──┐                                  ┌── 用户打字（聊天框）
                      ▼                                  ▼
        aha_input.next_char()                    POST /api/chat
        逐字切分 + 50 维特征                       _learn_unknown_in_text()
                      │                                  │
                      │        ┌─────────────────────────┘
                      ▼        ▼
              teach_char() → ask_deepseek()（真理标定器，只盖章不说话）
                      │  label='河流'  verdict='safe'
                      ▼
              eye.feed_char() ──► engine.learn()
                                      │
                    ┌─────────────────┼─────────────────┐
                    ▼                 ▼                 ▼
              找得到就唤醒        找不到就生长      连线（_connect）
              awake_think()      add_new_experience    consolidate()
                    │                 │                 │
                    └─────────────────┴─────────────────┘
                                      ▼
               ┌──────────── 一个神经元节点（三维坐标 + 膜电位）────────────┐
               │  activation  ← _spike_step() 每帧撒 5~10 点背景电活动      │
               │              ← 邻居串扰 / 外部刺激                        │
               │  activation  → tick_decay() 每帧 x0.951（漏电）           │
               │  到 50 就放电 → try_activate() → 不该期 → 重置            │
               └───────────────────────────┬─────────────────────────────┘
                                           ▼
                     update_homeostasis()（E=105+drive / I=100+err*0.7）
                     _update_biorhythm()（10 秒 50 次顿悟就强制入睡）
                                           ▼
            ┌──────────────────── 观测层 ────────────────────┐
            │  engine.frame() → WebSocket 10Hz → ingestFrame │
            │  → potColor() 电位配色 / focusRingPhase() 焦点环 │
            │  → CanvasRenderer / ThreeRenderer 画星云        │
            └────────────────────────────────────────────────┘

                                      ┌── 她开口（不走大模型）
                                      ▼
                            engine.compose_reply()
                            节点检索 → 顺连线找邻居 → 模板拼接
```

## 一、输入：世界怎么进来

| 环节 | 代码 |
| --- | --- |
| 扫描文件夹 | `aha_input.list_text_files()` — [aha_input.py:668](aha_input.py#L668) |
| 选一课上 | `aha_input.select_text_file()` — [aha_input.py:795](aha_input.py#L795) |
| 读下一课 | `aha_input._load_next_text_file()` — [aha_input.py:692](aha_input.py#L692) |
| 吐一个字 | `aha_input.next_char()` — [aha_input.py:839](aha_input.py#L839) |

`next_char()` 是整个输入层的闸门，它做四件事：切字（汉字单字 / 连续 ASCII 词）、抽特征、维护 `_read_set` 防重复、读到文件尾就 `hold = True` 停在这一课。

```python
# aha_input.py:839
unit = {"kind": "char", "glyph": ch, "feature": extract_char_feature(ch),
        "path": path, "name": name, "index": i}
```

**一课一停**（用户 m02388）的闸门在 `_load_next_text_file` 顶部：

```python
if self._hold_target and not self._forced_name:
    self.hold = True
    self.hold_reason = "《%s》读完了。点下一课，或者放她自己玩。" % self._hold_target
    return False
```

## 二、降维：汉字怎么变成 50 维向量

**这是整个项目最不"玄学"、也最关键的一段**——不调用任何模型，纯粹用码位和部首做几何映射。

`extract_char_feature(ch)` — [aha_input.py:396](aha_input.py#L396)，返回 `TEXT_FEATURE_DIM = 50` 维、值域 [0,1]。

| 维度 | 编码什么 | 机制 |
| --- | --- | --- |
| `[0..15]` | **部首族软分配** | 16 个部首锚点，`exp(-d²/2σ²)`，σ=400 码位 |
| `[16..27]` | **部族排名编码** | top1/top2 + 黄金比例散列，把跨族字硬性拉开 |
| 其余 | 码位 / 拼音区位 | 未归族的字兜底，保证任何输入都不返回 None |

```python
# aha_input.py:411 —— 软分配：我像哪些族
for i in range(min(16, len(_RADICAL_CENTERS))):
    d = code - _RADICAL_CENTERS[i][1]
    feat[i] = math.exp(-(d * d) / sigma2)
```

```python
# aha_input.py:427 —— 排名编码：我最像哪一族
order = sorted(range(16), key=lambda i: -feat[i])
top1 = order[0] if order else 0
top2 = order[1] if len(order) > 1 else top1
```

> 为什么光靠软分配不够：码位相邻就互相渗透，「日」和「月」只差 0.067，等于白白放行一批跨族误并。排名编码就是拿来把同族字钉在一起的。

## 三、盖章：谁来给这个字一个意思

| 环节 | 代码 |
| --- | --- |
| 问百科全书 | `ask_deepseek()` — [aha_server.py:614](aha_server.py#L614) |
| 解析标签 | `parse_truth_label()` — [aha_server.py:445](aha_server.py#L445) |
| 带缓存的教一个字 | `teach_char()` — [aha_server.py:879](aha_server.py#L879) |

`ask_deepseek` 的 body 里塞的是 `_BRAIN_SYSTEM_PROMPT`（真理标定器：拒绝废话 / 极简标签 ≤15 字 / 真值判定 / 安全感反馈 `[+安全]` 或 `[-危机]`），`temperature=0.1`、`max_tokens=64`。

`parse_truth_label` 把它拆成两半：

```python
answer = "河流 [+安全]"
→ label   = "河流"
→ verdict = "safe"        # safe / crisis / unknown
```

**这里有一条硬边界**（用户 m02206）：DeepSeek 只负责盖章和返回标签，**绝不生成对话文本**。查完就下机。

## 四、生长：节点怎么长出来

`engine.learn(feature_vector, meta)` — [aha_brain.py:1451](aha_brain.py#L1451) 是所有感官输入的唯一入口。

### 4.1 先认字，再认特征

```python
# aha_brain.py:1470 —— 先按字形精确找
if glyph:
    for n in self.nodes.values():
        if n.glyph == glyph:
            target = n
            break
if target is None:
    target = self._find_closest_node(feature_vector)
    # 但也不许"河"被特征相近的"江"认领
    if target is not None and target.glyph and target.glyph != glyph:
        target = None
```

两个判据缺一不可：只按特征找，`江` 和 `河` 会互相吞；只按字找，画等非文字输入就没法归并。

### 4.2 找不到就长一个新节点

`add_new_experience()` — [aha_brain.py:1365](aha_brain.py#L1365)，**三维坐标不是随机的**：

```python
# aha_brain.py:1377 —— 挂在最近邻旁边，相似度高就贴得紧
sim = self._cosine(parent.features_z, self._standardize(feature_vector))
spread = 2.5 + (1.0 - _clamp(sim, 0.0, 1.0)) * 5.5
pos = (parent.pos[0] + random.gauss(0.0, spread), ...)
```

相似 → 偏移 2.5；陌生 → 偏移 8。**这就是「树状记忆」和「聚类成簇」的物理来源**：不是画出来的，是长出来的。

第一条记忆（无父节点）才随机撒点，范围收窄到 ±30。

### 4.3 已认识的：唤醒 + 贴标签

走到 `awake_think()` — [aha_brain.py:1261](aha_brain.py#L1261)：找空间邻居 → 随机抽 5 个 → `try_activate` → 成功就建立连线并触发正反馈。

```python
# aha_brain.py:1502 —— 强化印记，受绝对不应期护盾
if now - target.last_fired_time >= target.abs_refractory:
    target.activation = min(target.threshold * 0.9, target.activation + 15.0 * sal)
```

## 五、连线：树怎么长出枝干

`_connect(a_id, b_id, weight)` — [aha_brain.py:688](aha_brain.py#L688) 是唯一的连线入口，**已存在就加强，上限 4.0**：

```python
key = (a_id, b_id) if a_id < b_id else (b_id, a_id)
if key in self._conn_index:
    self._conn_weight[idx] = min(4.0, self._conn_weight[idx] + weight * 0.5)
```

| 权重档 | 来源 | 代码 |
| --- | --- | --- |
| 0.8 | 出生时挂到最近邻（树的主干） | [aha_brain.py:1409](aha_brain.py#L1409) |
| 1.0 | 顿悟（awake_think 放电成功） | [aha_brain.py:1261](aha_brain.py#L1261) |
| 0.4 | 空间巩固（consolidate） | [aha_brain.py:1232](aha_brain.py#L1232) |
| 0.4 | 梦里的 REM 随机连线 | [aha_brain.py:993](aha_brain.py#L993) `_spike_step` |

`consolidate()` 每 2 秒跑一次：随机采样一批节点，把半径 `neighbor_radius * 2.5` 内的邻居连起来 —— **这是「睡一觉起来发现它们连上了」的机制**。

剪枝在 `_prune_synapses()` — [aha_brain.py:919](aha_brain.py#L919)，判据是「低权重 **且** 两端都不在核心集」：

```python
n_core = max(3, int(len(deg) * self.prune_core_ratio))   # 度数最高的 20%
core = set(nid for nid, _ in deg.most_common(n_core))
for i, (a, b) in enumerate(self.connections):
    if self._conn_weight[i] > self.prune_weight: continue   # 1.05
    if a in core or b in core: continue
```

## 六、活着：心跳、稳态、生物钟、电活动

`engine.tick(dt=0.1)` — [aha_brain.py:1195](aha_brain.py#L1195) 是整颗大脑的**唯一节拍器**，顺序不能乱：

```python
# aha_brain.py:1195（简化）
for n in self.nodes.values():
    n.tick_decay(now)            # ① 全网漏电
self.update_homeostasis(dt)      # ② E/I 负反馈
self._update_biorhythm(dt, now)  # ③ 亢奋判定，可能入睡
self._spike_step(dt, now, dream=bool(self.sleeping))   # ④ 背景电活动
if self.sleeping:
    self._dream_step(dt, now)    # ⑤ 梦境游走
self.consolidate()               # ⑥ 每 2 秒巩固一次
```

### 6.1 单个神经元的物理

| 机制 | 代码 | 关键行 |
| --- | --- | --- |
| 漏电 | `NeuronNode.tick_decay()` — [aha_brain.py:212](aha_brain.py#L212) | `activation *= exp(-0.05 * dt)`，1 秒 x0.951，**稳态 = 注入率 / 0.05** |
| 绝对不应期 | `NeuronNode.try_activate()` — [aha_brain.py:240](aha_brain.py#L240) | 2 秒内彻底锁死 |
| 相对不应期 | 同上 | 2~5 秒阈值翻倍 |
| 放电重置 | 同上 | `activation = max(0, act - threshold*0.8) * 0.35` |

### 6.2 内环境稳态（E 与 I）

`update_homeostasis()` — [aha_brain.py:716](aha_brain.py#L716)：

```python
drive = activity_ratio * min(mean_activation, 45.0) * 0.75
self.tone_excitation += ((self.target_safety + drive + self.bg_drift) - self.tone_excitation) * k_e
want_i = self.tonic_inhibition + max(0, err) * 0.7 + self.fatigue * 0.15
```

**105 只是静息基线，不是上限**。真正平衡点是 `105 + drive`，drive 天花板 33.75，所以 E 最高约 139。静息时实测 E≈114（mean≈16 时 drive≈12）。

### 6.3 生物钟与强制睡眠

`_update_biorhythm()` — [aha_brain.py:814](aha_brain.py#L814)：

```python
hot_aha = len(self.aha_times) >= self.aha_burst_max           # 10 秒 50 次
hot_raw = self.global_excitation >= limit * 0.90              # 顶到安全线九成
if hot_aha or hot_raw:
    self._excited_hold += dt
    if self._excited_hold >= self.aha_hold:                   # 持续 3 秒
        self._enter_sleep(now, reason)
```

入睡后 `_sleep_step()` — [aha_brain.py:870](aha_brain.py#L870)：全节点每帧 x0.80、E 被拉向 `tonic * 0.78`、每 0.8 秒剪一批突触。醒来的条件是「窗口内没有顿悟 **且** E 低于 96.6」并持续 4 秒。

### 6.4 背景电活动（m02813）

`_spike_step()` — [aha_brain.py:993](aha_brain.py#L993)，参数：[aha_brain.py:500](aha_brain.py#L500)：

```python
self.spike_hz = 8.0          # 5~10 Hz
self.spike_cover = 0.017     # 每脉冲覆盖全网的 1.7%
self.spike_bunch = 0.55      # 55% 概率继续打同一颗星（成簇，才有长尾）
lam = self.spike_hz * self.spike_gain * dt * self.spike_cover * n_nodes
k = _poisson(lam)
node.activation += random.uniform(5.0, 10.0)     # 用户要的 5~10 点
```

`_poisson()` 在 [aha_brain.py:64](aha_brain.py#L64) —— 10Hz 下单帧 `lam` 常小于 1，`int()` 会永远取 0。

**自发放电记在 `stats["self_aha"]`，绝不进 `stats["aha"]`** —— 后者是生物钟的输入，混了会让她被自己的底噪判成亢奋、永远醒不来。

梦里换一组参数（[aha_brain.py:519](aha_brain.py#L519)）：`dream_spike_rate = 14/s`、幅度 36~62（单次直接跨阈值），同帧两个节点放电就 `_connect` 一条 —— 这是「梦里连出奇妙的线」的来源。

## 七、开口：她怎么说话（零网络请求）

`POST /api/chat` → `api_chat()` — [aha_server.py:1630](aha_server.py#L1630)：

```python
# aha_server.py:1643 —— 先学，再答
learned = _learn_unknown_in_text(text, limit=6)    # 先查字典建节点
with _ENGINE_LOCK:
    res = engine.compose_reply(text)               # 再靠图网络拼话
```

`compose_reply()` — [aha_brain.py:1824](aha_brain.py#L1824)，六个纯函数：

| 步骤 | 函数 | 作用 |
| --- | --- | --- |
| ① 扫认识的词 | `_cjk_hits()` [aha_brain.py:1718](aha_brain.py#L1718) | 长字优先，倒排索引 |
| ② 切出实词 | `_target_spans()` [aha_brain.py:1738](aha_brain.py#L1738) | 排除 `_WEAK_CHARS` 里 100 多个虚词 |
| ③ 选主角 | `_topic_score()` [aha_brain.py:1758](aha_brain.py#L1758) | `deg*12 + len*6 - pos*0.8`，宾语 +500 |
| ④ 顺线找邻居 | `_neighbors_of()` [aha_brain.py:1768](aha_brain.py#L1768) | 按权重降序取 3 个，有字优先 |
| ⑤ 语气 | `_tone_prefix()` [aha_brain.py:1793](aha_brain.py#L1793) | 疲劳 ≥55 → 困倦；查不到 → 焦虑 |
| ⑥ 拼句 | `compose_reply()` | 三套模板 |

```python
# aha_brain.py:1824 附近 —— 三套句型
'你问到了「江」，我记得它连着「河」，还连着「海」。'
'你问到了「江」，我记得它连着「河」。'
'我看到了「江」，但它孤零零的，我想不出来它和什么有关系。'
'我不认识这个词，我的星云里没有它的光。'
```

最后 `speak()` — [aha_brain.py:1598](aha_brain.py#L1598) 写进 `speech_log`，前端 `pushSpeech()` 显示。

## 八、调度：三通道抢占

`lane()` 上下文管理器 — [aha_server.py:199](aha_server.py#L199)，底层是 `_arb_enter` [aha_server.py:161](aha_server.py#L161) / `_arb_exit` [aha_server.py:179](aha_server.py#L179)。

| 通道 | 优先级 | 谁用 |
| --- | --- | --- |
| `chat` | 1（最高） | `POST /api/chat`、`POST /teach` |
| `oracle` | 2 | `teach_char()` 里那次 DeepSeek 请求 |
| `learn` | 3 | `char_loop()` 逐字学习 |

```python
# aha_server.py:1127 —— 学习循环的闸门
ready, why = learn_ready()
if not ready:
    time.sleep(0.15)      # 不是死等，每 150ms 探一次
    continue
```

对话结束后 `_arb_exit(LANE_CHAT, RESUME_DELAY_CHAT = 2.6)`，学习通道以 `LEARN_RAMP_MUL = 1.8` 倍的间隔缓坡恢复（[aha_server.py:134](aha_server.py#L134)）。

`arb_focus(node_id, note, ttl)` — [aha_server.py:251](aha_server.py#L251) 点亮前端的焦点环。

## 九、观测：我们怎么看见她

| 环节 | 代码 |
| --- | --- |
| 主循环心跳 | `life_loop()` — [aha_server.py:799](aha_server.py#L799)，10Hz |
| WebSocket | `ws_stream()` — [aha_server.py:1241](aha_server.py#L1241) |
| 全量快照 | `engine.snapshot_full()` — [aha_brain.py:2119](aha_brain.py#L2119) |
| 增量帧 | `engine.frame()` — [aha_brain.py:2139](aha_brain.py#L2139) |
| 生理指标 | `engine.physiology()` — [aha_brain.py:2067](aha_brain.py#L2067) |
| 认知报告 | `engine.cognitive_report()` — [aha_brain.py:1945](aha_brain.py#L1945) |

前端三件事：

```js
// index.html:917
ingestFrame(msg)  →  S.nodes / S.conns / S.physio / S.hist(e,i)
```

| 视觉 | 函数 | 位置 |
| --- | --- | --- |
| 电位配色（深蓝→浅青→放电爆粉） | `potColor()` | [index.html:823](index.html#L823) |
| 焦点环（收缩锁定→闪3下→淡出） | `focusRingPhase()` | [index.html:852](index.html#L852) |
| 三通道面板联动 | `updateArb()` | [index.html:702](index.html#L702) |
| 意识流日志（上限 50 条） | `pushSpeech()` | [index.html:2018](index.html#L2018) |
| 悬停档案卡 | `renderTip()` | [index.html:1910](index.html#L1910) |
| Canvas 兜底渲染器 | `CanvasRenderer` | [index.html:1021](index.html#L1021) |
| Three 渲染器 | `ThreeRenderer` | [index.html:1214](index.html#L1214) |
| 升级到 Three | `upgradeToThree()` | [index.html:1468](index.html#L1468) |

## 十、关键常量总表

| 常量 | 值 | 位置 | 含义 |
| --- | --- | --- | --- |
| `TEXT_FEATURE_DIM` | 50 | [aha_input.py:336](aha_input.py#L336) | 汉字向量维度 |
| `_RADICAL_SIGMA` | 400.0 | [aha_input.py:358](aha_input.py#L358) | 部首族的码位半径 |
| `threshold` | 50.0 | [aha_brain.py:180](aha_brain.py#L180) | 放电阈值 |
| `decay_rate` | 0.05 | [aha_brain.py:179](aha_brain.py#L179) | 漏电率（时间常数 20 秒） |
| `target_safety` | 105.0 | [aha_brain.py:410](aha_brain.py#L410) | 兴奋基线 |
| `tonic_inhibition` | 100.0 | [aha_brain.py:417](aha_brain.py#L417) | 抑制基线 |
| `overload_per_node` | 25.0 | [aha_brain.py:427](aha_brain.py#L427) | 人均激活安全线 |
| `aha_window` | 10.0 | [aha_brain.py:441](aha_brain.py#L441) | 顿悟频率窗口 |
| `aha_burst_max` | 50 | [aha_brain.py:442](aha_brain.py#L442) | 窗口内多少次判亢奋 |
| `spike_hz` | 8.0 | [aha_brain.py:500](aha_brain.py#L500) | 背景电活动频率 |
| `spike_cover` | 0.017 | [aha_brain.py:501](aha_brain.py#L501) | 每脉冲命中比例 |
| `dream_spike_rate` | 14.0 | [aha_brain.py:519](aha_brain.py#L519) | 梦里脉冲频率 |
| `prune_weight` | 1.05 | [aha_brain.py:466](aha_brain.py#L466) | 低于此权重是修剪候选 |
| `CHAR_INTERVAL` | 0.8 | [aha_server.py:69](aha_server.py#L69) | 两个字之间歇多久 |
| `RESUME_DELAY_CHAT` | 2.6 | [aha_server.py:134](aha_server.py#L134) | 对话后恢复延迟 |
| `LEARN_RAMP_MUL` | 1.8 | [aha_server.py:137](aha_server.py#L137) | 缓坡间隔倍数 |

## 十一、一次完整生命周期（从放一个字到星云亮起）

```
t=0.00s  char_loop 取到「江」，learn_ready() 通过
t=0.01s  teach_char('江') 命中 _char_cache → label='河流' verdict='safe'（0 次网络）
t=0.02s  feed_char → engine.learn()
t=0.03s  learn 按 glyph 找：没有「江」→ _find_closest_node('江' 的 50 维)
         最近的是「河」（余弦 0.93）但它是别的字 → 拒绝认领
t=0.04s  add_new_experience：父节点=河，spread=2.5+0.07*5.5≈2.9
         pos=(河.x+gauss(0,2.9), ...)  → 江 落在河旁边 3 个单位内
         _connect(河, 江, weight=0.8)   ← 树干
t=0.05s  receive_reassurance(0.5) → E +1, fatigue -1.5
t=0.10s  life_loop 下一次 tick：江的 activation 从 15 开始 x0.951/秒
t=0.20s  _spike_step 撒了 33 个脉冲，其中 0.55 概率成簇打到同一颗星
t=1.90s  某颗星连挨 3 下 +22 → 47，第 4 下跨过 50 → try_activate 放电
         颜色从 206° 蓝 -> 185° 青 -> 338° 亮粉，鼓一圈，0.45 秒褪回去
t=2.00s  consolidate() 跑一轮：江 与 半径 25 内的 湖/海 连上 0.4 的弱边
t=30.0s  /api/chat 「你认识江吗」
         先 _learn_unknown_in_text（没有生字）→ compose_reply
         _target_spans('你认识江吗') = ['江']；_topic_score 宾语 +500
         _neighbors_of(江) = [河(直连), 海, 湖]
         reply = '你问到了「江」，我记得它连着「河」，还连着「海」。'
t=30.1s  arb_focus(江, '回答：你问到了「江」…', ttl=10)
         前端 focusRingPhase(age) 开始跑：0.32 秒收缩锁定 → 闪 3 下 → 2.4 秒内化掉
```

## 十二、三条不可违反的边界

1. **本体不依赖任何预训练模型**。整个 `aha_brain.py` 没有一次 import torch / 网络请求；说话也零网络（`compose_reply` 全是节点检索和字符串拼接）。
2. **DeepSeek 只盖章，不开口**（用户 m02206）。它出现在两处：`teach_char()` 给标签、`/teach` 给裁决。对话回复永远由 `compose_reply` 产生。
3. **自发放电不等于顿悟**。`stats["self_aha"]` 与 `stats["aha"]` 严格分开，否则生物钟会被底噪喂爆（[aha_brain.py:993](aha_brain.py#L993) 有注释说明）。
