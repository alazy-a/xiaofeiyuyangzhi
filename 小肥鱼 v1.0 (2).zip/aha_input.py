# -*- coding: utf-8 -*-
"""
Project Aha — 视觉与文件输入降维器 (aha_input.py)
====================================================

职责: 把外界的图片 / 文本，压成 10 维"物理特征"，喂给 aha_brain.AhaEngine。

哲学约束（不可违反）:
  - 绝对不用 ResNet / ViT / CLIP 之类的预训练视觉模型。
    "看"这件事只允许用最底层的物理量：Canny 边缘、Sobel 梯度、RGB/HSV 统计。
    小鱼出生时不会认识"猫"，它只知道"这里有密集的强边缘 + 低明度 + 高饱和红"。
  - 特征必须是固定长度，且与 aha_brain 的特征空间同量纲（全部落在 [0, 1]）。

10 维特征定义（图片）:
  d0 边缘密度        Canny 非零像素占比      —— "画面有多碎"
  d1 边缘强度        Sobel 幅值均值 / 255    —— "边缘有多硬"
  d2 边缘方向熵      梯度方向直方图的归一化熵 —— "纹理是否有主方向"
  d3 R 均值 / 255
  d4 G 均值 / 255
  d5 B 均值 / 255
  d6 明度 V / 255
  d7 饱和度 S / 255
  d8 色彩对比度      灰度标准差 / 128        —— "是不是一片糊"
  d9 构图复杂度      8x8 网格的边缘密度熵     —— "东西是不是挤在一角"

10 维特征定义（文本）:
  d0 长度(log 归一) d1 字母率 d2 数字率 d3 标点率 d4 中日韩字符率
  d5 空白率    d6 字符熵   d7 大写率 d8 元音率 d9 字节值标准差率

依赖:
  - 必需: numpy
  - 期望: OpenCV (cv2)，装不上时自动退化为 Pillow + numpy 手写 Sobel
  - 本项目把 cv2 装在工作区内的 tools/_pylibs，本文件会自动把它加进 sys.path
"""

import math
import random
import re
import sys
import threading
import time
import unicodedata
from collections import Counter
from pathlib import Path

import numpy as np

_HERE = Path(__file__).resolve().parent

# --- 本项目把 OpenCV 装在 workspace 内部（系统 site-packages 无写权限）---
_VENDOR = _HERE / "tools" / "_pylibs"
if _VENDOR.is_dir() and str(_VENDOR) not in sys.path:
    sys.path.insert(0, str(_VENDOR))

try:
    import cv2
except Exception:                     # pragma: no cover - 环境差异
    cv2 = None

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".webp", ".tif", ".tiff", ".gif", ".ppm"}
TEXT_EXTS = {".txt", ".md", ".json", ".csv", ".tsv", ".log", ".yaml", ".yml", ".py", ".js", ".html"}

FEATURE_DIM = 10
MAX_SIDE = 512          # 先缩到 512 长边，特征几乎不变，速度快一个量级


# ---------------------------------------------------------------------------
# 基础工具
# ---------------------------------------------------------------------------


def _clamp01(v):
    return 0.0 if v < 0.0 else (1.0 if v > 1.0 else float(v))


def _norm_entropy(counts):
    """归一化信息熵：0 = 完全集中，1 = 完全均匀"""
    total = sum(counts)
    if total <= 0:
        return 0.0
    h = 0.0
    for c in counts:
        if c > 0:
            p = c / total
            h -= p * math.log(p)
    n = len([c for c in counts])
    if n <= 1:
        return 0.0
    return h / math.log(n)


def _imread_unicode(path):
    """读图，兼容中文/空格路径。

    cv2.imread 在 Windows 上遇到非 ASCII 路径会静默返回 None，
    这是最经典的坑：用户往 Input_Files 里丢一张"红果子.png"，小鱼直接瞎掉。
    必须走 np.fromfile + cv2.imdecode。
    """
    p = str(path)
    if cv2 is not None:
        try:
            buf = np.fromfile(p, dtype=np.uint8)
            if buf.size == 0:
                return None
            return cv2.imdecode(buf, cv2.IMREAD_COLOR)
        except Exception:
            return None
    # Pillow 兜底
    try:
        from PIL import Image
        with Image.open(p) as im:
            return np.array(im.convert("RGB"))[:, :, ::-1].copy()   # RGB -> BGR，与 cv2 对齐
    except Exception:
        return None


# ---------------------------------------------------------------------------
# 图片 → 10 维
# ---------------------------------------------------------------------------


def _sobel_pil(gray):
    """没有 cv2 时的 Sobel 兜底（纯 numpy 卷积，3x3）"""
    g = gray.astype(np.float32)
    kx = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=np.float32)
    ky = np.array([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=np.float32)
    pad = np.pad(g, 1, mode="edge")
    out = np.zeros_like(g)
    for y in range(g.shape[0]):
        for x in range(g.shape[1]):
            win = pad[y:y + 3, x:x + 3]
            gx = float((win * kx).sum())
            gy = float((win * ky).sum())
            out[y, x] = math.hypot(gx, gy)
    return out


def _edge_maps(bgr):
    """返回 (边缘二值图, 梯度幅值, 梯度方向) —— 优先 cv2，退化到 numpy"""
    gray = None
    if cv2 is not None:
        gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
        # 自适应 Canny：低对比度图上固定阈值会得到全 0 的边缘图
        med = float(np.median(gray))
        lower = int(max(0.0, 0.66 * med))
        upper = int(min(255.0, 1.33 * med))
        if upper <= lower:
            lower, upper = 50, 150
        edges = cv2.Canny(gray, lower, upper)
        gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
        gy = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)
    else:                                   # pragma: no cover
        from PIL import Image
        gray = np.array(Image.fromarray(bgr[:, :, ::-1]).convert("L"))
        gx = np.zeros_like(gray, dtype=np.float32)
        gy = np.zeros_like(gray, dtype=np.float32)
        mag = _sobel_pil(gray)
        edges = (mag > 60).astype(np.uint8) * 255
    mag = np.hypot(gx, gy)
    ang = np.arctan2(gy, gx)
    return edges, mag, ang, gray


def extract_image_feature(path):
    """把一张图压成 10 维物理特征。失败返回 None。"""
    bgr = _imread_unicode(path)
    if bgr is None or bgr.size == 0:
        return None

    h, w = bgr.shape[:2]
    scale = min(1.0, MAX_SIDE / float(max(h, w)))
    if scale < 1.0:
        if cv2 is not None:
            bgr = cv2.resize(bgr, (max(1, int(w * scale)), max(1, int(h * scale))),
                             interpolation=cv2.INTER_AREA)
        else:                               # pragma: no cover
            from PIL import Image
            im = Image.fromarray(bgr[:, :, ::-1]).resize(
                (max(1, int(w * scale)), max(1, int(h * scale))))
            bgr = np.array(im)[:, :, ::-1].copy()

    edges, mag, ang, gray = _edge_maps(bgr)
    total_px = float(gray.shape[0] * gray.shape[1]) or 1.0

    # d0 边缘密度
    edge_density = float(np.count_nonzero(edges)) / total_px
    # d1 边缘强度
    edge_strength = _clamp01(float(mag.mean()) / 255.0)
    # d2 边缘方向熵（只用有梯度的像素投票）
    strong = mag > (mag.mean() + mag.std())
    if np.any(strong):
        bins = ((ang[strong] + math.pi) / (2 * math.pi) * 8).astype(np.int32) % 8
        hist = np.bincount(bins, minlength=8).tolist()
        dir_entropy = _norm_entropy(hist)
    else:
        dir_entropy = 0.0

    # d3~d5 RGB 均值（BGR 顺序还原）
    b_mean = float(bgr[:, :, 0].mean()) / 255.0
    g_mean = float(bgr[:, :, 1].mean()) / 255.0
    r_mean = float(bgr[:, :, 2].mean()) / 255.0

    # d6 明度 / d7 饱和度
    if cv2 is not None:
        hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
        v_mean = float(hsv[:, :, 2].mean()) / 255.0
        s_mean = float(hsv[:, :, 1].mean()) / 255.0
    else:                                   # pragma: no cover
        mx = bgr.max(axis=2).astype(np.float32)
        mn = bgr.min(axis=2).astype(np.float32)
        v_mean = float(mx.mean()) / 255.0
        s_mean = float(np.where(mx > 0, (mx - mn) / np.maximum(mx, 1), 0).mean())

    # d8 色彩对比度
    contrast = _clamp01(float(gray.std()) / 128.0)

    # d9 构图复杂度：8x8 网格里边缘密度的分布熵
    gh, gw = gray.shape
    cells = []
    for gy_ in range(8):
        for gx_ in range(8):
            y0, y1 = int(gh * gy_ / 8), max(int(gh * (gy_ + 1) / 8), int(gh * gy_ / 8) + 1)
            x0, x1 = int(gw * gx_ / 8), max(int(gw * (gx_ + 1) / 8), int(gw * gx_ / 8) + 1)
            block = edges[y0:y1, x0:x1]
            cells.append(float(np.count_nonzero(block)))
    layout_entropy = _norm_entropy(cells)

    feat = [
        _clamp01(edge_density * 4.0),      # 边缘密度通常 < 0.25，乘 4 拉开动态范围
        edge_strength,
        dir_entropy,
        r_mean,
        g_mean,
        b_mean,
        v_mean,
        s_mean,
        contrast,
        layout_entropy,
    ]
    return [round(_clamp01(v), 6) for v in feat]


# ---------------------------------------------------------------------------
# 文本 → 10 维
# ---------------------------------------------------------------------------


def extract_text_feature(path_or_text, is_text=False):
    """把一段文本压成 10 维。is_text=True 时直接当字符串处理。"""
    if is_text:
        text = str(path_or_text)
        name = "<inline>"
    else:
        p = Path(path_or_text)
        name = p.name
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            try:
                text = p.read_text(encoding="gbk", errors="ignore")
            except Exception:
                return None

    text = text[:20000]                    # 只要统计特征，截断足够
    n = len(text)
    if n == 0:
        return [0.0] * FEATURE_DIM

    letters = digits = puncts = cjk = spaces = uppers = vowels = 0
    VOWELS = set("aeiouAEIOU")
    for ch in text:
        cat = unicodedata.category(ch)
        if ch.isspace():
            spaces += 1
        elif cat.startswith("L"):
            if "\u4e00" <= ch <= "\u9fff":
                cjk += 1
            elif ch.isalpha():
                letters += 1
                if ch.isupper():
                    uppers += 1
                if ch in VOWELS:
                    vowels += 1
        elif cat.startswith("N"):
            digits += 1
        elif cat.startswith("P") or cat.startswith("S"):
            puncts += 1

    counter = Counter(text)
    char_entropy = _norm_entropy(list(counter.values())) if counter else 0.0
    byte_arr = np.frombuffer(text.encode("utf-8", errors="ignore"), dtype=np.uint8)
    byte_std = float(byte_arr.std()) / 128.0 if byte_arr.size else 0.0

    feat = [
        _clamp01(math.log1p(n) / math.log1p(20000)),
        letters / n,
        digits / n,
        puncts / n,
        cjk / n,
        spaces / n,
        char_entropy,
        uppers / max(1, letters),
        vowels / max(1, letters),
        _clamp01(byte_std),
    ]
    return [round(_clamp01(v), 6) for v in feat]


# ---------------------------------------------------------------------------
# 输入层（文件夹扫描 + 喂食）
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 中文字形特征提取器 (Text Feature Extractor, v2)
# ---------------------------------------------------------------------------
# 设计约束：不许用任何 Transformer / 预训练语言模型。
# 那"江"和"河"凭什么在向量空间里靠得近？靠三样**纯物理量**：
#
#   1. 部首族软分配（16 维）
#      汉字 90% 以上是形声字，部首决定语义场。Unicode 的 CJK 区块里，
#      同部首的字是**连续排列**的（水部集中在 U+6C00 附近，木部 U+6700 附近）。
#      所以只要取 16 个"部首锚点"，算每个字到锚点的码位距离，就能得到
#      一张"我属于哪个语义场"的软分配表 —— 不需要词表，不需要训练。
#
#   2. 码位多尺度 sin/cos（12 维）
#      抓"字形上长得像"。低频尺度抓整块，高频尺度抓细分。
#
#   3. GB2312 区位码（10 维）
#      GB2312 一级汉字（区 16-55）**按拼音排序**。这是免费的拼音压缩：
#      "江 jiang" 和 "将 jiang" 区位相邻，"江" 和 "河 he" 相隔几十个区。
#      于是同音字自动靠近 —— 这正是"含义相近"的一条强线索。
#
# 全部 50 维落在 [0, 1]，与图片特征同量纲，可以直接喂 engine.learn()。
# ---------------------------------------------------------------------------

TEXT_FEATURE_DIM = 50

# 16 个语义部首族的锚点字。**这不是词表**，只是用来在码位轴上定位锚点。
_RADICAL_SEEDS = {
    "水": "江河海湖洋溪流波消深浅",
    "木": "树林森枝根柳杨松柏梅",
    "火": "火焰烧煤灯烛热煮照煎",
    "土": "地土壤堆城墙壁场堤坝",
    "金": "铁钢银铜钱钩锋针钉钟",
    "人": "你我他们仁休仙佳伴侣",
    "口": "吃喝叫喊唱叹吹味吻吐",
    "心": "想恋情愁怕急怒怨念恨",
    "手": "打拉抱推拿握拍拯挂招",
    "足": "跑跳踢踩跨跟践跃踏距",
    "日": "明暗晴晓昨晨时映晒暖",
    "月": "有朋服朗朝期望期",
    "草": "花草茶菜药苗蔬菊荷蓝",
    "虫": "蚊蜂蝶蛇蛾蚂蚁蟹蜀蚕",
    "言": "说话语词诗请谢读识记",
    "丝": "红绿线绳纸编绸练纯织",
}

_RADICAL_SIGMA = 400.0          # 部首族的码位半径（太小则互不渗透，太大则糊成一团）
_CJK_LO, _CJK_HI = 0x4E00, 0x9FFF


def _radical_centers():
    """把每族锚点字的码位取均值，得到该族在 CJK 码位空间里的中心。"""
    out = []
    for name, seeds in _RADICAL_SEEDS.items():
        codes = [ord(c) for c in seeds if _CJK_LO <= ord(c) <= _CJK_HI]
        if codes:
            out.append((name, sum(codes) / float(len(codes))))
    return out


_RADICAL_CENTERS = _radical_centers()
_RADICAL_INDEX = {name: i for i, (name, _) in enumerate(_RADICAL_CENTERS)}

# 码位法的系统性盲区：少数高频字的正字偏旁落在别的部族区里
# （"我" U+6211 紧贴手部区，可它属于"戈"部，而"戈"不在这 16 族里），
# 用一个几行的常识表把最高频的字钉回去 —— 这不是词典，是 5 条常识。
_CHAR_TRIBE_FIX = {"我": "人", "打": "手", "拉": "手"}


def _is_cjk(ch):
    return bool(ch) and _CJK_LO <= ord(ch[0]) <= _CJK_HI


def _gb_locate(ch):
    """汉字在 GB2312 里的 (区, 位)。非 GB2312 字符返回 None。"""
    try:
        raw = ch.encode("gb2312")
    except Exception:
        return None
    if len(raw) != 2:
        return None
    return raw[0] - 0xA0, raw[1] - 0xA0


def extract_char_feature(ch):
    """单个字符 -> 50 维数值向量，值域 [0, 1]。

    汉字走"部首族 + 码位 + 拼音区位"三路；标点/字母/数字走码位兜底，
    保证任何输入都不会返回 None 或抛异常。
    """
    if not ch:
        return [0.0] * TEXT_FEATURE_DIM
    ch = ch[0]
    code = ord(ch)
    is_cjk = _CJK_LO <= code <= _CJK_HI
    feat = [0.0] * TEXT_FEATURE_DIM

    # --- [0..15] 语义部首族软分配 ---------------------------------------
    if is_cjk:
        sigma2 = 2.0 * _RADICAL_SIGMA * _RADICAL_SIGMA
        for i in range(min(16, len(_RADICAL_CENTERS))):
            d = code - _RADICAL_CENTERS[i][1]
            feat[i] = math.exp(-(d * d) / sigma2)

    # --- [16..27] 部族排名编码（强判别信号，12 维）-----------------------
    # 软分配回答"我像哪些族"，排名编码回答"我最像哪一族"。
    # 同族字的 top1/top2 完全一致，跨族字在这里被硬性拉开 —— 这是把
    # 跨族误并率压下去的关键，光靠软分配（码位相邻就互相渗透）做不到。
    if is_cjk:
        fix = _CHAR_TRIBE_FIX.get(ch)
        if fix is not None:
            idx = _RADICAL_INDEX.get(fix)
            if idx is not None:
                for i in range(16):
                    feat[i] = 1.0 if i == idx else feat[i] * 0.35
        order = sorted(range(16), key=lambda i: -feat[i])
        top1 = order[0] if order else 0
        top2 = order[1] if len(order) > 1 else top1
        s1 = feat[top1]
        s2 = feat[top2] if top2 != top1 else 0.0
        if s1 < 0.05:
            # 离 16 个锚点都很远（如"学""道""很"）—— 它不属于任何一族。
            # 原本会退化成 sorted 稳定的第 0 位（误判成"水"族），必须显式标成"无族"。
            top1 = top2 = -1
    else:
        top1 = top2 = -1
        s1 = s2 = 0.0
    # 黄金比例散列：把相邻的族索引打散到 [0,1] 上。
    # 若直接用 pos/15，日(10) 和 月(11) 只差 0.067，排名编码几乎相同 ——
    # 而这两个族的码位区本来就贴在一起，等于白白放行一批跨族误并。
    for slot, pos in ((16, top1), (22, top2)):
        p = 0.31415926 if pos < 0 else (pos * 0.6180339887) % 1.0
        for k in range(3):
            ang = p * math.pi * (0.5 * (2.0 ** k))
            feat[slot + 2 * k] = 0.5 + 0.5 * math.sin(ang)
            feat[slot + 2 * k + 1] = 0.5 + 0.5 * math.cos(ang)

    # --- [28..33] 码位多尺度 sin/cos（只留低频 3 尺度，抓字形邻近）-------
    # 高频尺度只反映"码位差了几十"，与语义无关，是跨族误并的噪声源，故砍掉。
    if is_cjk:
        rel = (code - _CJK_LO) / float(_CJK_HI - _CJK_LO)
    else:
        rel = (code & 0xFFFF) / 65535.0
    rel = min(1.0, max(0.0, rel))
    for k in range(3):
        ang = rel * math.pi * (0.5 * (2.0 ** k))     # 0.5 / 1 / 2
        feat[28 + 2 * k] = 0.5 + 0.5 * math.sin(ang)
        feat[29 + 2 * k] = 0.5 + 0.5 * math.cos(ang)

    # --- [34..37] CJK 大区块软分配（4 块）-------------------------------
    if is_cjk:
        span = float(_CJK_HI - _CJK_LO + 1) / 4.0
        b = (code - _CJK_LO) / span
        for i in range(4):
            d = b - (i + 0.5)
            feat[34 + i] = math.exp(-(d * d) / (2.0 * 0.55 * 0.55))

    # --- [38..41] GB2312 区位（免费的拼音序，低频 1 尺度）----------------
    loc = _gb_locate(ch) if is_cjk else None
    if loc:
        qu, wei = loc
    else:
        qu, wei = 0.0, 0.0
    aq = (qu / 94.0) * math.pi * 0.5
    aw = (wei / 94.0) * math.pi * 0.5
    feat[38] = 0.5 + 0.5 * math.sin(aq)
    feat[39] = 0.5 + 0.5 * math.cos(aq)
    feat[40] = 0.5 + 0.5 * math.sin(aw)
    feat[41] = 0.5 + 0.5 * math.cos(aw)

    # --- [42..49] 标量元信息 -------------------------------------------
    feat[42] = qu / 94.0
    feat[43] = wei / 94.0
    feat[44] = 1.0 if (loc and 16 <= qu <= 55) else 0.0   # 一级汉字(常用)
    feat[45] = 1.0 if is_cjk else 0.0
    feat[46] = rel
    feat[47] = 1.0 if loc else 0.0
    feat[48] = s1                       # 最强部族有多强（典型度）
    feat[49] = s2                       # 次强部族强度

    if not is_cjk:
        # 非汉字（标点 / 字母 / 数字）：补字节信息，别让所有符号撞成同一个点
        try:
            raw = ch.encode("utf-8")
        except Exception:
            raw = b"\x00"
        feat[30] = (raw[0] / 255.0) if len(raw) > 0 else 0.0
        feat[31] = (raw[1] / 255.0) if len(raw) > 1 else 0.0
        feat[32] = (raw[2] / 255.0) if len(raw) > 2 else 0.0
        feat[33] = 1.0 if ch.isdigit() else 0.0

    for i in range(TEXT_FEATURE_DIM):
        v = feat[i]
        if v != v:                    # NaN 兜底
            feat[i] = 0.0
        elif v < 0.0:
            feat[i] = 0.0
        elif v > 1.0:
            feat[i] = 1.0
    return feat


def extract_word_feature(word):
    """词组 -> 50 维（逐字特征取均值）。单字等价于 extract_char_feature。"""
    if not word:
        return [0.0] * TEXT_FEATURE_DIM
    chars = [c for c in word if not c.isspace()]
    if not chars:
        return [0.0] * TEXT_FEATURE_DIM
    acc = [0.0] * TEXT_FEATURE_DIM
    for c in chars:
        f = extract_char_feature(c)
        for i in range(TEXT_FEATURE_DIM):
            acc[i] += f[i]
    n = float(len(chars))
    return [v / n for v in acc]


def iter_cn_units(text):
    """把一段文字切成投喂单元：汉字逐字吐，连续字母数字合成一个词，标点跳过。"""
    buf = []
    for ch in text or "":
        if _is_cjk(ch):
            if buf:
                yield "".join(buf)
                buf = []
            yield ch
        elif ch.isalnum() or ch in "'-_":
            buf.append(ch)
            if len(buf) >= 12:
                yield "".join(buf)
                buf = []
        else:
            if buf:
                yield "".join(buf)
                buf = []
    if buf:
        yield "".join(buf)


# 课本注音：「江(jiāng)」「海（hǎi）」。声调符号落在 U+0100~U+024F，
# 外加零声母的 ü / ' 与隔音符号，都在后面这个字符类里。
_PYIN_RE = re.compile(
    u"([\u3400-\u4dbf\u4e00-\u9fff])"
    u"[（(]\s*([A-Za-z\u00c0-\u024f\u0300-\u036f'\u00b7\s]{1,24}?)\s*[）)]"
)


def strip_pinyin(text):
    """把课本里的「字(pīn yīn)」注音剥下来，返回 (纯正文, {正文索引: 拼音})。

    为什么必须剥而不是留着：next_char() 会把连续的 ASCII 字母当成一个「词」
    喂给大脑（extract_word_feature）。标了音的课文如果原样进缓冲，
    jiang / hai / wo 这些拼音会变成一个个新词塞满节点表 —— 她学到的就不是
    汉字而是自己的注音了。注音只该进节点的 pinyin 字段。

    索引对齐：返回值里的键是**剥离后**正文的下标，正好等于 next_char 里
    idx（self._pos）取到的位置，所以取用时不需要再算偏移。
    """
    if not text:
        return "", {}
    out, marks = [], {}
    i, total = 0, len(text)
    while i < total:
        m = _PYIN_RE.match(text, i)
        if m:
            marks[len(out)] = m.group(2).strip().lower()
            out.append(m.group(1))
            i = m.end()
            continue
        out.append(text[i])
        i += 1
    return "".join(out), marks


# 句末标点：读到一个就换一句。换行也算 —— 课本一行一句。
_SENT_BREAK = u"。！？!?；;" + chr(10) + chr(13)


def _sent_map(text):
    """给每个字符标一个句子号，供「同句相邻的字互相连线」使用。

    返回的列表长度等于 len(text)，下标与 next_char() 里的 idx 对齐 ——
    这是元音剥离之后的正文下标，所以和 self._pinyin 用的是同一套坐标。
    """
    out = []
    no = 0
    for ch in text:
        if ch in _SENT_BREAK:
            no += 1
        out.append(no)
    return out


def read_text_file(path, max_chars=200000):
    """安全读文本：多重编码兜底，坏字节直接忽略，绝不抛异常。"""
    raw = None
    try:
        raw = Path(path).read_bytes()
    except Exception:
        return ""
    if raw is None:
        return ""
    for enc in ("utf-8-sig", "utf-8", "gb18030", "utf-16", "big5"):
        try:
            text = raw.decode(enc)
            break
        except Exception:
            text = None
    if text is None:
        text = raw.decode("utf-8", errors="ignore")
    text = text.replace("\x00", "")
    return text[:max_chars]


class AhaInput:
    """小鱼的眼睛与耳朵。

    用法:
        eye = AhaInput()                 # 默认 A:\\Aha_Universe\\Input_Files
        eye.feed(engine)                 # 随便抓一个输入喂给它
    """

    def __init__(self, root=None, seed=None, synth_when_empty=True, text_mode=False):
        self.root = Path(root) if root else (_HERE / "Input_Files")
        self.root.mkdir(parents=True, exist_ok=True)
        self.rng = random.Random(seed)
        self.synth_when_empty = synth_when_empty
        self._prototypes = self._build_prototypes(8)
        self.last_error = None

        # --- 中文文本模式（m01200）---
        # text_mode=True：不再合成噪声、不走图像边缘检测，改成逐字读 .txt。
        self.text_mode = bool(text_mode)
        self._text_lock = threading.Lock()
        self._tbuf = ""          # 当前文件的全文缓冲区（注音已剥掉）
        self._pinyin = {}        # {正文字符下标: 拼音}，来自课本的「字(pīn yīn)」
        self._sent_ids = []      # 每个字符的句子号（_sent_map 的结果）
        self._doc_no = 0         # 第几篇课文；和句子号一起构成全局唯一的 sent_id
        self._pos = 0            # 读到第几个字符
        self._cur_file = None
        self._cur_name = ""
        self.text_files_read = 0
        self.chars_fed = 0
        self._read_set = set()     # 本轮已读过的文件
        self._round_end_at = 0.0   # 上一轮读完的时刻
        self.round_cooldown = 3.0  # 读完一本歇多久再从头看（秒）
        # 读完过几轮。投喂控制台的"一键全部投喂"靠它判断"这一轮真的读完了"——
        # 不能用 _read_set 判：那个集合在读完的瞬间就被清空了，事后看永远是空的。
        self.rounds_done = 0

        # --- 课程选择（m02388）---
        # 老师点哪一课就读哪一课；读完停住，不再自己往后翻。没有指定时
        # 退回老行为：按文件名顺序把 Input_Files 轮一遍。
        self.hold = False          # 停住自动投喂，等老师点下一课
        self.hold_reason = ""
        self.hold_file = ""
        self._forced_name = ""     # 待读的指定文件名（只读一次）
        self._hold_target = ""     # 正在读的那一课，读完好收工

    # -- 目录 -------------------------------------------------------------

    def list_inputs(self):
        """列出 Input_Files 里可用的文件（跳过读不了的、超大体积的）。"""
        out = []
        if not self.root.is_dir():
            return out
        try:
            entries = sorted(self.root.iterdir())
        except Exception as exc:
            self.last_error = repr(exc)
            return out
        for p in entries:
            if not p.is_file() or p.name.startswith("."):
                continue
            ext = p.suffix.lower()
            if ext in IMAGE_EXTS or ext in TEXT_EXTS:
                try:
                    if p.stat().st_size > 32 * 1024 * 1024:
                        continue
                except Exception:
                    continue
                out.append(p)
        return out

    # -- 合成感官（目录为空时用）-------------------------------------------

    @staticmethod
    def _build_prototypes(count, dim=FEATURE_DIM):
        """固定的"天生就会看到的几种东西"。

        用固定种子生成，保证每次启动的原型一致 —— 否则每次重启小鱼都会
        把同样的东西当成全新未知，记忆库会被垃圾节点填满。
        """
        rng = random.Random(20260101)
        return [[rng.random() for _ in range(dim)] for _ in range(count)]

    def synth_feature(self):
        """没有投喂时的内部噪声输入：从原型里挑一个 + 高斯扰动。

        这样即使 Input_Files 是空的，小鱼也在自己"看见"东西，星云会生长，
        而不是死机一样停在那里。
        """
        proto = self.rng.choice(self._prototypes)
        return [round(_clamp01(v + self.rng.gauss(0.0, 0.10)), 6) for v in proto]

    # -- 文本流：逐字投喂 --------------------------------------------------
    #
    # 这里是"眼睛"，不是"老师"。只负责吐字 + 降维，不碰网络。
    # 教学（把这个字送去 DeepSeek 要标签）在 aha_server.py 的 life_loop 里做。

    TEXT_UNIT_EXTS = (".txt", ".md")

    def list_text_files(self):
        """只列 .txt / .md。其它文本格式先不喂，免得一堆配置把记忆灌满。"""
        out = []
        if not self.root.is_dir():
            return out
        try:
            entries = sorted(self.root.iterdir())
        except Exception as exc:
            self.last_error = repr(exc)
            return out
        for p in entries:
            if not p.is_file() or p.name.startswith("."):
                continue
            if p.suffix.lower() not in self.TEXT_UNIT_EXTS:
                continue
            try:
                size = p.stat().st_size
            except Exception:
                continue
            if size <= 0 or size > 8 * 1024 * 1024:
                continue
            out.append(p)
        return out

    def _load_next_text_file(self):
        """换下一个还没读过的 txt 读进缓冲区。

        轮转语义：一轮之内每个文件只读一次；全部读完就返回 False，并进入
        冷却（round_cooldown 秒）。冷却结束后才会从头开始第二轮 —— 否则同一本
        书会被瞬间反复灌进大脑，把一个字顶到饱和、把教学接口打爆。
        """
        if self.hold:
            self._tbuf, self._pos = "", 0
            return False
        files = self.list_text_files()
        if not files:
            self._tbuf, self._pos = "", 0
            return False
        if self._hold_target and not self._forced_name:
            # 老师点的那一课读完了（缓冲耗尽才会再进来）：停住。
            done = self._hold_target
            self._hold_target = ""
            self._tbuf, self._pos = "", 0
            self.hold = True
            self.hold_file = done
            self.hold_reason = "《%s》读完了。点下一课，或者放她自己玩。" % done
            return False
        if self._forced_name:
            want = self._forced_name
            self._forced_name = ""
            hit = None
            for p in files:
                if p.name == want:
                    hit = p
                    break
            if hit is not None:
                self._read_set.add(hit)
                try:
                    text = read_text_file(hit)
                except Exception:
                    text = ""
                if text and text.strip():
                    text, self._pinyin = strip_pinyin(text)
                    self._sent_ids = _sent_map(text)
                    self._doc_no += 1
                    self._tbuf, self._pos = text, 0
                    self._cur_file, self._cur_name = hit, hit.name
                    self.text_files_read += 1
                    return True
        pending = [p for p in files if p not in self._read_set]
        if not pending:
            # 一轮读完：清空已读标记，记下时刻，开始冷却
            self._tbuf, self._pos = "", 0
            self._read_set.clear()
            self._round_end_at = time.time()
            self.rounds_done += 1
            return False
        if self._round_end_at > 0.0:
            if (time.time() - self._round_end_at) < self.round_cooldown:
                self._tbuf, self._pos = "", 0
                return False
            self._round_end_at = 0.0
        for p in pending:
            self._read_set.add(p)
            try:
                text = read_text_file(p)
            except Exception:
                text = ""
            if not text or not text.strip():
                continue          # 空文件 / 纯空白：标记已读，换下一个
            text, self._pinyin = strip_pinyin(text)
            self._sent_ids = _sent_map(text)
            self._doc_no += 1
            self._tbuf = text
            self._pos = 0
            self._cur_file = p
            self._cur_name = p.name
            self.text_files_read += 1
            return True
        self._tbuf, self._pos = "", 0
        return False

    def round_progress(self):
        """投喂进度（给侧栏用，只读，不改任何状态）。"""
        try:
            files = self.list_text_files()
        except Exception:
            files = []
        total = len(files)
        try:
            read_n = sum(1 for p in files if p in self._read_set)
        except Exception:
            read_n = 0
        return {
            "total": total,
            "read": read_n,
            "left": max(0, total - read_n),
            "rounds_done": self.rounds_done,
            "checked_out": len(self._read_set),
            "current": self._cur_name or "",
            "chars_fed": self.chars_fed,
            "text_files_read": self.text_files_read,
            "hold": bool(self.hold),
            "hold_reason": self.hold_reason or "",
            "hold_file": self.hold_file or "",
            "forced": self._forced_name or "",
        }

    def resume_round(self):
        """跳过轮间冷却，立刻开始下一轮（"一键全部投喂"用）。"""
        with self._text_lock:
            self._round_end_at = 0.0

    def select_text_file(self, name):
        """指定下一课读哪个文件（前端课程选择器）。

        只接受 list_text_files() 里真实存在的文件名 —— 前端传什么
        "../config.json" 这种花活都会被挡在这里，不然就是拿她的眼睛去翻
        整台机器。返回 (path, None) 或 (None, 原因)。
        """
        want = str(name or "").strip()
        if not want:
            return None, "没给文件名"
        try:
            files = self.list_text_files()
        except Exception as exc:
            return None, "列目录失败：%r" % (exc,)
        hit = None
        for p in files:
            if p.name == want:
                hit = p
                break
        if hit is None:
            return None, "Input_Files 里没有《%s》" % want
        with self._text_lock:
            self._tbuf, self._pos = "", 0
            self._cur_file, self._cur_name = None, ""
            self._read_set.discard(hit)     # 允许重读
            self._round_end_at = 0.0
            self._forced_name = hit.name
            self._hold_target = hit.name
            self.hold = False
            self.hold_reason = ""
            self.hold_file = ""
        return hit, None

    def release_hold(self):
        """解除「这一课上完了」的停泊，恢复按文件名顺序轮转。"""
        with self._text_lock:
            self.hold = False
            self.hold_reason = ""
            self.hold_file = ""
            self._forced_name = ""
            self._hold_target = ""
            self._round_end_at = 0.0
        return True

    def next_char(self):
        """逐字吐一个单元：汉字单字，或一串连续的 ASCII 词。

        返回 {kind, glyph, feature, path, name, index}；没有可用文本时返回 None。
        内部把异常全部吞掉并清空缓冲 —— 主循环绝不允许因为这个卡死。
        """
        with self._text_lock:
            try:
                for _ in range(400):
                    if not self._tbuf or self._pos >= len(self._tbuf):
                        if not self._load_next_text_file():
                            return None
                        continue
                    idx = self._pos
                    sent = self._sent_ids[idx] if 0 <= idx < len(self._sent_ids) else 0
                    ch = self._tbuf[self._pos]
                    self._pos += 1
                    if ch.isspace():
                        continue
                    try:
                        if unicodedata.category(ch).startswith("C"):
                            continue
                    except Exception:
                        pass
                    if _is_cjk(ch):
                        unit = {
                            "kind": "char",
                            "glyph": ch,
                            "pinyin": self._pinyin.get(idx, ""),
                            "feature": extract_char_feature(ch),
                            "path": str(self._cur_file) if self._cur_file else "",
                            "name": self._cur_name,
                            "index": idx,
                            "sent": sent,
                            "doc": self._doc_no,
                        }
                        self.chars_fed += 1
                        return unit
                    if ch.isascii() and ch.isalnum():
                        j = self._pos
                        while (j < len(self._tbuf) and (j - idx) < 12
                               and self._tbuf[j].isascii() and self._tbuf[j].isalnum()):
                            j += 1
                        word = self._tbuf[idx:j]
                        self._pos = j
                        self.chars_fed += 1
                        return {
                            "kind": "word",
                            "glyph": word,
                            "feature": extract_word_feature(word),
                            "path": str(self._cur_file) if self._cur_file else "",
                            "name": self._cur_name,
                            "index": idx,
                            "sent": sent,
                            "doc": self._doc_no,
                        }
                    # 标点 / 符号 / emoji：跳过
                return None
            except Exception as exc:
                self.last_error = "next_char: %r" % (exc,)
                self._tbuf, self._pos = "", 0
                return None

    def feed_char(self, engine, unit, meaning=None, verdict=None, now=None):
        """把一个字（或词）连同标签一起交给大脑。"""
        if not unit:
            return {"event": "idle", "thought": "没有可用的文本", "input": None}
        meta = {
            "kind": unit["kind"],
            "glyph": unit["glyph"],
            "name": unit["name"],
            "path": unit["path"],
            "meaning": meaning,
            "verdict": verdict,
            "pinyin": unit.get("pinyin") or "",
            # m03809：同一句话里挨着出现的两个字，靠它连成一条边。
            "sent_id": "%d:%d" % (int(unit.get("doc") or 0),
                                  int(unit.get("sent") or 0)),
        }
        result = engine.learn(unit["feature"], meta=meta, now=now)
        result["input"] = {
            "kind": unit["kind"],
            "name": unit["glyph"],
            "glyph": unit["glyph"],
            "meaning": meaning,
            "verdict": verdict,
            "feature": unit["feature"],
            "path": unit["path"],
        }
        return result

    # -- 核心: 扫描一帧 ----------------------------------------------------

    def scan_directory(self):
        """遍历 Input_Files，随机抽一个输入并提取 10 维特征。

        返回 dict: {kind, path, name, feature, shape, size}
        图片 -> kind="image" | 文本 -> kind="text" | 空目录 -> kind="synth"
        """
        files = self.list_inputs()

        if not files:
            if not self.synth_when_empty:
                return None
            return {
                "kind": "synth",
                "path": "",
                "name": "<sensory-noise>",
                "feature": self.synth_feature(),
                "size": 0,
            }

        # 打乱后逐个尝试，读坏了就换下一个（不因单张坏图卡死整个循环）
        order = files[:]
        self.rng.shuffle(order)
        for p in order[:min(8, len(order))]:
            ext = p.suffix.lower()
            try:
                if ext in IMAGE_EXTS:
                    feat = extract_image_feature(p)
                    if feat is None:
                        self.last_error = "无法解码: %s" % p.name
                        continue
                    shape = ""
                    if cv2 is not None:
                        img = _imread_unicode(p)
                        if img is not None:
                            shape = "%dx%d" % (img.shape[1], img.shape[0])
                    return {
                        "kind": "image",
                        "path": str(p),
                        "name": p.name,
                        "feature": feat,
                        "shape": shape,
                        "size": p.stat().st_size if p.exists() else 0,
                    }
                feat = extract_text_feature(p)
                if feat is None:
                    self.last_error = "无法读取: %s" % p.name
                    continue
                return {
                    "kind": "text",
                    "path": str(p),
                    "name": p.name,
                    "feature": feat,
                    "size": p.stat().st_size if p.exists() else 0,
                }
            except Exception as exc:
                self.last_error = "%s: %r" % (p.name, exc)
                continue

        # 所有候选都读失败 -> 退回内部噪声，绝不让主循环空转
        if not self.synth_when_empty:
            return None
        return {
            "kind": "synth",
            "path": "",
            "name": "<sensory-noise>",
            "feature": self.synth_feature(),
            "size": 0,
        }

    # -- 喂食 -------------------------------------------------------------

    def feed(self, engine, record=None, now=None):
        """抽一个输入并交给大脑。返回 engine.learn() 的结果 + 输入元信息。"""
        rec = record or self.scan_directory()
        if rec is None:
            return {"event": "idle", "thought": "没有可用的输入", "input": None}
        result = engine.learn(
            rec["feature"],
            meta={"path": rec["path"], "name": rec["name"], "kind": rec["kind"]},
            now=now,
        )
        result["input"] = rec
        return result

    def feed_text(self, engine, text, now=None):
        """把一段外部文本（例如 DeepSeek 的答案）压成特征喂进去。"""
        feat = extract_text_feature(text, is_text=True)
        result = engine.learn(feat, meta={"kind": "text", "name": "<taught>"}, now=now)
        result["input"] = {"kind": "text", "name": "<taught>", "feature": feat,
                           "size": len(text), "path": ""}
        return result


# ---------------------------------------------------------------------------
# 自测：python aha_input.py
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import json
    import time as _time

    from aha_brain import AhaEngine

    print("=== Project Aha 输入层自检 ===")
    print("cv2: %s" % (cv2.__version__ if cv2 is not None else "未安装（已退化到 Pillow）"))

    eye = AhaInput()
    files = eye.list_inputs()
    print("Input_Files: %s" % eye.root)
    print("可用输入文件: %d 个" % len(files))
    for p in files[:10]:
        print("  - %s" % p.name)

    engine = AhaEngine()
    t0 = _time.time()

    # 观察 120 次喂食后记忆的形态
    for i in range(120):
        now = t0 + i * 0.15
        eye.feed(engine, now=now)
        engine.tick(0.15, now=now)

    print("\n喂食 120 次后:")
    print("  节点: %d   连接: %d" % (len(engine.nodes), len(engine.connections)))
    print("  生理: %s" % json.dumps(engine.physiology(), ensure_ascii=False))
    print("  想法: %s" % engine.last_thought)

    sample = eye.scan_directory()
    print("\n一次抽样输入: kind=%s name=%s" % (sample["kind"], sample["name"]))
    print("  特征向量(10维): %s" % sample["feature"])
    assert len(sample["feature"]) == FEATURE_DIM, "特征维度必须为 %d" % FEATURE_DIM

    # 文本通路
    tf = extract_text_feature("小鱼今天看见了一片绿叶，上面挂着一颗红果子。", is_text=True)
    print("  文本特征(10维): %s" % tf)
    assert len(tf) == FEATURE_DIM

    # 不同输入应该给出不同的稀缺度（少数派原则）
    print("\n稀缺度抽样（同一特征反复喂 -> 应趋近 0.4；陌生 -> 趋近 1.6）:")
    common = engine._find_closest_node(sample["feature"], threshold=-2.0)
    if common is not None:
        print("  已记住的那一个: %.3f" % engine._salience_of(common.features))
    print("  全新随机输入  : %.3f" % engine._salience_of([0.01, 0.02, 0.03, 0.99, 0.98, 0.97, 0.5, 0.5, 0.5, 0.5]))

    print("\n输入层 OK。")
