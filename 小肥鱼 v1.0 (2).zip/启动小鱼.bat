@echo off
chcp 65001 >nul
title 小肥鱼 v1.0 · Project Aha
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
echo.
echo   小肥鱼正在苏醒 ...
echo   天文台:  http://127.0.0.1:8000
echo   记忆每 60 秒自动落盘一次；点右上角「⏻ 关闭」或关掉这个黑窗口 = 让她睡下。
echo.
start "" /min cmd /c "timeout /t 5 >nul & start http://127.0.0.1:8000"
python aha_server.py --port 8000
echo.
echo   小肥鱼已停止。存档在 Memory_Core\brain_state.json
pause
